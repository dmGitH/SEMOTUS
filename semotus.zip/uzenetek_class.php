<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Uzenetek
{

    public $id;
    public $message_id;
    public $kinek;
    public $statusz;
    

    public function __construct()
    {

    }


}