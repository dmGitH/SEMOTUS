<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo 0;
    exit();
}

function javakerdimennyiuzenetevan()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'csek.php';
    require_once 'uzenetek_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $klt = $_POST["klt"];
        if(strlen($klt)!=40)exit;
        $reg_id = "*";
        $i=0;
        if ($result = $db->query("SELECT `id`,`passhash`,`dmsk` from reg;")) {
            if ($result->rowCount()) {
                $sor = "";
                while ($row2 = $result->fetch(PDO::FETCH_NUM)) {
                    $sor = sha1(substr(base64_encode(sha1($row2[1] . $row2[2])), 0, 40));
                    if ($sor == sha1($klt)) {
                        $reg_id = $row2[0];
                        break;
                    }
                }

            } else {
                $db=null;
                echo base64_encode('Error');
                exit;
            }
        } else {
            $db = null;
            echo base64_encode('Error');
            exit;
        }
        if ($reg_id == "*") {
            $db = null;
            echo '*';
            exit;
        } else {
            if ($result = $db->query("select id from kiknek where kinek='$reg_id' and statusz=0;")) {
                $result->setFetchMode(PDO::FETCH_CLASS, 'Uzenetek');
                $vissza;
                if ($result->rowCount()) {
                    while($row = $result->fetch()) {
                        $i++;
                    }
                }else{
                    $db = null;
                    echo 0;
                    exit;
                }
            }else{
                $db = null;
                echo base64_encode('Error');
                exit;
            }
        }
        $db = null;
        echo $i;
    } else {
        $db = null;
        echo base64_encode('Error');
    }
}
