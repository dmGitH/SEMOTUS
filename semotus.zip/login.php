<?php

use Faker\Provider\Base;
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
};

function belepes()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'secus.php';
    require_once 'csek.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);
        $nyelv = $_POST["nyelv"];

        // Get the form fields and remove whitespace.

        $tmp2 = secxor($_POST["nickname"], $kulcs);
        $nickname = strip_tags(trim($tmp2));
        $tmp3 = secxor($_POST["loginpass"], $kulcs);
        $loginpass = strip_tags(trim($tmp3));

        $ujkulcs = ujkucs($kulcs, $nickname);
        $kileptetes = $_POST["cb"];

        // Check that data was sent to the mailer.
        if (empty($nickname) or empty($loginpass)) {
            // Set a 400 (bad request) response code and exit.
            //http_response_code(400);
            echo responsxor("val:<h1 id=\"a41\"></h1>", $ujkulcs);
            exit;
        }
        if (strlen($nickname) < 4 || strlen($loginpass) < 7) {
            echo responsxor("val:<h1 id=\"a42\"></h1>", $ujkulcs);
            exit;
        }

        $jelszohash = hash('sha256', $loginpass . $nickname);
        $jelszohash = hassolo($jelszohash, $nickname);
        //SELECT ip,count(ip) FROM `sikertelen` where date>UNIX_TIMESTAMP()-180
        if ($result = $db->query("SELECT ip,count(ip) FROM `sikertelen` where date>" . time() . "-180")) {
            if ($result->rowCount()) {
                $eredmeny = $result->fetchAll(PDO::FETCH_NUM);

                $ip = $eredmeny[0][0];
                $proba = $eredmeny[0][1];
                if ($_SERVER['REMOTE_ADDR'] == $ip) {
                    if ($proba > 4) {
                        echo '-4';
                        $db = null;
                        exit;
                    }
                }
            } else {

            }

        } else {

        }
        $name = '*';
        $reg_id = 0;
        if ($result = $db->query("select * from reg where passhash='$jelszohash' and nickname='$nickname';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
            $i = 0;
            if ($result->rowCount()) {
                if ($result->rowCount() == 1) {
                    while ($row = $result->fetch()) {
                        $name = $row->nickname;
                        $reg_id = $row->id;
                        $aktiv = $row->aktiv;
                        if ($aktiv == -1) {
                            echo '-3';
                            $db = null;
                            exit;
                        }

                        $i = 1;
                    }
                } else {

                    while ($row = $result->fetch()) {
                        $i++;
                        if ($i > 0) {
                            if ($row->aktiv == 0) {

                                $sql = "delete from reg where passhash='$jelszohash';";
                                $db->exec($sql);

                            } else {

                                $name = $row->nickname;
                                $reg_id = $row->id;
                            }
                        } else {

                        }

                    }
                }
            }
            if ($i == 0 || $name == '*') {

                $query = $db->prepare("insert into sikertelen (`username`,`password`,`date`,`ip`,`eszkoz`) VALUES(?,?,?,?,?);");
                $query->execute(array($nickname, rpass(), time(), $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']));
                $db = null;
                echo responsxor('val:<h1 id="a40"></h1>', $ujkulcs);
                exit;
            }

        } else {
            echo responsxor('val:<p>Lekérdezési hiba</p>', $ujkulcs);
            $db = null;
            exit;
        }

        $valasz = "";

        if ($kileptetes) {
            $sql = "delete from login where reg_id=$reg_id;";
            $db->exec($sql);
        }

        $loginkod = substr(base64_encode(sha1(rand() + time() * rand()).md5($reg_id)),0,80);
//---megnézni hogy van e már belépése a tagnak ha van update ha nincs insert
        if ($result = $db->query("select * from login where reg_id='$reg_id' AND `eszkoz_azon`='" . $_SERVER['HTTP_USER_AGENT'] . "';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Login');

            if ($result->rowCount()) {
                $query = "update login SET `bejelentkezett`='" . time() . "',`ip`='" . ipgen() . "',`statusz`=`statusz`+1,`eszkoz_azon`='" . $_SERVER['HTTP_USER_AGENT'] . "',`loginkod`='" . $loginkod. "'  where reg_id='$reg_id' and eszkoz_azon='" . $_SERVER['HTTP_USER_AGENT'] . "';";
                // echo $query;
                // exit;
                $statement = $db->prepare($query);
                $statement->execute();
            } else {
                $query = $db->prepare("insert into login (`reg_id`,`bejelentkezett`,`ip`,`statusz`,`eszkoz_azon`,`loginkod`) VALUES(?,?,?,?,?,?);");
                $query->execute(array($reg_id, time(), ipgen(), 1, $_SERVER['HTTP_USER_AGENT'], $loginkod));
            }
        } else {
            $db = null;
            echo hibauzenetek(404);
            exit;
        }

        echo responsxor("val:login" . $nyelv . $loginkod, $ujkulcs);

        $db = null;
        exit;

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        //http_response_code(403);
        $db = null;
        echo hibauzenetek(404);
        exit;
    }
}
