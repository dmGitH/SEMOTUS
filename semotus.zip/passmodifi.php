<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function passmodifi()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);
        if ($kulcs == null) {
            echo 'kulcsszinkron hiba';
            exit;
        }
        //echo sha1($kulcs);
        $loginkod_passmodositas_sha1 = $_POST['logincode'];
        $ujpass = strip_tags(trim(secxor($_POST['sinc'], $kulcs)));
        //echo $ujpass;
        $ujnickname = strip_tags(trim(secxor($_POST['nnm'], $kulcs)));
        $ujkulcs = ujkucs($kulcs, $ujpass);
        //meg kell keresni a felhasználói nevet
        $reg_id=kikerdezi($loginkod_passmodositas_sha1);
        $nickname = "";
        if ($result = $db->query("select * from reg where id='$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $nickname = $row->nickname;

                }

            } else {
                $db = null;
                echo hibauzenetek(403);
                exit;
            }
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }
        //itt össze kell hozni a jelszohast
        //echo $ujpass;
        if ($ujnickname == '0') {
            $jelszohash = hash('sha256', $ujpass . $nickname);
            $jelszohash = hassolo($jelszohash, $nickname);
        } else {
            $jelszohash = hash('sha256', $ujpass . $ujnickname);
            $jelszohash = hassolo($jelszohash, $ujnickname);
            if ($result = $db->query("select * from reg where `nickname`='" . $ujnickname . "';")) {
                if ($result->rowCount()) {
                    echo 2;
                    $db = null;
                    exit;
                }
            }
        }
        $update = "update reg set `passhash`='" . $jelszohash . "' where id=" . $reg_id . ";";
        $db->exec($update);
        if ($ujnickname != '0') {
            $update = "update reg set `nickname`='" . $ujnickname . "' where id=" . $reg_id . ";";
            $db->exec($update);
            $uzenetszoveg = "Rendszerüzenet: A csoportban $nickname megváltoztatta a loginnevét $ujnickname re/ra.";
            $hossza = strlen($uzenetszoveg);
            $sor = sha1(time() + $hossza);
            $uzenetszoveg = responsxordatabase($uzenetszoveg, dmsksecd());
            $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
            $query->execute(array($reg_id, $uzenetszoveg, time(), time() + (168 * 60 * 60), $sor . ':' . $hossza));
            $utolso_uzenet_id = $db->lastInsertId();
            $query = $db->prepare("insert into kiknek (`message_id`,`kinek`,`statusz`) VALUES(?,?,?);");
            $query->execute(array($utolso_uzenet_id, aid(), 0));
            $db = null;
        }
        $db = null;
        echo 1;

    } else {
        echo hibauzenetek(403);
    }
}
