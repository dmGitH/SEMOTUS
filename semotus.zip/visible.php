<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function lattam()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'uzenetek_class.php';
//require_once 'uezent_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $uzenetazon_sha1 = $_POST["sinc"];
        $lg_sha1 = $_POST["lg"];

        //jogosultság ellenörzés
        kikerdezi($lg_sha1);
        //üzenet státusz átállítás
        if ($result = $db->query("select * from kiknek;")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Uzenetek');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $id = $row->id;
                    $message_id = $row->message_id;

                    if (sha1($id) == $uzenetazon_sha1) {
                        $query = "UPDATE kiknek SET `statusz`= 1 where id='$id';";
                        $db->exec($query);
                        if ($result = $db->query("SELECT * from `kiknek` where `statusz` = 0 and message_id='$message_id';")) {
                            if ($result->rowCount()) {

                            } else {
                                if ($result = $db->query("SELECT `sor` from message where id=$message_id;")) {
                                    if ($result->rowCount()) {
                                        $sor = "";
                                        while ($row = $result->fetch(PDO::FETCH_NUM)) {
                                            $sor = $row[0];
                                        }
                                        $query = "update message SET `sor`= 1 where `sor`='$sor';";
                                        $db->exec($query);
                                    } else {

                                    }
                                } else {

                                }
                            }
                        } else {

                        }
                        //
                        //válaszolni egy elolvasva uzenettel?

                        $db = null;
                        echo 1;
                        exit;
                    }

                }
                echo 0;
                $db = null;
                exit;
            } else {
                $db = null;
                echo 0;
                exit;
            }
        } else {
            $db = null;
            echo 0;
            exit;
        }

        $db = null;
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
