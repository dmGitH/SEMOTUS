<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function reg()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'csek.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);

        $email = filter_var(trim(secxor($_POST["email"], $kulcs)), FILTER_SANITIZE_EMAIL);

        $ujkulcs = ujkucs($kulcs, $email);
        $tmp1 = secxor($_POST["name"], $kulcs);
        $name = strip_tags(trim($tmp1));
        $name = str_replace(array("\r", "\n"), array(" ", " "), $name);

        // Check that data was sent to the mailer.
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            //http_response_code(400);
            echo responsxor("<h1 class=\"a80\"></h1>" . $email, $ujkulcs);

            exit;
        }

        $kod = hash('sha256', $email . $name);
        for ($i = 0; $i < 5; $i++) {
            $kod = hash('sha256', sha1($kod) . $name);
        }
        $kod=substr(base64_encode($kod),0,64);
        //---ellenorizni kell van e már ilyen cim regisztralva
        $ellenor = false;
        if ($result = $db->query("select hash from reg where hash='$kod';")) {

            if ($result->rowCount()) {
                $ellenor = true;
                echo responsxor('<h1 class="a81"></h1>', $ujkulcs);
                exit();
            }

        }
        if ($result = $db->query("select nickname from reg where nickname='$name';")) {

            if ($result->rowCount()) {

                echo 'foglalt';
                $db = null;
                exit();

            }

        }
        $statusz = 0;
        if ($result = $db->query("select * from reg;")) {

            if (!$result->rowCount()) {
                $statusz = 3;
            }
        }
        $recipient = $email;
        $dmsk = sha1(rand());
        $dmskkuldd = 'G' . substr($dmsk, 1, 10) . 'EN';
        $jelszo = sha1(rand());
        if (!$ellenor) {
            $jelszo = 'G'.substr($jelszo, 1, 8).'EN';
        }

        if (!$ellenor) {
            $dmsk = responsxor('G'.substr($dmsk, 1, 10).'EN', dmsksec());
        } else {
            $jelszo = " Az első regisztrációs e-mailben található!";
        }
        //The purpose of the use is to rewrite
        // Set the email subject.
        $subject = "(Confirmation of registration:) Regisztráció megerősítése:  Semotus";

        // Build the email content.

       
        $email_content .= "Másold be ezt a kódot annak a megerősítéséhez, hogy megkaptad, ezt az e-mailt.(Copy this code to confirm that you have received this email.) \n A kód a következő 64 karakterből álló sorozat.(The code is a series of 64 characters.) ( jelöld ki a kódot PONTOSAN, majd Ctrl+c másolás, utánna beillesztés Ctrl+v) : \n\n" . $kod . "\n\n";
        
        $email_content .= "Kedves: $name. Jelszó az első bejelentkezésedhez(Password for your login): $jelszo\nAz itt kapott jelszót az első bejelentkezés után tetszőlegesen megváltoztathatod. (You can change the password you have received here after login in.)\n";
        $email_content .= "A jelszavad \"elvesztése\" esetén, egy másik e-mail címről tudsz új regisztrációt kezdeményezni, vagy a csoport adminisztrátorát kérd meg, hogy törölje a regisztrációdat.\n";
        $email_content .= "\n\n";
        $email_content .= "\n\nRendszerüzenet(Message system)";
        $email_content .= "\n\nDMSK-240B-F üzenetküldő rendszer biztonsági figyelmeztetése (Security Bulletin from DMSK-240B-F Messaging System:):\n";
        $email_content .= "Ha maximális biztonságban akarod az üzeneteid küldeni az interneten keresztül, akkor bejelentkezés után add meg ezt a kódot a DMSK BEÁLLÍTÁS menüben(If you want to send your messages with security over the internet, enter this code in the DMSK SETUP menu after logging in)(DMSK-240B-F): $dmskkuldd \nA kód megadása nem kötelező, de a biztonsági szint növelését nagymértékben szolgálja.(Entering the code is not required, but security level is greatly enhanced)\n";
        $email_content .= "\n";

        if (utf8_encode($email_content));
        else{
            $email_content = ekezetlenites($email_content);
        }

        // Build the email headers.
        //$email_headers = "From: $name <$email>";
        //mail('cimzett@cimzett.hu', 'TÁRGY', 'ÜZENET', null, '-f felado@nethelynel.hu')

        // Send the email.

        if (mail($recipient, $subject, $email_content, 'From:info@semotus.hu')) {
            // Set a 200 (okay) response code.
            //http_response_code(200);
            //az első regisztráló felhasználó admin módot kapjon $statusz beállítása
            if ($ellenor == false) {
                $query = $db->prepare("insert into reg (`hash`,`aktiv`,`regisztralt`,`ip`,`nickname`,`passhash`,`dmsk`) VALUES(?,?,?,?,?,?,?);");
                $jelszohash = hash('sha256', $jelszo . $name);
                $jelszohash = hassolo($jelszohash, $name);
                $query->execute(array($kod, $statusz, time(), ipgen(), $name, $jelszohash, $dmsk));
            }
            $db = null;

            if ($ellenor == false) {
                echo responsxor("<h1 class=\"a82\"></h1>", $ujkulcs);
            }

        } else {
            // Set a 500 (internal server error) response code.
            //http_response_code(500);
            echo 'hiba';
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        //http_response_code(403);
        echo hibauzenetek(403);
    }
}
