<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Login
{

    public $id;
    public $reg_id;
    public $bejelentkezett;
    public $ip;
    public $statusz;
    public $kijelentkezes;
    public $eszkoz_azon;
    public $loginkod;

    public function __construct()
    {

    }


}