<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function rzgrg()
{

    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'd234_kopl_456_db.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        lejaruzenettorlese();
        //  $y = "delete from message where lejar<" . time() . " ;";
        //  $db->exec($y);

        //  $z = "DELETE FROM `message`  WHERE message.id not in (SELECT kiknek.message_id from kiknek WHERE statusz=0);";
        //  $db->exec($z);

        //  $x = "delete from kiknek where message_id not in (select id from message );";
        //  $db->exec($x);

        //  $db = null;
        if (count($_POST) !=5) {
            header("Location: https://dm.semotus.hu/index.php"); /* Redirect browser */
            exit();
        }
        $sinckod = sha1($_POST['sinc']);
        
        $lg_sha1 = $_POST['lg'];
        $tk = $_POST['tk'];
        $dmsk = $_POST['dmsk'];
        $phmd5;
        $reg_id = 0;
        if ($lg_sha1 == "2b020927d3c6eb407223a1baa3d6ce3597a3f88d");
        else{
            
            $tmp;
            if ($result = $db->query("select `loginkod`,`reg_id` from login;")) {
               
                if ($result->rowCount()) {
       
                   
                    while ($row = $result->fetch(PDO::FETCH_NUM)) {
                      
                        if($row[0]==ujloginkod($lg_sha1)){
                            $reg_id=$row[1];
                            if ($result = $db->query("select `passhash` from `reg` where id=$reg_id;")) {
                                if ($result->rowCount()) {
                                    $row = $result->fetch(PDO::FETCH_NUM);
                                    $phmd5 = md5($row[0]);

                                }
                            } else {

                            }
                        }
                    }
                    
                } else {
                }

            } else {
               
            }
            

            $tmp = substr(Base64_encode(hash('sha256', $sinckod)), 0, 80);
            $ujloginkod = ujloginkod(sha1($tmp));
           
            $update = "UPDATE `login` SET `loginkod`='$ujloginkod' WHERE `reg_id`='$reg_id' and `eszkoz_azon`='".$_SERVER['HTTP_USER_AGENT']."';";
            $db->exec($update);
            $db = null;
        }
        if ($dmsk == 1) {

            if ($sinckod == "" || $tk == "") {
                http_response_code(404);
                exit;
            }
            if($reg_id!=0) $sinckod .=$phmd5;
            $kulcs = hashellenor($tk);
            $dmsk_val = dmskkeres($lg_sha1);
            $dmsk_val = secxor($dmsk_val, dmsksec());

            if ($kulcs == null) {
                $replisinc = base64_encode(substr(str_shuffle('0123456789abcdefghijklmnopqrsztyvzu+ABCDEFGHIJKLMNOPQRSTUVZY'), 0, 3));
                $ujkulcs = ujkucs($sinckod, $tk . hash('sha256', $dmsk_val) . $replisinc);
                http_response_code(200);
                echo $replisinc;
                exit();
            }

            $ujkulcs = ujkucs($kulcs, $sinckod . hash('sha256', $dmsk_val));
            echo responsxor('ok', $ujkulcs);

        } else {
            if ($sinckod == "" || $tk == "") {
                http_response_code(404);
            }
            if ($reg_id != 0) $sinckod .= $phmd5;
            $kulcs = hashellenor($tk);
            if ($kulcs == null) {
                $replisinc = base64_encode(substr(str_shuffle('0123456789abcdefghijklmnopqrsztyvzu+ABCDEFGHIJKLMNOPQRSTUVZY'), 0, 3));
                $ujkulcs = ujkucs($sinckod, $tk . $replisinc);
                http_response_code(200);
                echo $replisinc;
                exit();
            }
            $ujkulcs = ujkucs($kulcs, $sinckod);
            echo responsxor('ok', $ujkulcs);

        }

    } else {
        http_response_code(404);

    }
}
