function pinxorencode(pin, mit) {
    mivel = btoa(SHA256(pin)).substr(0, 64);
    valto = 0;
    b = "";
    a = "";
    for (i = 0; i < mit.length; i++) {
        if (mivel.length - 1 < valto) {
            valto = 0;
            mivel = btoa(SHA1(mivel + pin)).substr(0, 38);

        }
        a = (mit.charCodeAt(i) ^ mivel.charCodeAt(valto));
        h = a.toString();
        b = b + h.length + a;
        valto++;
    }
    return b;
}

function pinxordecode(pin, mit) {
    mivel = btoa(SHA256(pin)).substr(0, 64);
    try {
        ato = mit;
    } catch (err) {
        return;
    }
    if (ato == "new") {
        return ato;
    }
    tmp = "";
    valto = 0;

    a = "";
    b = "";
    for (i = 0; i < ato.length; i++) {
        if (mivel.length - 1 < valto) {
            valto = 0;
            mivel = btoa(SHA1(mivel + pin)).substr(0, 38);
        }
        h = ato[i];
        tmp = "";
        for (c = 0; c < h; c++) {
            i++;
            if (i < ato.length) tmp = tmp + ato[i];
        }
        b = parseInt(tmp) ^ mivel.charCodeAt(valto);
        a = a + String.fromCharCode(b);
        valto++;

    }
    return a;
}



$(document).on("click", "#pinvedett", function () {
    if ($('#pinvedett').html() == szovegetide(nyelv, 122)) {
        $('#pt').text('');
        $('#pinvedett').html('PASSWORD');

        $("#feed_back").html(
            szovegetide(nyelv, 123)
        );
        uzenet();
        $('#kflabel').toggle("explode");
        $('#ujuzenet').css('border', '');
        secallapot = 0;
        return;
    }

    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv, 124))
        .dialog({
            modal: true,
            title: szovegetide(nyelv, 125),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Igen: function () {
                    var pass = $('input[name="name"]').val();
                    if (pass.length < 10) {
                        alert(szovegetide(nyelv, 126));
                        $('input[name="name"]').val('');
                        return;
                    }
                    if (checkPwd(pass)) {
                        $('input[name="name"]').val('');
                        return;
                    }
                    $("#feed_back").html(
                        szovegetide(nyelv, 127)
                    );
                    uzenet();
                    $(this).dialog("close");
                    pass = pincsekk(pass);
                    $('#pt').text(pass);
                    $('#pinvedett').html(szovegetide(nyelv, 122));
                    $('#kflabel').toggle("explode");
                    $('#ujuzenet').css('border', '5px solid green');
                    secallapot = 1;
                },
                Nem: function () {
                    $(this).dialog("close");
                    return;
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
});

function pincsekk(pin) {
    i = 0;
    while (pin.length < 64) {
        pin = SHA1(pin) + pin.length + pin.substr(0, i + 1);
        i++;
    }
    return SHA256(pin);
}


var kulcsft;
var filefelt;
var hangfelt;

$(document).on("change", "#verman", function () {

    file = this.files[0];
    merete = file.size;
    if (merete > 1024 * 1024 * 30 || merete < 10240) {
        alert(szovegetide(nyelv, 130));
        $("#verman").val("");
        return;
    }



    var start = 0;
    var stop = file.size - 1;

    var reader = new FileReader();
    var blob = file.slice(start, stop + 1);
    reader.readAsBinaryString(blob);
    reader.onloadend = function (evt) {
        if (evt.target.readyState == FileReader.DONE) {

            dataprint(evt.target.result);

            // console.log(['Read bytes: ', start + 1, ' - ', stop + 1,' of ', (file.size)/1024, ' kbyte file'].join(''));
        }
    };
    neve = this.files[0].name;
    tipusa = this.files[0].type;
    $("#feed_back").html(
        szovegetide(nyelv, 131) +
        '.<br>' + szovegetide(nyelv, 132) + neve + '<br>' + szovegetide(nyelv, 133) + tipusa + '<br>' + szovegetide(nyelv, 134) + (merete / 1024 / 1024).toFixed(3) + szovegetide(nyelv, 135)
    );
    uzenet();
    // alert($('input[type=file]')[0].files[0].name);
    // alert($('input[type=file]')[0].files[0].type);
    // alert($('input[type=file]')[0].files[0].size);
    // alert($('input[type=file]').val());

});
var kulcscsomo = "";

function dataprint(data) {

    for (i = 2048; i < data.length; i = i + 64) {
        kulcscsomo = kulcscsomo + btoa(data.substr(i, 64)).substr(0, 64);
    }
    if (uztip == 2) {
        $(dekodolandoazonosito).val('');

        $(dekodolandoazonosito).val(responsexor(dekodolando, kulcscsomo));
        uztip = 0;
        $("#dekodfile").val("");
    } else if (uztip == 4) {
        kodoltadat = responsexor(dekodolando, kulcscsomo);
        menteselokeszites(kodoltadat, "kapottfile");
        uztip = 0;
        $("#dekodfile").val("");
        kodoltadat = "";
    } else if (uztip == 6) {
        

    } else {

        $('#kflabel').html(szovegetide(nyelv, 136));
        $('#pinvedett').toggle("explode");
        $('#ujuzenet').css('border', '5px solid green');
        secallapot = 2;
    }
    piestop();
}
$('.tooltip').click(function () {
    secdelet();
});

function secdelet() {
    kulcscsomo = "";
    $('#pt').text("");
    $('#ujuzenet').css('border', '');
    secallapot = 0;
    kodoltadat = "";
    binary = "";
    $('#felf').val("");
    uztip = 0;
    titkositott=0;

}
$(document).on("click", "#kflabel", function () {
    if ($("#verman").val() == "");
    else {
        $("#verman").val("");
        $('#kflabel').html(szovegetide(nyelv, 137));
        $("#feed_back").html(
            szovegetide(nyelv, 138)
        );
        uzenet();
        kulcscsomo = "";
        $('#pinvedett').toggle("explode");
        $('#ujuzenet').css('border', '');
        secallapot = 0;
        titkositott=0;
    }
});
$(document).on("click", "#filefel", function () {
    if ($("#felf").val() == "") {

        document.getElementById("felf").click();

    } else {
        $("#felf").val("");
        $('#filefel').html(szovegetide(nyelv, 139));
        $("#feed_back").html(
            szovegetide(nyelv, 140)
        );
        uzenet();
        binary = "";
        $('#hangfelvetel').fadeIn(500);
    }
});
// var kuldeni="";
var binary;
$(document).on("change", '#felf', function () {
    var file;
    if ($('#felf').val() != "") {
        $('#filefel').html(szovegetide(nyelv, 141));

        $('#hangfelvetel').fadeOut(500);
        file = this.files[0];
        merete = file.size;
        if (merete > 1024 * 1024 * 10 || merete < 1024) {
            alert(szovegetide(nyelv, 142));
            $("#felf").val("");
            $('#filefel').html(szovegetide(nyelv, 139));
            return;
        }

        var start = 0;
        var stop = file.size - 1;

        var reader = new FileReader();
        tmp = file.slice(start, stop + 1);
        reader.readAsBinaryString(tmp);
        reader.onloadend = function (evt) {
            if (evt.target.readyState == FileReader.DONE) {

                // console.log(['Read bytes: ', start + 1, ' - ', stop + 1,' of ', (file.size)/1024, ' kbyte file'].join(''));
                binary = evt.target.result;
                // binary=btoa(binary);
                // console.log(binary);
            }
        };
        neve = this.files[0].name;
        tipusa = this.files[0].type;
        $("#feed_back").html(
            szovegetide(nyelv, 143) +
            '.<br>' + szovegetide(nyelv, 132) + neve + '<br>' + szovegetide(nyelv, 133) + tipusa + '<br>' + szovegetide(nyelv, 134) + (merete / 1024 / 1024).toFixed(3) + ' MB'
        );
        uzenet();
        // $('#ujuzenet').append(szovegetide(nyelv,144)+neve);

    } else {
        binary = "";
        $('#hangfelvetel').fadeIn(500);
    }
});

var dekodolando;
var dekodolandoazonosito;
var kodoltadat = "";
var pass;
var valasz = 0;

$(document).on("click", "#dekodol", function () {

    var uzenetazonosito = $('#dekodol').val();
    var kapottuzenetszovege = kodoltadat;
    dekodolando = kodoltadat; // kapottuzenetszovege.substr(1, kapottuzenetszovege.length - 1);
    dekodolandoazonosito = '#kapottuzenetszovege' + uzenetazonosito;
    if (uztip == 1) {
        $('<div></div>').appendTo('body')
            .html(szovegetide(nyelv, 145))
            .dialog({
                modal: true,
                title: szovegetide(nyelv, 146),
                zIndex: 10000,
                autoOpen: true,
                width: 'auto',
                resizable: false,
                buttons: {
                    Igen: function () {
                        var pass = $('input[name="name"]').val();
                        if (checkPwd(pass)) {
                            $('input[name="name"]').val('');
                            return;
                        }

                        $(this).dialog("close");

                        // $('#pt').html();
                        $('#kapottuzenetszovege' + uzenetazonosito).val(pinxordecode(pincsekk(pass), kapottuzenetszovege));
                        // $('#pt').text('');
                        $('#dekodol').prop("disabled", true);
                        $('#dekodtooltip').text(szovegetide(nyelv, 147));
                    },
                    Nem: function () {
                        $(this).dialog("close");
                        // $('#dekodolom').css('display', 'none');
                        return;
                    }
                },
                close: function (event, ui) {
                    $(this).remove();
                }
            });
    } else if (uztip == 2) {
        document.getElementById("dekodfile").click();

    } else if (uztip == 4) {
        //ve kodolt file
        //  console.log('ve k file');

        document.getElementById("dekodfile").click();

    } else if (uztip == 5) {


        //pin kodolt file
        $('<div></div>').appendTo('body')
            .html(szovegetide(nyelv, 148))
            .dialog({
                modal: true,
                title: szovegetide(nyelv, 146),
                zIndex: 10000,
                autoOpen: true,
                width: 'auto',
                resizable: false,
                buttons: {
                    Igen: function () {
                        pass = $('input[name="name"]').val();
                        if (checkPwd(pass)) {
                            $('input[name="name"]').val('');
                            return;
                        }
                        valasz = 1;

                        $(this).dialog("close");
                        piestart();
                        setTimeout(dekodolom, 2);

                    },
                    Nem: function () {

                        $(this).dialog("close");
                        // $('#dekodolom').css('display', 'none');
                        return;
                    }
                },
                close: function (event, ui) {
                    $(this).remove();


                }
            });

    } else if (uztip == 6) {
        menteselokeszites(kodoltadat, "kapottfile");
        uztip = 0;
        $("#dekodfile").val("");
        kodoltadat = "";

    }
});

function dekodolom() {
    if (valasz == 1) {

        kodoltadat = pinxordecode(pincsekk(pass), kodoltadat);
        menteselokeszites(kodoltadat, "kapottfile");
        uztip = 0;
        kodoltadat = "";
        $("#dekodfile").val("");
        // $('#pt').text('');
        $('#dekodol').prop("disabled", true);
        $('#dekodtooltip').text(szovegetide(nyelv, 149));
    }
    pass = "";
    valasz = 0;
}

$(document).on("cut copy paste", ".uzenettorzs", function (e) {
    e.preventDefault();
});
$(document).on("cut copy", "#ujuzenet", function (e) {
    e.preventDefault();
});
$(document).on("change", "#dekodfile", function () {
    piestart();
    ja = 1;
    file = this.files[0];
    merete = file.size;
    // files = document.getElementById('dekodfile').files;
    // merete = $('input[type=file]')[0].files[0].size;
    if (merete > 1024 * 1024 * 30 || merete < 10240) {
        alert(szovegetide(nyelv, 130));
        $("#dekodfile").val("");
        piestop();
        return;
    }


    // file = files[0];
    start = 0;
    stop = file.size - 1;

    reader = new FileReader();
    blob = file.slice(start, stop + 1);
    reader.readAsBinaryString(blob);
    reader.onloadend = function (evt) {
        if (evt.target.readyState == FileReader.DONE) {
            dataprint(evt.target.result);
        }
    };
    neve = this.files[0].name;
    tipusa = this.files[0].type;

    $("#feed_back").html(
        szovegetide(nyelv, 150) +
        '.<br>' + szovegetide(nyelv, 132) + neve + '<br>' + szovegetide(nyelv, 133) + tipusa + '<br>' + szovegetide(nyelv, 134) + (merete / 1024 / 1024).toFixed(3) + ' MB'
    );
    uzenet();

    $('#dekodol').prop("disabled", true);
    $('#dekodtooltip').text(szovegetide(nyelv, 151));
});
var f;

$('#ks').click(function () {
    if ($('#ofpng').css('display') == 'inline') return;
    if ($('#kszkibe').text() == 'be') {
        $('#kszkibe').text('ki');
        stopkulcsszinkron();
        f = setTimeout(figyelem, 60000);
        $('#ks').attr('src', 'ico/ki.png');
        // a=window.location.href;
        // console.log(a.length);
        // var b;
        // var a = SHA256(a);
        // var c = SHA256($('#logincode').text());
        // if ($('#dmsk').text() == '') b = SHA1($('#logincode').text());
        // else b=$('#dmsk').text();
        // d = xor((a + b + c), xor(SHA1(a),c,"secret"), "secret");
        // while (d.length < 120440){
        //     d += xor(d, xor(SHA1(d), c, "secret"), "secret");
        // }
        // console.log(d);
        // console.log(d.length);
        return;
    }
    if ($('#kszkibe').text() == 'ki') {
        $('#kszkibe').text('be');
        startkulcsszinkron();
        clearTimeout(f);
        kulcsszinkron();
        $('#ks').attr('src', 'ico/burn.png');
        // d="";
        return;
    }

});

function figyelem() {
    alert(szovegetide(nyelv, 152));
}

function saveAs(blob, fileName) {
    var url = window.URL.createObjectURL(blob);

    var anchorElem = document.createElement("a");
    anchorElem.style = "display: none";
    anchorElem.href = url;
    anchorElem.download = fileName;

    document.body.appendChild(anchorElem);
    anchorElem.click();

    document.body.removeChild(anchorElem);

    setTimeout(function () {
        window.URL.revokeObjectURL(url);
    }, 1000);
}

function menteselokeszites(adat, fajlnev) {
    piestop();
    // convert base64 string to byte array
    var byteCharacters = adat;
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);


    var blob1 = new Blob([byteArray], {
        type: "application/octet-stream"
    });
    //---------------------
    var fileReader = new FileReader();
    var header = "";
    fileReader.readAsArrayBuffer(blob1);
    fileReader.onloadend = function (e) {
        var arr = (new Uint8Array(e.target.result)).subarray(0, 4);

        for (var i = 0; i < arr.length; i++) {
            header += arr[i].toString(16);
        }
        console.log(header);
        kiterjesztese(header, blob1, fajlnev);
        console.log(kiterjesztes);


    };
    //------------------------------


}

function kiterjesztese(header, blob1, fajlnev) {
    kiterjesztes = "";
    switch (header) {
        case "89504e47":
            type = "image/png";
            kiterjesztes = "png";
            break;
        case "47494638":
            type = "image/gif";
            kiterjesztes = "gif";
            break;
        case "ffd8ffe0":
        case "ffd8ffe1":
        case "ffd8ffe2":
        case "ffd8ffe3":
        case "ffd8ffe8":
            type = "image/jpeg";
            kiterjesztes = "jpg";
            break;
        case "4f676753":
            type = "application/ogg";
            kiterjesztes = "ogg";
            break;
        case "25504446":
            type = "application/pdf";
            kiterjesztes = "pdf";
            break;
        case "fffb7844":
            type = "audio/mpeg";
            kiterjesztes = "mp3";
            break;
        case "000001ba":
            type = "video/mpg";
            kiterjesztes = "mpg";
            break;
        case "000001b3":
        case "000001b1":
        case "000001b2":
        case "000001b3":
        case "000001b5":
        case "000001b6":
        case "000001b7":
        case "000001b8":
        case "000001b9":
            type = "video/mpeg";
            kiterjesztes = "mpeg";
            break;
        case "00000100":
            type = "image/icon";
            kiterjesztes = "ico";
            break;
        case "0001000":
            type = "font";
            kiterjesztes = "ttf";
            break;
        case "38425053":
            type = "fotoshop";
            kiterjesztes = "psd";
            break;
        case "3c3f786d":
            type = "<? x";
            kiterjesztes = "xml";
            break;
        case "464c5601":
            type = "video/flash";
            kiterjesztes = "flv";
            break;
        case "4d4d002a":
        case "4d4d002b":
            type = "image/tif";
            kiterjesztes = "tif";
            break;
        case "504b0304":
        case "504b0506":
        case "504b0708":
            type = "pkzip-verziok";
            kiterjesztes = "pkzip";
            break;
        case "504b34":
            type = "zip";
            kiterjesztes = "zip";
            break;
        case "52617221":
            type = "Rar";
            kiterjesztes = "rar";
            break;
        case "53434d49":
            type = "Bitmap";
            kiterjesztes = "img";
            break;
        case "edabeedb":
            type = "redhatpackage";
            kiterjesztes = "rpm";
            break;
        case "cafebabe":
            type = "Java class file";
            kiterjesztes = "class";
            break;
        case "25215053":
            type = "PostScript";
            kiterjesztes = "ps";
            break;
        case "4d546864":
            type = "Midi sound file";
            kiterjesztes = "midi";
            break;
        case "78617221":
            type = "Xar archivum";
            kiterjesztes = "xar";
            break;
        case "4d4c5649":
            type = "Magic Lantern video file";
            kiterjesztes = "mlv";
            break;
        case "4d534346":
            type = "Microsoft cabinet file";
            kiterjesztes = "cab";
            break;
        case "1a45dfa3":
            type = "WebM";
            kiterjesztes = "mkv";
            break;
        case "0061736d":
            type = "WebAssembly binary format";
            kiterjesztes = "wasm";
            break;
        case "00018":
        case "0001c":
        case "00014":
            type = "video";
            kiterjesztes = "mp4";
            break;
        case "d7cdc69a":
            type = "windows-meta";
            kiterjesztes = "wmf";
            break;
        case "52494646":
            type = "video-avi";
            kiterjesztes = "avi";
            break;
        case "6d6f6f76":
            type = "video-mov";
            kiterjesztes = "mov";
            break;
        default:
            type = "unknown"; // Or you can use the blob.type as fallback
            break;
    }
    if (header.substr(0, 4) == "fffb" || header.substr(0, 6) == "494433") {
        type = "audio/mpeg";
        kiterjesztes = "mp3";
    } else if (header.substr(0, 6) == "425a68") {
        type = "application/BZH";
        kiterjesztes = "bz2";

    } else if (header.substr(0, 4) == "4d5a") {
        type = "application/windows";
        kiterjesztes = "exe";
    }

    //  console.log(kiterjesztes);
    //  console.log(type);


    var fileName1 = fajlnev + '.' + kiterjesztes;
    if (kiterjesztes == "mp3") {
        url = URL.createObjectURL(blob1);
        au = document.createElement('audio');
        au.autoplay = 'autoplay';
        au.type = 'audio/mpeg';
        li = document.createElement('li');
        link = document.createElement('a');
        au.controls = true;
        au.src = url;

        li.appendChild(au);
        li.appendChild(link);
        $('.valaszli').append(szovegetide(nyelv, 252));
        $('.valaszli').append(li);

    } else if (kiterjesztes == "ogg") {
        url = URL.createObjectURL(blob1);
        au = document.createElement('audio');
        au.autoplay = 'autoplay';
        au.type = 'audio/ogg';
        li = document.createElement('li');
        link = document.createElement('a');
        au.controls = true;
        au.src = url;

        li.appendChild(au);
        li.appendChild(link);
        $('.valaszli').append(szovegetide(nyelv, 252));
        $('.valaszli').append(li);

    } else if (kiterjesztes == "mp4") {
        url = URL.createObjectURL(blob1);
        au = document.createElement('video');
        au.autoplay = 'autoplay';
        //    au.loop = 'loop';
        au.type = 'video/mp4';
        li = document.createElement('li');
        link = document.createElement('a');
        au.controls = true;
        au.src = url;

        li.appendChild(au);
        li.appendChild(link);
        $('.container').html('<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>');
        $('.container').append(li);


    } else if (kiterjesztes == "jpg" || kiterjesztes == "gif" || kiterjesztes == "png" || kiterjesztes == "bmp") {
        url = URL.createObjectURL(blob1);
        au = document.createElement('img');
        //au.autoplay = 'autoplay';
        //    au.loop = 'loop';
        au.type = 'image/image';
        li = document.createElement('li');
        link = document.createElement('a');
        //au.controls = true;
        au.src = url;

        li.appendChild(au);
        li.appendChild(link);
        $('.container').html('');
        $('.container').append(li);

    }
    saveAs(blob1, fileName1);


}

$('#ks').contextmenu(function () {

    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv, 244) + '<br><br><input type="number" style="color:yellow;background:black" min="15" max="110" value="25" step="5" style="z-index:10000" name="time">')
        .dialog({
            modal: true,
            title: szovegetide(nyelv, 245),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Igen: function () {


                    ujido = $('input[name="time"]').val();
                    ujkulcszinkronido(ujido);

                    $(this).dialog("close");

                },
                Nem: function () {

                    $(this).dialog("close");
                    return;
                }
            },
            close: function (event, ui) {
                $(this).remove();


            }
        });
});

$(document).on('contextmenu', '#messimg', function () {

    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv, 246) + '<br><br><input type="number" style="color:yellow;background:black" min="10" max="1800" value="15" step="5" style="z-index:10000" name="time">')
        .dialog({
            modal: true,
            title: szovegetide(nyelv, 247),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Igen: function () {


                    ujido = $('input[name="time"]').val();
                    uzenetellenorzes(ujido);

                    $(this).dialog("close");

                },
                Nem: function () {

                    $(this).dialog("close");
                    return;
                }
            },
            close: function (event, ui) {
                $(this).remove();


            }
        });
});

function ujkulcszinkronido(ujido) {
    stopkulcsszinkron();
    $('#sincronmp').text(ujido);
    startkulcsszinkron();
}

function uzenetellenorzes(ujido) {
    clearInterval(uzenetellenor);
    uzenetellenor = setInterval(uzenetcsekk, 1000 * ujido);
}

$(document).contextmenu(function () {
    return false;
});
var idozarvar = 5;
var idleTime = 0;
$(document).ready(function () {

    var idleInterval = setInterval(timerIncrement, 60000);


    $(this).mousemove(function (e) {

        idleTime = 0;

    });
    $(this).keypress(function (e) {

        idleTime = 0;
    });
});
var nyitott = 0;

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime >= idozarvar) {
        if (nyitott == 0) idozar();
    }
}


function idozar() {
    nyitott = 1;
    $('#div1').hide();
    pass = "";
    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv, 248) + '<br><br><input type="password" style="color:yellow;background:black"  style="z-index:100100" name="time">')
        .dialog({
            modal: true,
            title: szovegetide(nyelv, 249),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                OK: function () {
                    pass = $('input[name="time"]').val();
                    nyitvagykidob(pass);
                    nyitott = 0;
                    $(this).dialog("close");
                }
            },
            close: function (event, ui) {
                nyitott = 0;
                if (pass == '') kilepes();
                $(this).remove();
            }
        });
}

function nyitvagykidob(pass) {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }

    logincode = SHA1(ego);

    pass = xor(pass, dmsk240B, "secret");
    tk = dmsk240B;
    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(pass, 1);
    adatforgalom(logincode, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 9,
            sinc: pass,
            logincode: logincode,
            tk: tk
        },
        error: function () {
            iconoffline();
            $('#szinkron').text('0');
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == 0101) {
                nyitott = 0;
                $('#div1').show();
            } else {
                kilepes();
            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });

}
$(document).on("change", '#cb_titkositott', function () {
    martikositva();
  
});

var titkositott = 0;

function martikositva(){
    if ($('#cb_titkositott')[0].checked) {
        titkositott = 1;
        $('#pinvedett').fadeOut();
        $('#kflabel').fadeOut();
    }
    else {
        titkositott = 0;
        $('#pinvedett').fadeIn();
        $('#kflabel').fadeIn();
    }
}