var uzenetellenor;

var meta = document.createElement('meta');
meta.name = "referrer";
meta.content = "no-referrer";
document.getElementsByTagName('head')[0].appendChild(meta);


$(document).ready(function () {
    setTimeout(uzenetcsekk, 5000);
    uzenetellenor = setInterval(
        uzenetcsekk,
        1000 * parseInt($("#allapotjelzo").text())
    );
});

function uzenetkuldesmenu() {
    uzenettorlese();
    $("#div1").html(szovegetide(nyelv, 20));
    $("#vegrehajt").css("visibility", "visible");
    if (location.protocol != 'https:') {
        $('#nemtitok').css('display', 'none');
    }
    regisztracio();
    $("#allapotjelzo").text("kuldes");
}

function taglistaoffline() {
    if ($('#tagid').html() != '') {
        $('#tagidlist').html(LZString.decompressFromUTF16($('#tagid').html()));
        $("#feed_back").html(
            szovegetide(nyelv, 22)
        );
        uzenet();
        return 1;
    } else {
        return 0;
    }
}

function openFullscreen() {
    fullscreen = 1;
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    } else if (elem.mozRequestFullScreen) { /* Firefox */
        elem.mozRequestFullScreen();
    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera? */
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) { /* IE/Edge */
        elem.msRequestFullscreen();
    }
}
$('#full').click(function () {
    if (fullscreen == 0) {
        openFullscreen();
        $('#full').html(szovegetide(nyelv, 1));
    } else {
        closeFullscreen();
        $('#full').html(szovegetide(nyelv, 2));
    }
});

function closeFullscreen() {
    fullscreen = 0;
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) { /* Firefox */
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera? */
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) { /* IE/Edge */
        document.msExitFullscreen();
    }
}

function ekezeteskodcserevissza(str) {
    a = str.replace(/&aacute;/g, "á");
    b = a.replace(/&eacute;/g, "é");
    c = b.replace(/&iacute;/g, "í");
    d = c.replace(/&oacute;/g, "ó");
    e = d.replace(/&ouml;/g, "ö");
    f = e.replace(/&#337;/g, "ő");
    g = f.replace(/&uacute;/g, "ú");
    h = g.replace(/&uuml;/g, "ü");
    i = h.replace(/&#369;/g, "ű");
    j = i.replace(/&Aacute;/g, "Á");
    k = j.replace(/&Eacute;/g, "É");
    l = k.replace(/&Iacute;/g, "Í");
    m = l.replace(/&Oacute;/g, "Ó");
    n = m.replace(/&Ouml;/g, "Ö");
    o = n.replace(/&#336;/g, "Ő");
    p = o.replace(/&Uacute;/g, "Ú");
    q = p.replace(/&Uuml;/g, "Ü");
    r = q.replace(/&#368;/g, "Ű");
    return r;
}

function uzenetmentese(klt, kinek, lejarat, uzenetszoveg) {
    kltarr.push(klt);
    kinekarr.push(kinek);
    lejaratarr.push(lejarat);
    uzenetszovegarr.push(LZString.compressToUTF16(uzenetszoveg));
    $('#pt').text('');
    kulcscsomo = "";
}

function ajaxprogressreset() {
    $('.progress').css({
        width: 0 + '%'
    });
    $('.progress').removeClass('hide');
    $('#bar').text('');
}
// function offline(lejarat, uzenetszoveg, kinek, ki, klt, tk) {
//     if (klt == 0) {
//         uzenetszoveg = responsexor(uzenetszoveg, tk);
//     }

// }
function uzenetszovegmentese() {
    if ($('#ujuzenet').val() != '') {
        if (secallapot == 0) $('#mentettuzenet').text(LZString.compressToUTF16($('#ujuzenet').val()));
    }
}

function uzenetolvasasmenu() {
    uzenettorlese();
    $("#div1").html(szovegetide(nyelv, 29));
    $("#vegrehajt").css("visibility", "hidden");
    regisztracio();
    $("#allapotjelzo").text("olvasas");
}

function dmsksetup() {
    uzenettorlese();
    $("#div1").html(szovegetide(nyelv, 40));
    $("#vegrehajt").css("visibility", "visible");
    regisztracio();
    $('#allapotjelzo').text('DMSK');
}

function valaszirasa(cim, mirevalasz, uzenetazonosito) {
    ka = $('#ka').text();
    mirevalasz = mirevalasz + szovegetide(nyelv, 52);
    uzenettorlese();
    $("#div1").html(szovegetide(nyelv, 53) + cim + szovegetide(nyelv, 153) + filefelt + szovegetide(nyelv, 154) + mirevalasz + szovegetide(nyelv, 155) + kulcsft + szovegetide(nyelv, 156));
    $("#vegrehajt").css("visibility", "visible");
    regisztracio();
    $("#allapotjelzo").text("kuldes");
}

function tovabbitas(kapottuzenetszovege) {
    uzenettorlese();
    $("#div1").html(szovegetide(nyelv, 54));
    $("#vegrehajt").css("visibility", "visible");
    regisztracio();
    $("#allapotjelzo").text("kuldes");
    uzenetazonosito = null;
}

function messpillog() {
    for (i = 0; i < 20; i++) {
        $('#messimg').fadeToggle(600);
    }
}

function DMSK() {
    $("#dialogModal").dialog('open');
}

function kuldes413(kinekor, lejarator, uzenetszoveg, klt) {
    // kulcsszinkron();

    a = uzenetszoveg.length;

    if (a < 500000) {
        alert(szovegetide(nyelv, 102));
        return 1;
    }
    var j = 1;
    var mettol = 0;
    x = parseInt(a / 500000);

    while (j > 0) {

        if (a - mettol >= 500000) {
            darabok.push(uzenetszoveg.substr(mettol, 500000));

        } else {
            darabok.push(uzenetszoveg.substr(mettol));
            j = 0;

        }
        mettol += 500000;
    }
    $("#feed_back").html(
        szovegetide(nyelv, 222)
    );
    uzenet();
    kuldtemp(kinekor, lejarator, klt, 0);


}

function kuldtemp(kinekor, lejarator, klt, honnan) {

    if (honnan == 0) {
        sinc_number = Math.floor(Math.random() * 10000000);
        sinc = sinc_number.toString() + kinekor;
        csomagazon = SHA1(sinc);
    }
    csomagszam = darabok.length;

    if (csomagszam == 0) {
        darabok = [];
        csomagazon = "";
        return;
    }
    darabszoveg = darabok.shift();
    feltemp(kinekor, lejarator, darabszoveg, csomagszam, klt);
}

$(document).on("click", "#vegrehajt", function () {
    if ($('#allapotjelzo').text() == "kuldes") {
        piestart();
        setTimeout(vegrehajtas, 500);
    } else {
        vegrehajtas();
    }
});

$(document).on("click", ".a2", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", ".a3", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", ".a4", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", ".a5", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", ".a6", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", ".a7", function () {
    var value = $(this).text().toLowerCase();
    $("#listamess li").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
});
$(document).on("click", "#jkk", function () {
    copyToClipboard(juszlkk);
    $("#feed_back").html(
        szovegetide(nyelv, 253)
    );
    uzenet();

});

function copyToClipboard(text) {
    var dummy = document.createElement("input");
    document.body.appendChild(dummy);
    dummy.setAttribute('value', text);
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}

function vegrehajtas() {

    if ($("#allapotjelzo").text() == "rt") {
        $('<div></div>').appendTo('body')
            .html(szovegetide(nyelv, 70))
            .dialog({
                modal: true,
                title: szovegetide(nyelv, 69),
                zIndex: 10000,
                autoOpen: true,
                width: 'auto',
                resizable: false,
                buttons: {
                    Igen: function () {
                        var pass = $('input[name="name"]').val();
                        regisztraciotorlese(SHA1(ego), pass);
                        $(this).dialog("close");
                    },
                    Nem: function () {
                        $(this).dialog("close");
                        return;
                    }
                },
                close: function (event, ui) {
                    $(this).remove();
                }
            });
    }
    if ($('#allapotjelzo').text() == "pw") {
        jelszomodositas();
    }
    if ($('#allapotjelzo').text() == "DMSK") {
        dmsksetuprun();
    }

    if ($('#allapotjelzo').text() == "kuldes") {
        piestart();
        if (titkositott == 1 && binary != "") {
            feltolte();
            if ($('#ujuzenet').val().length != 0) {
                secallapot=0;
                uzenetkuldes();
                }
            else {
                $('#allapotjelzo').text('uzenetlista');
                uzenetlista(0);
                window.scrollTo(0, 0);
            }
            return;
        }
        
        szoveghossza = LZString.compressToBase64($('#ujuzenet').val());
        if (secallapot == 0) {
            korlat = xor(szoveghossza, dmsk240B, "secret").length;
            // console.log('kodolot szoveg hossza: ' + korlat / 1024 + ' kb, korlát: ' + 120440/1024 +' kb');
            if (korlat > 120440) {
                $("#feed_back").html(
                    szovegetide(nyelv, 71)
                );
                uzenet();
                piestop();
                return;
            }
        }
        if (secallapot == 0) {
            if (binary != "") {
                // console.log(binary);
                $("#feed_back").html(
                    szovegetide(nyelv, 72)
                );
                uzenet();
                piestop();
                return;
            }
        }

        if (secallapot == 2) {
            if (szoveghossza.length > kulcscsomo.length) {
                $("#feed_back").html(
                    szovegetide(nyelv, 73)
                );
                uzenet();
                piestop();
                return;
            } else if (binary != "" && binary.length > kulcscsomo.length) {
                $("#feed_back").html(
                    szovegetide(nyelv, 74)
                );
                uzenet();
                piestop();
                return;
            }
        }


        if (binary != "") {
            onlinechek();
            if (offlinech == 1) {
                iconoffline();
                alert(szovegetide(nyelv, 243));
                piestop();
                return;
            }
            piestart();
            if (secallapot == 1) binary = pinxorencode($('#pt').text(), binary);
            if (secallapot == 2) binary = xor(binary, kulcscsomo, "secret");

            feltolte();


        }
        if ($('#ujuzenet').val().length == 0 && binary == "") {
            $("#feed_back").html(
                szovegetide(nyelv, 24)
            );
            uzenet();
            piestop();
            return;
        }
        if ($('#ujuzenet').val().length != 0) uzenetkuldes();
        else {
            $('#allapotjelzo').text('uzenetlista');
            uzenetlista(0);
            window.scrollTo(0, 0);
        }
    }
}

function kuldeseloellenorzes() {
    var radio = $("input[name=kuldes]");
    if (titkositott == 1 && binary != "") return 1;
    if (secallapot == 0 && binary != "") {
        $('#pinvedett').effect("shake");
        $('#kflabel').effect("shake");
        return 0;
    } else if ($('#ujuzenet').val().length == 0 && binary == "") {
        $('#ujuzenet').effect("shake");
        return 0;
    } else if (kulcscsomo.length < binary.length && secallapot == 2) {
        $('#kflabel').effect("shake");
        return 0;
    } else if (secallapot == 1 && $('#pt').text() == '') {
        $('#pinvedett').effect("shake");
        return 0;
    } else if (radio.filter(":checked").val() != 'all' && $('#taglista').val() == '') {
        $('#taglista').effect("shake");
        return 0;
    } else return 1;
}

function pwmodepreesec() {
    if ($('#regijelszo').val() == '' || $('#passa').val() == '' || $('#passb').val() == '') {
        if ($('#regijelszo').val() == '') $('#regijelszo').effect("shake");
        if ($('#passa').val() == '') $('#passa').effect("shake");
        if ($('#passb').val() == '') $('#passb').effect("shake");
        return 0;
    }
}

$(document).on("mouseenter", "#vegrehajt", function () {
    if ($('#allapotjelzo').text() == "DMSK") {
        if (dmsk_on() == 0) {
            hianyos();
            $('#dmskinfo').effect("shake");
            return;
        }
    } else if ($('#allapotjelzo').text() == "kuldes") {
        if (kuldeseloellenorzes() == 0) {
            hianyos();
            return;
        }
    } else if ($('#allapotjelzo').text() == "pw") {
        if (pwmodepreesec() == 0) {
            hianyos();
            return;
        }
    }
    $('#vegrehajt').css('background-color', 'green').css('opacity', '1');
});

function hianyos() {
    $('#vegrehajt').css('background-color', 'red').css('opacity', '1');
}

$(document).on("mouseleave", "#vegrehajt", function () {
    $('#vegrehajt').css('background-color', '').css('opacity', '0.8');
});

$(document).on("click", "#hangfelvetel", function () {
    $('#hanguzenet').css('display', 'inline');
});