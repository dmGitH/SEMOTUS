function xor(mit, mivel, honnan) {
   
    valto = 0;
    if (honnan == "secret") {
        b = "";
        a = "";
        for (i = 0; i < mit.length; i++) {
            if (mivel.length - 1 < valto) {
                valto = 0;
                mivel=btoa(SHA256(mivel)).substr(0,64);
               
            }
            a = (mit.charCodeAt(i) ^ mivel.charCodeAt(valto));
            h = a.toString();
            b = b + h.length + a;
            valto++;
        }
        return encompdmsk(b);
    }
}

function responsexor(mit, mivel) {
    
    mit = serverhibauzenetlevagasa(mit);
    mit = decompdmsk(mit);
    try {
        ato = mit;
    } catch (err) {
        return;
    }
    if (ato == "new") {
        return ato;
    }
    var tmp = "";
    var valto = 0;
    var a = "";
    var b = "";
    for (i = 0; i < ato.length; i++) {
        if (mivel.length - 1 < valto) {
            valto = 0;
             mivel = btoa(SHA256(mivel)).substr(0, 64);
            
        }
        h = ato[i];
        tmp = "";
        for (c = 0; c < h; c++) {
            i++;
            if (i < ato.length) tmp = tmp + ato[i]
        }
        b = parseInt(tmp) ^ mivel.charCodeAt(valto);
        a = a + String.fromCharCode(b);
        valto++;
    }
    return a;
}
function secret(kulcs,so) {
    szinkromszam++;
    kulcs += so;
    kulcs = btoa(SHA1(kulcs)).substr(0, 40);
    for (i = 0; i < 5; i++) {
        kulcs += btoa(SHA1(kulcs + so)).substr(0, 40);
    }
    
    dmsk240B=kulcs;
   
    $('#szszam').html(szinkromszam);
    $('#szhiba').html(szinkronhiba);
   
}

function encompdmsk(mit) {
    
    tmp = "";
    eredmeny = "";
    hossz = mit.length;
    for (i = 0; i < hossz; i++) {
        if (i + 1 == hossz) {

            tmp = mit[i];
        } else {
            if (mit[i] == '0') tmp = '0';
            else {
                tmp += mit[i] + mit[i + 1];
                i++;
            }
        }

        eredmeny += String.fromCharCode(parseInt(tmp) + 64);
        tmp = "";
    }
   
    return btoa(eredmeny);
  
}

function decompdmsk(mitt) {
    mit = atob(mitt);
    hossz = mit.length;
    eredmeny = "";
    for (i = 0; i < hossz; i++) {
        tmp = (mit.charCodeAt(i)) - 64;
        if (tmp == 0) eredmeny += '0';
        else eredmeny += tmp;
    }
    return eredmeny;
}

