var adminmenustatusz=0;
function admin(){
   
     $("#kijelentkezes").slideToggle(600);
     $("#uzenetkuldes").slideToggle(600);
     $("#beallitasok").slideToggle(600);
     $("#uzenetek").slideToggle(600);
     $("#dmsk_setup").slideToggle(600);
     
    if(adminmenustatusz==0){
     
        
         $('#admin').slideToggle(600);
          $('#admin').slideToggle(600);
          $('#allapotjelzo').text('admin');
          adminmenustatusz=1
        adminmenube();
    }
    else {
         $('#admin').hide();
         $('#admin').slideToggle(600);
        
         $('#allapotjelzo').text('admin');
         adminmenustatusz=0;
        adminmenuki();
    }
}

function adminmenube(){
     $("#div1").html(
         '<br><div id="page-wrapper"><h1>'+szovegetide(nyelv,157)+'</h1></div><button class="gombok" id="felhasznalok">'+szovegetide(nyelv,158)+'</button>'+
         '<button class="gombok" id="phpinfo">PHPINFO</button>'+
         '<button class="gombok" id="databasecliner">'+szovegetide(nyelv,159)+'</button>'+
         '<button class="gombok" id="silenton">Stop!</button>'+
         '<button class="gombok" id="silentoff">Start!</button>'+
         '<button class="gombok" id="threadinf">Thread inf</button>'

     );
     regisztracio();
}
function adminmenuki(){
    $('#allapotjelzo').text('uzenetlista');
     $("#vegrehajt").css("visibility", "hidden");
     uzenetlista(0);
     regisztracio();
}
function felhasznalokbetoltese(){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    var lc = SHA1(ego);
    var tk = dmsk240B;
    tk = SHA1(tk);
   
    secret(dmsk240B, tk);
    adatforgalom(tk, 1);
    adatforgalom(lc, 1);
    piestart();
    $('#szinkron').text('1');
     $.ajax({
         type: "POST",
         url: elosztas(),
         data: {
             go: 2,
             lc: lc,
             tk: tk
         },
         
         success: function (data) {
             adatforgalom(data.length, 0);
             data = responsexor(data, dmsk240B);
              $("#div1").html(
                  '<div id="page-wrapper"><h1>'+szovegetide(nyelv,161)+'</h1></div>'+
                  '<button class="gombok" id="avissz">'+szovegetide(nyelv,160)+'</button>'+data
                  
              );
              $('.a60').prepend(szovegetide(nyelv, 225));
              $('.a61').prepend(szovegetide(nyelv, 226));
              $('.a62').prepend(szovegetide(nyelv, 227));
              $('.a63').prepend(szovegetide(nyelv, 228));
              $('.a64').prepend(szovegetide(nyelv, 229));
              $('.a65').prepend(szovegetide(nyelv, 230));
              $('.a66').prepend(szovegetide(nyelv, 231));
              $('.a67').prepend(szovegetide(nyelv, 232));
              $('.a68').prepend(szovegetide(nyelv, 233));
              $('.a69').prepend(szovegetide(nyelv, 234));
              $('.a70').prepend(szovegetide(nyelv, 235));
              $('.a71').prepend(szovegetide(nyelv, 236));
              $('.a72').prepend(szovegetide(nyelv, 237));
              $('.a73').prepend(szovegetide(nyelv, 238));
              $('.a74').prepend(szovegetide(nyelv, 239));
              regisztracio();
         },
         complete: function (data, xhr) {
             $('#szinkron').text('0');
                 statuszkodlog(data.status, xhr);
                 hibakodok(data.status);
             piestop();
         }
     });

}

function phpinfo(){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
     var lc = ego;
     var tk = dmsk240B;
     tk = SHA1(tk);
     secret(dmsk240B, tk);
     adatforgalom(tk, 1);
     piestart();
     $('#szinkron').text('1');
     $.ajax({
         type: "POST",
         url:elosztas(),
         data: {
            go:11,
             tk: tk
         },
         
         success: function (data) {
             adatforgalom(data.length, 0);
             $("#div1").html(
                 '<button class="gombok" id="avissz">'+szovegetide(nyelv,160)+'</button><br>'+data
             );
             regisztracio();
         },
         complete: function (data, xhr) {
             $('#szinkron').text('0');
                 statuszkodlog(data.status, xhr);
                 hibakodok(data.status);
             piestop();
         }
     });
}

function skdarabol(statuszkod){
    hol=statuszkod.indexOf('_');
    id = statuszkod.substr(0,hol);
    statusz = statuszkod.substr(hol+1);
    return new Array(id,statusz);
}


function igenmodositom(id,statusz,p){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
        if(p=='')return;
        p = xor(p, dmsk240B, "secret");
        lc = SHA1(ego);
        
        sinc = id;
        tkk = dmsk240B;
        tk = SHA1(tkk);
        st = statusz;
        // sinc = SHA1(sinc);
        // st = SHA1(st);
        sinc=xor(sinc, tkk, "secret");
       
        st=xor(st, tkk, "secret");
       
        secret(dmsk240B, tk + lc);
        adatforgalom(tk, 1);
        adatforgalom(lc, 1);
        adatforgalom(st, 1);
        adatforgalom(sinc, 1);
        adatforgalom(p, 1);
        piestart();
        $('#szinkron').text('1');
        $.ajax({
            type: "POST",
            url: elosztas(),
            data: {
                go: 23,
                tk: tk,
                lc: lc,
                st: st,
                sinc: sinc,
                p: p
            },
            
            success: function (data) {
                adatforgalom(data.length, 0);
                if (data == 3) window.location.replace('index.php');
                felhasznalokbetoltese();
            },
            complete: function (data, xhr) {
                $('#szinkron').text('0');
                    statuszkodlog(data.status, xhr);
                    hibakodok(data.status);
                piestop();
            }
        });
}
function igentorlom(id, statusz, p) {
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
        if(p=='')return;
        p = xor(p, dmsk240B, "secret");
        lc = SHA1(ego);
        
        sinc = id;
        tkk = dmsk240B;
        tk = SHA1(tkk);
       
        st = statusz;
        // sinc = SHA1(sinc);
        // st = SHA1(st);
        sinc=xor(sinc, tkk, "secret");
       
        st=xor(st, tkk, "secret");
       
        secret(dmsk240B, tk + lc);
        adatforgalom(tk, 1);
        adatforgalom(lc, 1);
        adatforgalom(st, 1);
        adatforgalom(sinc, 1);
        adatforgalom(p, 1);
        piestart();
        $('#szinkron').text('1');
        $.ajax({
            type: "POST",
            url: elosztas(),
            data: {
                go: 18,
                tk: tk,
                lc: lc,
                st: st,
                sinc: sinc,
                p: p
            },
            
            success: function (data) {
                adatforgalom(data.length, 0);
                if (data == 3) window.location.replace('index.php');
                felhasznalokbetoltese();
            },
            complete: function (data, xhr) {
                $('#szinkron').text('0');
                    statuszkodlog(data.status, xhr);
                    hibakodok(data.status);
                piestop();
            }
        });
}

function tisztitas(p){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
if (p == '') return;
p = xor(p, dmsk240B, "secret");
lc = SHA1(ego);

tkk = dmsk240B;
tk = SHA1(tkk);


secret(dmsk240B, tk + lc);
adatforgalom(tk, 1);
adatforgalom(lc, 1);
adatforgalom(p, 1);
piestart();
$('#szinkron').text('1');
$.ajax({
    type: "POST",
    url: elosztas(),
    data: {
        go: 20,
        tk: tk,
        lc: lc,
        p: p
    },
    
    success: function (data) {
        adatforgalom(data.length, 0);
        if (data == -3) window.location.replace('index.php');
        $("#feed_back").html(
            szovegetide(nyelv,62)+'<br />'+data+szovegetide(nyelv,162)
        );
        uzenet();
    },
    complete: function (data, xhr) {
        $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
        piestop();
    }
});
}

function threadinfbetoltese(){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    lc = SHA1(ego);
    
    adatforgalom(lc, 1);
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
           go: 19,
            lc: lc
            
        },
        
        success: function (data) {
            adatforgalom(data.length, 0);
            if(parseInt(data)){
                $('#szinkron').text('0');
                return;
            }
            $("#feed_back").html(
                szovegetide(nyelv, 62) + '<br />'+ szovegetide(nyelv,163)+data
            );
            
            uzenet();
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
                statuszkodlog(data.status, xhr);
                hibakodok(data.status);
            piestop();
        }
    });
}
function kapcsolo(p,kapcsolo){
    onlinechek();
    if (offlinech==1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    if (p == '') return;
    p = xor(p, dmsk240B, "secret");
    k = xor(kapcsolo, dmsk240B, "secret");
    lc = SHA1(ego);

    tkk = dmsk240B;
    tk = SHA1(tkk);
   
    secret(dmsk240B, tk + lc);
    adatforgalom(tk, 1);
    adatforgalom(lc, 1);
    adatforgalom(p, 1);
    adatforgalom(k, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go:15,
            tk: tk,
            lc: lc,
            p: p,
            k: k
        },
        
        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == -3) window.location.replace('index.php');
            $("#feed_back").html(
                szovegetide(nyelv, 62) + '</span><br/>'+szovegetide(nyelv,164) + data
            );
            uzenet();
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
                statuszkodlog(data.status, xhr);
                hibakodok(data.status);
            piestop();
        }
    });
}
function silentoff(){
    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv,165))
        .dialog({
            modal: true,
            title: szovegetide(nyelv,69),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Igen: function () {
                    var pass = $('input[name="name"]').val();
                    kapcsolo(pass, 'on');
                    $(this).dialog("close");
                },
                Nem: function () {
                    $(this).dialog("close");
                    return;
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
}

function silenton(){
    $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv,166))
        .dialog({
            modal: true,
            title: szovegetide(nyelv,69),
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Igen: function () {
                    var pass = $('input[name="name"]').val();
                    kapcsolo(pass,'off');
                    $(this).dialog("close");
                },
                Nem: function () {
                    $(this).dialog("close");
                    return;
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
}

$(document).ready(function(){
     $(document).on("click", "#databasecliner", function () {
          $('<div></div>').appendTo('body')
              .html(szovegetide(nyelv,167))
              .dialog({
                  modal: true,
                  title: szovegetide(nyelv,69),
                  zIndex: 10000,
                  autoOpen: true,
                  width: 'auto',
                  resizable: false,
                  buttons: {
                      Igen: function () {
                          var pass = $('input[name="name"]').val();
                          tisztitas(pass);
                          $(this).dialog("close");
                      },
                      Nem: function () {
                          $(this).dialog("close");
                          return;
                      }
                  },
                  close: function (event, ui) {
                      $(this).remove();
                  }
              });
        
     });
     $(document).on("click", "#felhasznalok", function () {
         felhasznalokbetoltese();
        
     });
     $(document).on("click", "#avissz", function () {
         adminmenube();
        
     });
     $(document).on("click", "#threadinf", function () {
         threadinfbetoltese();
        
     });
     $(document).on("click", "#phpinfo", function () {
         phpinfo();
        
     });
    $(document).on("click", "#silenton", function () {
         silenton();
        
     });
    $(document).on("click", "#silentoff", function () {
        silentoff();
        
     });
     $(document).on("click", "#stmodosito", function () {
         var statuszkod = $(this).val();
         var darabolt=skdarabol(statuszkod);
         var felirat;
         if (darabolt[1] == '1') felirat = szovegetide(nyelv,168);
         if (darabolt[1] == '2') felirat = szovegetide(nyelv, 169);
         if (darabolt[1] == '3') felirat = szovegetide(nyelv, 170);
         
         $('<div></div>').appendTo('body')
            .html('<div><h3>' + felirat + '</h3></div><div><h3 style="color:brown">'+szovegetide(nyelv,171)+'</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>')
            .dialog({
                modal: true,
                title: szovegetide(nyelv, 69),
                zIndex: 10000,
                autoOpen: true,
                width: 'auto',
                resizable: false,
                buttons: {
                    Igen: function () {
                        var pass = $('input[name="name"]').val();
                        igenmodositom(darabolt[0],darabolt[1],pass);
                        $(this).dialog("close");
                    },
                    Nem: function () {
                        $(this).dialog("close");
                        return;
                    }
                },
                close: function (event, ui) {
                    $(this).remove();
                }
            });
                
    });
    
     $(document).on("click", "#tagtorlese", function () {
         var statuszkod = $(this).val();
         var darabolt=skdarabol(statuszkod);
         var felirat;
         if(darabolt[1]=='3'){
             
             tween.restart();
             alert(szovegetide(nyelv,172));
             return;
         }
         
         
         
         $('<div></div>').appendTo('body')
            .html('<div><h3>' + szovegetide(nyelv, 173) + '</h3></div><div><h3 style="color:brown">' + szovegetide(nyelv, 171) + '</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>')
            .dialog({
                modal: true,
                title: szovegetide(nyelv, 69),
                zIndex: 10000,
                autoOpen: true,
                width: 'auto',
                resizable: false,
                buttons: {
                    Igen: function () {
                        var pass = $('input[name="name"]').val();
                        igentorlom(darabolt[0], darabolt[1], pass);
                        $(this).dialog("close");
                    },
                    Nem: function () {
                        $(this).dialog("close");
                        return;
                    }
                },
                close: function (event, ui) {
                    $(this).remove();
                }
            });
                
    });
     $(document).on("click", "#uzenetkuldesinfo1", function () {
         var alt = $(this).attr("alt");
         if ($('#eszkozlista'+alt).css('display') == 'none') {
             $('#eszkozlista'+alt).show('slow');
             $("#page-wrapper").css("box-shadow", "10px 10px 10px rgba(0, 0, 0, 0.8)");
         } else {
             $('#eszkozlista'+alt).hide('slow');
             $("#page-wrapper").css("box-shadow", "0 2px 10px rgba(0, 0, 0, 0.8)");
         }
     });
});