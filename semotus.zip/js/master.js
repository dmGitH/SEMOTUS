var szinkromszam = 0;
var szinkronhiba = 0;
var kuldottadat=0;
var fogadottadat=0;
var offlinech=0;
var oflk=0;
var kltarr = [];
var csomagazon;
var darabok = [];
var kinekarr = [];
var lejaratarr = [];
var uzenetszovegarr = [];
var kapottuzenetszovege;
var uzenetazonosito;
var szerverkapcsolatszam=0;
var uzenetvedo=0;
var menuallapotellenor=0;
var uztip=0;
var secallapot = 0;

//full screen
var elem = document.documentElement;
var fullscreen=0;


function feliratok(){
  $("#div1").html(szovegetide(nyelv,104));
  $(".divh1").html(szovegetide(nyelv,105));
  $("#info").html(szovegetide(nyelv,106));
  $('#gemes').fadeIn(2000);
  fooldal();
  $("#hely").html(szovegetide(nyelv,107));
  $("#ido").html(szovegetide(nyelv,108));
  $("#kozlemeny").html(szovegetide(nyelv,109));
  $("#regisztracio").html(szovegetide(nyelv,110));
  $("#btn").val(szovegetide(nyelv,67));

}
function adatforgalom(adathossz,kibe){
  
  if(kibe==1){
    if(typeof adathossz==='number'){
       adathossz=adathossz.toString();
    }
    kuldottadat+=adathossz.length;
  }
  if(kibe==0)fogadottadat+=adathossz;
  szerverkapcsolatszam++;
}
var tween = TweenMax.to("#div1", 3, {
  rotationY: 720
});
function iconfogratas() {

  TweenMax.fromTo('#ks', 0.5, {
    scale: 1
  }, {
    rotation: 1440,
    opacity: 1,
    scale: 1,

  });
}

function iconfogratasl() {

  TweenMax.fromTo('#messimg', 0.5, {
    scale: 1
  }, {
    rotation: 720,
    opacity: 1,
    scale: 1,

  });
}

function iconfogratasv() {

  TweenMax.fromTo('#ks', 0.5, {
    scale: 1
  }, {
    rotation: -1440,
    opacity: 1,
    scale: 1,

  });
}

function iconfogratasvl() {

  TweenMax.fromTo('#messimg', 0.5, {
    scale: 1
  }, {
    rotation: -720,
    opacity: 1,
    scale: 1,

  });
}

function iconfogratasbeinfo() {

  TweenMax.fromTo('#belepoinfo', 0.5, {
    scale: 1
  }, {
    rotation: -720,
    opacity: 1,
    scale: 1,

  });
}

function iconfogratasbeinfov() {

  TweenMax.fromTo('#belepoinfo', 0.5, {
    scale: 1
  }, {
    rotation: 720,
    opacity: 1,
    scale: 1,

  });
}

function kepmutatas() {
  TweenMax.fromTo(
    "#terkep",
    2, {
      scale: 0
    }, {
      scale: 0.9
    }
  );
  TweenMax.fromTo(
    "#terkep",
    2, {
      x: 0,
      y: 0,
      scale: 0,
      opacity: 0.3
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 0.6
    }
  );
  TweenMax.fromTo(
    "#helyszin",
    2, {
      x: 0,
      y: -1000,
      scale: 0,
      opacity: 0.3
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 1,
      ease: Bounce.easeOut
    }
  );
  TweenMax.fromTo(
    "#div1",
    2, {
      x: 0,
      y: 0,
      scale: 0,
      opacity: 0
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 1
    }
  );
  $("#terkep").css("max width", "80%");
}

function regisztracio() {
  TweenMax.fromTo(
    "#page-wrapper",
    0.3, {
      scale: 0
    }, {
      scale: 1
    }
  );
  TweenMax.fromTo(
    "#page-wrapper",
    0.5, {
      x: 0,
      y: 0,
      scale: 0,
      opacity: 0.3
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 1
    }
  );
  TweenMax.fromTo(
    "#div1",
    1, {
      x: 0,
      y: 0,
      scale: 0,
      opacity: 0
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 1
    }
  );
}
var tl = new TimelineLite();
tl.staggerFrom(
    ".nav span",
    0.05, {
      autoAlpha: 0
    },
    0.1
  )
  .fromTo(
    ".divh1",
    0.3, {
      scale: 0
    }, {
      scale: 1
    },
    ".letters"
  )
  .fromTo(
    "#terkep",
    0.3, {
      scale: 0
    }, {
      scale: 1
    },
    ".letters"
  )
  .fromTo(
    ".buttons",
    0.3, {
      scale: 0
    }, {
      scale: 1,
      borderRadius: 20
    },
    ".letters"
  )
  .fromTo(
    ".container",
    0.3, {
      scale: 0
    }, {
      scale: 1
    },
    ".letters"
  );

function emailok(mail) {
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
    return true;
  }
  return false;
}
function uzenet() {
  $('#feed_back').css('display', 'inline');
  TweenMax.fromTo(
    "#feed_back",
    1, {
      x: 0,
      y: -2000,
      scale: 0,
      opacity: 1
    }, {
      x: 0,
      y: 0,
      scale: 1,
      opacity: 1
    }
  );
}
function uzenettorlese() {
  TweenMax.fromTo("#feed_back", 1, {
    x: 0,
    y: 0,
    scale: 1,
    opacity: 1
  }, {
    x: 0,
    y: 0,
    scale: 0,
    opacity: 0
  });
  $("#feed_back").html("");
}
function contenervissza() {
  TweenMax.fromTo(
    "#div1",
    1, {
      x: 0,
      y: 0
    }, {
      x: -1000,
      y: 0
    }
  );
}

// function ekezeteskodcsere(str) {
//   a = str.replace(/á/g, "&aacute;");
//   b = a.replace(/é/g, "&eacute;");
//   c = b.replace(/í/g, "&iacute;");
//   d = c.replace(/ó/g, "&oacute;");
//   e = d.replace(/ö/g, "&ouml;");
//   f = e.replace(/ő/g, "&#337;");
//   g = f.replace(/ú/g, "&uacute;");
//   h = g.replace(/ü/g, "&uuml;");
//   i = h.replace(/ű/g, "&#369;");
//   j = i.replace(/Á/g, "&Aacute;");
//   k = j.replace(/É/g, "&Eacute;");
//   l = k.replace(/Í/g, "&Iacute;");
//   m = l.replace(/Ó/g, "&Oacute;");
//   n = m.replace(/Ö/g, "&Ouml;");
//   o = n.replace(/Ő/g, "&#336;");
//   p = o.replace(/Ú/g, "&Uacute;");
//   q = p.replace(/Ü/g, "&Uuml;");
//   r = q.replace(/Ű/g, "&#368;");
//   return r;
// }


function icononline(){
 $('#ks').css('display', 'inline');
 $('#ofpng').css('display', 'none');
}
function iconoffline(){
   $('#ks').css('display', 'none');
   $('#ofpng').css('display', 'inline');
}


$(window).resize(function () {
  if ($(window).width() < 400 && menuallapotellenor == 1) menukibe();
  if ($(window).width() > 640 && menuallapotellenor == 0) menukibe();
  tultipellenorzes();
});
var dmskf = '';
function dmskbe() {
  if (dmskf != "") dmsk = 1;
  else dmsk = 0;
  return dmsk;
}
function kszst(){
    kulcsszinkron();
}
var ismetles=0;

function menube() {
  TweenMax.fromTo(
    ".buttons",
    0.5, {
      scale: 0
    }, {
      scale: 1,
      borderRadius: 20
    },
    ".letters"
  );
}
function menukibe() {
  if (menuallapotellenor == 1) {
    menuallapotellenor = 0;
    $(".buttons").css("position", "initial");
    menube();
  } else {
   menuallapotellenor =1;
    $(".buttons").css("position", "fixed");
    menube();
  }
}
function adatvedelminyilatkozat() {
  uzenettorlese();
  $("#div1").html(szovegetide(nyelv,7));
  $("#btn").css("visibility", "hidden");
  regisztracio();
}
function regbetoltese(data) {
  if (data == "") uzenettorlese();
  else $("#feed_back").html(data);
  $("#div1").html(
    szovegetide(nyelv,8)
  );
  regisztracio();
  $("#btn").css("visibility", "visible");
}
function regtorlesebetoltese() {
  $("#div1").html(
    szovegetide(nyelv,9)
  );
  $("#vegrehajt").css("visibility", "visible");
  $("#allapotjelzo").text("rt");
}
function tultipellenorzes() {
  if ($("#menu").width() < 640) {
    $(".gombok span").css("visibility", "hidden");
  } else {
    $(".gombok span").css("visibility", "visible");
  }
}
function tooltipforgatas() {
  TweenMax.fromTo(
    ".tooltiptext",
    1, {
      scale: 0,
      opacity: 0
    }, {
      scale: 1,
      opacity: 1,
      borderRadius: 5
    }
  );
}
function serverhibauzenetlevagasa(mirol) {
  utolsotag = 0;
  for (i = 0; i < mirol.length; i++) {
    if (mirol[i] == ">") utolsotag = i;
    if (mirol[i] == "#") window.location.reload();
  }
  if (utolsotag > 0) return mirol.substr(utolsotag + 1, mirol.length - 1);
  else return mirol;
}

function piestart() {
  $('#pie').css('display', 'inline');
  return 1;
}
function piestop() {
  $('#pie').css('display', 'none');
}
function stopkulcsszinkron(){
   clearInterval(sinkrontime);
}
function startkulcsszinkron(){
    sinkrontime = setInterval(
    kulcsszinkron,
    1000 * parseInt($("#sincronmp").text())
  );
}
function stratcimeltuntetes(){
  eltuntet=setTimeout(cimeltuntetes,2000);
}
function cimeltuntetes(){
     TweenMax.fromTo(
     "#focim",
     5, {
       x: 0,
       y: 0,
       scale: 1,
       opacity: 1
    
     }, {
       x: 0,
       y: 0,
       scale: 0,
       opacity: 1,
     }
   );
}
function statuszkodlog(kod,szoveg){
  if(kod!=200){
    console.log('státuszkód: '+kod);
    console.log('uzenet: '+szoveg);
  }
}
function setup(l) {
  nyelv=l;
   if (nyelv == 2) {
     $('#lang').attr('src', $('#hun').attr('src'));
   } else if (nyelv == 1) {
     $('#lang').attr('src', $('#eng').attr('src'));
   }
  var udv = $('#ki').html();
  $("#div1").html(udv + szovegetide(nyelv,41));
  $("#focim").text(szovegetide(nyelv,111));
  $("#kijelentkezes").html(szovegetide(nyelv,112));
  $("#full").html(szovegetide(nyelv,113));
  $("#uzenetek").html(szovegetide(nyelv,114));
  $("#uzenetkuldes").html(szovegetide(nyelv,115));
  $("#dmsk_setup").html(szovegetide(nyelv,116));
  $("#beallitasok").html(szovegetide(nyelv,117));
  $("#admin").html(szovegetide(nyelv,118));
  $(".ki1").text(szovegetide(nyelv,119));
  $(".ki2").text(szovegetide(nyelv,120));
  $(".ki3").text(szovegetide(nyelv,121));
  $("#vegrehajt").val(szovegetide(nyelv,66));
  kulcsft = szovegetide(nyelv, 128);
  filefelt = szovegetide(nyelv, 129);
  hangfelt = szovegetide(nyelv,250);
  $('#katt').text(Math.floor(Date.now() / 1000));

}

function fooldal() {
  uzenettorlese();
  $("#div1").html(
    szovegetide(nyelv,55)
  );
  $("#btn").css("visibility", "hidden");
  //regisztracio();
}



function adatmegjelenitese(){
  $('.adatokmegjelenitesef').text(szovegetide(nyelv,63) + (fogadottadat / 1024 / 1024).toFixed(4) + 'MB');
  $('.adatokmegjeleniteseo').text(szovegetide(nyelv,64) + szerverkapcsolatszam);
  $('.adatokmegjelenitesek').text(szovegetide(nyelv,65) + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB');
}

function dmskbeallitas() {
  uzenetszovegmentese();
  dmsksetup();
  $('#vegrehajt').attr('value', szovegetide(nyelv,66));
}

$(document).ready(function () {
  
  var adatmegjelenites = setInterval(
    adatmegjelenitese,
    2000 
  );
  // var uzenetellenor = setInterval(
  //   uzenetcsekk,
  //   1000 * parseInt($("#allapotjelzo").text())
  // );
  startkulcsszinkron();
  stratcimeltuntetes();
  var dok=$("body,html");
  $('#fel').click(function(){
      hova = dok.scrollTop() - $(window).height();
      dok.animate({ scrollTop: hova }, 500, function () {
      });
    
  });
  $('#fel').dblclick(function () {
      dok.animate({ scrollTop: 0 }, 500, function () {
      });
    
  });
  $('#le').click(function(){
    hova = dok.scrollTop() + $(window).height();
    dok.animate({ scrollTop: hova }, 500, function () {
    });
  });
  $('#lang').on({
    
    'click': function () {
      var index=window.location.pathname;
      // console.log(window.location.pathname);
      
      if(nyelv==1){
          $(this).attr('src', "ico/eng.png");
          nyelv = 2;
      }else if(nyelv==2){
         $(this).attr('src', "ico/hun.png");
         nyelv = 1;
      }
      if (index.indexOf("index.php") != -1 || index=='/') {
        feliratok();
        $('#btn').css('visibility', 'hidden');
      }
      else {
        setup(nyelv);  
        $('#vegrehajt').css('visibility', 'hidden');
      }
      
    }
  });
  $('#le').dblclick(function () {
    
    dok.animate({
          scrollTop: dok.prop("scrollHeight")
        }, 500, function () {
    });
    
  });

  $(document).on("click", "#alap", function () {
     if(uzenetvedo==0){
       $('.uzenettorzs').removeClass("uzenettorzs").addClass("uzenettorzsr");
        uzenetvedo=1;
     }else{
       $('.uzenettorzsr').removeClass("uzenettorzsr").addClass("uzenettorzs");
        uzenetvedo=0;
     }
  });

  $("#allapotjelzo").text('uzenetlista');
  $("#dialogModal").dialog({
    autoOpen: false
  });
  $("#myButtonUI").on('click', function () {
    $("#dialogModal").dialog('open');
  });
  $(document).on("click", "#valasz", function () {
    var valaszcim = $(this).val();
    uzenetazonosito = $('#olvasva').val();
    kapottuzenetszovege = $('#kapottuzenetszovege' + uzenetazonosito).val();
    $('#vegrehajt').attr('value', szovegetide(nyelv,67));
    var lt = /</g,
      gt = />/g,
      ap = /'/g,
      ic = /"/g;
    kapottuzenetszovege = kapottuzenetszovege.toString().replace(lt, "&lt;").replace(gt, "&gt;").replace(ap, "&#39;").replace(ic, "&#34;");
    valaszirasa(valaszcim, kapottuzenetszovege, uzenetazonosito);
  });
  $(document).on("click", "#413", function () {
    http413();
  });
  $(document).on("click", "#tovabbit", function () {
    uzenetazonosito = $("#olvasva").val();
    kapottuzenetszovege = $('#kapottuzenetszovege' + uzenetazonosito).val();
   var lt = /</g,
     gt = />/g,
     ap = /'/g,
     ic = /"/g;
   kapottuzenetszovege = kapottuzenetszovege.toString().replace(lt, "&lt;").replace(gt, "&gt;").replace(ap, "&#39;").replace(ic, "&#34;");
    $('#vegrehajt').attr('value', szovegetide(nyelv,67));
    tovabbitas(kapottuzenetszovege);
    
  });
  $(document).on("click", "#olvasva", function () {
    var uzenetazonosito = $(this).val();
    olvasva(uzenetazonosito, 1);
  });
  $(document).on("click", "#letolt", function () {
    var uzenetazonosito = $(this).val();
    uzenetekbetoltese(uzenetazonosito);
  });
  $(document).on("click", "#messimg", function () {
     $('#allapotjelzo').text('uzenetlista');
     secdelet();
    uzenetlista(0);
  });
  $(document).on("click", "#dmskimg", function () {
    secdelet();
    dmskbeallitas();
  });
  $(document).on("click", "#dmskinfo", function () {
    if ($('#dmskinfotext').css('display') == 'none') {
      $('#dmskinfotext').show('slow');
      $("#page-wrapper").css("box-shadow", "10px 10px 10px rgba(0, 0, 0, 0.8)");
    } else {
      $('#dmskinfotext').hide('slow');
      $("#page-wrapper").css("box-shadow", "0 2px 10px rgba(0, 0, 0, 0.8)");
    }
  });
  $(document).on("click", "#uzenetkuldesinfo1", function () {
    if ($('#uzenetkuldestext1').css('display') == 'none') {
      $('#uzenetkuldestext1').show('slow');
      $("#page-wrapper").css("box-shadow", "10px 10px 10px rgba(0, 0, 0, 0.8)");
    } else {
      $('#uzenetkuldestext1').hide('slow');
      $("#page-wrapper").css("box-shadow", "0 2px 10px rgba(0, 0, 0, 0.8)");
    }
  });
  $(document).on("click", "#uzenetkuldesinfo2", function () {
    if ($('#uzenetkuldestext2').css('display') == 'none') {
      $('#uzenetkuldestext2').show('slow');
      $("#page-wrapper").css("box-shadow", "10px 10px 10px rgba(0, 0, 0, 0.8)");
    } else {
      $('#uzenetkuldestext2').hide('slow');
      $("#page-wrapper").css("box-shadow", "0 2px 10px rgba(0, 0, 0, 0.8)");
    }
  });
  $(document).on("click", "#kiurit", function () {
    $('#ujuzenet').val('');
    $('#mentettuzenet').text('');
  });
  $(document).on("click", "#belepoinfo", function () {
    if ($("#beinfo").css("display") == "none") {
      iconfogratasbeinfo();
      $("#beinfo").show("slow");
      $("#beinfo").css("box-shadow", "10px 10px 10px rgba(0, 0, 0, 0.8)");
      $("#vegrehajt").css("visibility", "visible");
      $("#allapotjelzo").text('pw');
    } else {
      iconfogratasbeinfov();
      $("#beinfo").hide("slow");
      $("#beinfo").css("box-shadow", "0 2px 10px rgba(0, 0, 0, 0.8)");
      $("#vegrehajt").css("visibility", "hidden");
      $('#allapotjelzo').text('uzenetlista');
    }
  });
  $("#Ok").click(function () {
    $("#dialogModal").dialog('close');
    dmskf=$('#dmsk_kod').val();
    if (dmskf != '') {
      $("#dmsk_setup").css("display", "inline");
    }
  });
  $("#Cancel").click(function () {
    $("#dialogModal").dialog('close');
  });
  $("#dmsk_setup").click(function () {
    dmskbeallitas();
  });
  $("#uzenetkuldes").click(function () {
    uzenetkuldesmenu();
    $('#vegrehajt').attr('value', szovegetide(nyelv,67));
  });
  $("#uzenetek").click(function () {
     $('#allapotjelzo').text('uzenetlista');
     $("#vegrehajt").css("visibility", "hidden");
    uzenetlista(0);
  });
  $("#kijelentkezes").click(function () {
    if(kltarr.length>0){
      $('<div></div>').appendTo('body')
        .html(szovegetide(nyelv,68))
        .dialog({
          modal: true,
          title: szovegetide(nyelv,69),
          zIndex: 10000,
          autoOpen: true,
          width: 'auto',
          resizable: false,
          buttons: {
            Igen: function () {
               kilepes();
              $(this).dialog("close");
             
            },
            Nem: function () {
              $(this).dialog("close");
            }
          },
          close: function (event, ui) {
            $(this).remove();
          }
        });
    }
    kilepes();
  });
  $("#beallitasok").click(function () {
    uzenetszovegmentese();
    regtorlesebetoltese();
    $('#vegrehajt').attr('value', szovegetide(nyelv,66));
    regisztracio();
  });
  $('#admin').click(function () {
    $('#vegrehajt').css('visibility', 'hidden');
    admin();
  });
  
  tultipellenorzes();
  $(".gombok").mouseenter(function () {
    tooltipforgatas();
  });
  $(".nav").click(function () {
    menukibe();
  });
  $("#feed_back").click(function () {
    uzenettorlese();
  });
  $("#hely").click(function () {
    uzenettorlese();
    $("#div1")
      .html(
        szovegetide(nyelv,75)
      );
    $("#btn").css("visibility", "hidden");
    kepmutatas();
  });
  $("#ido").click(function () {
    adatvedelminyilatkozat();
    $('#btn').attr('value', szovegetide(nyelv,66));
  });
  $("#regisztracio").click(function () {
    regbetoltese("");
    $('#btn').attr('value', szovegetide(nyelv,76));
  });
  $("#info").click(function () {
    fooldal();
  });
  $("#kozlemeny").click(function () {
    $('#btn').attr('value', szovegetide(nyelv,77));
    uzenettorlese();
    $("#div1").html(
      szovegetide(nyelv,78)
    );
    $("#btn").css("visibility", "visible");
    regisztracio();
  });
  
  $("#btn").click(function () {
    
    if ($("#loginname").val() != null && $("#loginpass").val() != null) {
      belepes(1);
    } else if ($("#regkod").val() == null && $("#name").val() != null) {
      loginregisztracio();
    } else if ($("#regkod").val() != null) {
      regsucces();
    }
    uzenet();
  });
});
function vanbenrosszkarakter(str) {
  tmp = /^[\x00-\x7F]*$/.test(str);
  if (tmp) return 0;
  else return 1;
}
function checkPwd(str) {
  if (str.search(/\d/) == -1) {
    $("#feed_back").html(
      szovegetide(nyelv,79)
    );
    uzenet();
    return 1;
  } else if (str.search(/[a-z]/) == -1) {
    $("#feed_back").html(
      szovegetide(nyelv,80)
    );
    uzenet();
    return 1;
  } else if (str.search(/[A-Z]/) == -1) {
    $("#feed_back").html(szovegetide(nyelv,81));
    uzenet();
    return 1;
  }
  return 0;
}
function hibakodok(hibakod) {
  if (hibakod == 500) {
    $("#feed_back").html(
      szovegetide(nyelv,82)
    );
    uzenet();
    return;
  }
  else if (hibakod == 503) {
    $("#feed_back").html(
      szovegetide(nyelv,83)
    );
    uzenet();
    return;
  }
  else if (hibakod == 404) {
    $("#feed_back").html(
      szovegetide(nyelv,84)
    );
    uzenet();
    return;
  }
  else if (hibakod == 400) {
    $("#feed_back").html(
      szovegetide(nyelv,85)
    );
    uzenet();
    return;
  }
  else if (hibakod == 0) {
    $("#feed_back").html(
      szovegetide(nyelv,86)
    );
    uzenet();
    return;
  }
  else if (hibakod == 413) {
    $("#feed_back").html(
      szovegetide(nyelv,87)
    );
    uzenet();
    return;
  }else if(hibakod!=200){
    $("#feed_back").html(
      szovegetide(nyelv, 174)+hibakod
    );
  }
}

// window.addEventListener("offline", function(e) {
//   console.log("offline");
//   iconoffline();
//   offlinech = 1;
//   oflk = oflk + offlinech;
//   if (oflk == 1) {
//     $("#feed_back").html(szovegetide(nyelv, 88));
//     uzenet();
//   }
// });

// window.addEventListener("online", function(e) {
//   console.log("online");
//   icononline();
//   offlinech = 0;
//   if (oflk != 0) {
//     $("#feed_back").html(szovegetide(nyelv, 89));
//     uzenet();
//     kulcsszinkron();
//   }
//   oflk = 0;
// });


function onlinechek(){
  $.ajax({
  type: "GET",
   url: elosztas(),
   data: {
     
   },
   error: function () {
     offlinech=1;
    oflk = oflk + offlinech;
    if(oflk==1){
      $("#feed_back").html(szovegetide(nyelv,88));
       uzenet();
       }
     },
     success: function (data) {
       if(data==1){
         offlinech=0;
         if (oflk != 0){ 
          $("#feed_back").html(szovegetide(nyelv,89));
            uzenet();
            kulcsszinkron();
         }
         oflk = 0;
        
       }else{
          offlinech = 1;
           oflk = oflk + offlinech;
           if (oflk == 1) {
             $("#feed_back").html(
               szovegetide(nyelv,88)
             );
             uzenet();
         } 
       }
     }    
   });

    //  ping('https://nethely.hu/').then(function (delta) {
    //    console.log('Ping time was ' + String(delta) + ' ms');
    //  }).catch(function (err) {
    //    console.error('Could not ping remote URL', err);
    //  });
}

var elosztoszama=1;
function elosztas(){
  // if(elosztoszama>9)elosztoszama=0;
  // elosztoszama++;
  // return "eloszto"+elosztoszama+".php";
  return "eloszto1.php";
}



$(document).keypress(function (e) {
   if (e.which == 13) {
    if($('#btn').val()==szovegetide(nyelv,77)){
      if ($("#loginname").val() != null && $("#loginpass").val() != null) {
        belepes(1);
      }
    }
    else if($('#btn').val()==szovegetide(nyelv,76)){
      if ($("#loginname").val() != null && $("#loginpass").val() != null) {
        loginregisztracio();
      }
    } else if ($("#regkod").val() != null) {
      regsucces();
    } else if ($('#allapotjelzo').text() == "uzenetlista" && $('#btn').val() != szovegetide(nyelv, 76)) {
      $('#allapotjelzo').text('uzenetlista');
      $("#vegrehajt").css("visibility", "hidden");
      uzenetlista(0);
    }
  }
 });
$(document).keydown(function (e) {
  
  
  if($('#vegrehajt').val()!=null){
    if (e.keyCode == 81 && e.ctrlKey) {
      $("#allapotjelzo").text("uzenetlista");
      $("#vegrehajt").css("visibility", 'hidden');
      setup(nyelv);
    }
    if (e.keyCode == 88 && e.ctrlKey) {
      kilepes();
    }
    if (e.keyCode == 89 && e.ctrlKey) {
      kulcsszinkron();
    }
    if (e.keyCode == 48 && e.ctrlKey) {
      menukibe();
    }
    if (e.keyCode == 112 && e.ctrlKey) {
      window.open('http://semotus.hu/index.php?hlp=help');
    }
    if (e.keyCode == 113 && e.ctrlKey) {
      $("#allapotjelzo").text("kuldes");
      $("#vegrehajt").css("visibility", 'visible');
      uzenetkuldesmenu();
    }
    if (e.keyCode == 27) {
      uzenettorlese();
    }
}
});
$(document).on("click", "#help", function () {
  window.open('http://semotus.hu/index.php?hlp=help');
});
$(document).on("click", "#honlapra", function () {
  window.open('http://semotus.hu/index.php');
});



function addmsk(mihez) {
  if (dmskf != "") {
    return mihez + dmskf;
  } else return mihez;
}

function belepesprobak(voltproba) {
  alert(szovegetide(nyelv, 223) + voltproba + szovegetide(nyelv, 224));
}

if (window.matchMedia('(display-mode: standalone)').matches) {
  console.log('display-mode is standalone');
}