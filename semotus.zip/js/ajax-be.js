function offlineuzenetekkuldese() {

    klt = kltarr.shift();
    kltor = klt;
    kinek = kinekarr.shift();
    kinekor = kinek;
    lejarat = lejaratarr.shift();
    lejarator = lejarat;
    uzenetszoveg = LZString.decompressFromUTF16(uzenetszovegarr.shift());
    uzenetszovegor = LZString.compressToUTF16(uzenetszoveg);
    ki = SHA1(ego);
    tk = dmsk240B;
    
    if (klt == 0) uzenetszoveg = xor(uzenetszoveg, tk, "secret");
    lejarat = xor(lejarat, tk, "secret");
    kinek = xor(kinek, tk, "secret");
    ki = xor(ki, tk, "secret");
    

    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(lejarat, 1);
    adatforgalom(uzenetszoveg, 1);
    adatforgalom(kinek, 1);
    adatforgalom(ki, 1);
    adatforgalom(klt, 1);
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 5,
            lejarat: lejarat,
            uzenetszoveg: uzenetszoveg,
            tk: tk,
            kinek: kinek,
            ki: ki,
            klt: klt
            
        },
        error: function () {
            kltarr.push(kltor);
            kinekarr.push(kinekor);
            lejaratarr.push(lejarator);
            uzenetszovegarr.push(uzenetszovegor);
        },
        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == "nemaktiv") kilepes();
            if (data == 0) {
                kltarr.push(kltor);
                kinekarr.push(kinekor);
                lejaratarr.push(lejarator);
                uzenetszovegarr.push(uzenetszovegor);
            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
        }
    });
    secret(dmsk240B, SHA1(tk));

}
var havanujuzenet="";
function uzenetcsekk() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    tk =ego;
    if (tk == "");
    else {
        tk = SHA1(tk);
        st = dmskbe();
        //ellenőrizni, hogy milyen az ikon
        //console.log($('#messimg').attr('src'));
        if($('#messimg').attr('src')=="ico/error.png")havanujuzenet="";
        hvuu = havanujuzenet;
        adatforgalom(st, 1);
        adatforgalom(tk, 1);
        iconfogratasl();
        $('#szinkron').text('1');
        $.ajax({
            type: "POST",
            url: elosztas(),
            data: {
                go: 14,
                tk: tk,
                st: st,
                hvuu: hvuu
            },
            error: function () {
                iconoffline();
                $('#szinkron').text('0');
                return;
            },
            success: function (data) {
                if(data=='n'){

                }else{
                havanujuzenet=SHA1(data);
                icononline();
                adatforgalom(data.length, 0);
                if (data == 'nemaktiv') kilepes();
                if (data == 1) kilepes();
                if (data == 0);
                else {
                    data = window.atob(data);
                    if (data.substr(0, 2) != "ok");
                    else {
                        uzenetszam = data.substr(2);
                        darabszam = data.substr(20,1);
                        
                        ennyivoltelotte=$('#osszuzenet').text();
                        
                        
                        var b = $('#pirosp').text();
                        
                        var c = $('#osszuzenet').text().substr(0,1);
                        
                        if (b == c) uzenetszam = uzenetszam.replace(szovegetide(nyelv, 3), ' ');
                        $("#uzenetszam").html(uzenetszam);
                        if (b != c) {
                            $('#osszuzenet').text(b);

                            uzenetlista(1);
                        }
                    }
                }
            }
        },
            complete: function (data, xhr) {
                $('#szinkron').text('0');
                statuszkodlog(data.status, xhr);
                hibakodok(data.status);
                iconfogratasvl();
                if ($('.eltuntetni').css('display') == 'block') {
                    if ($(window).width() > 400) menukibe();
                    $('.rejtett').css('display', 'block');
                }
                $('.eltuntetni').css('display', 'none');
                var uzszam = parseInt($('#pirosp').text().substr(0, 3));
                if(isNaN(uzszam))uzszam=0;
                $('#title').text(szovegetide(nyelv, 4) + uzszam);
            }
        });
    }
}
function http413() {
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 8,
            tk: 1
        },
        error: function () {
            iconoffline();
            $('#szinkron').text('0');
            return;
        },
        success: function (data) {
            alert(szovegetide(nyelv, 218) + data);
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
        }

    });
}
function tagidlistabetoltese() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        taglistaoffline();
        return;
    } else {
        icononline();
    }
    if ($("#mentettuzenet").text() != "") {
        $("#ujuzenet").val(LZString.decompressFromUTF16($("#mentettuzenet").text()));
    }
    
    var logincode = ego;
    var tk = dmsk240B;
    tkor = tk;
    sinc_number = Math.floor(Math.random() * 10000000);
    sinc = sinc_number.toString();
    if ($('#szinkron').text() == '1') {
         
         taglistaoffline();
         return;
    }
    logincode = SHA1(logincode);
    tk = SHA1(tk);
    secret(dmsk240B, sinc);
    adatforgalom(tk, 1);
    adatforgalom(logincode, 1);
    adatforgalom(sinc, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 17,
            logincode: logincode,
            tk: tk,
            sinc: sinc
        },
        error: function () {
            $('#szinkron').text('0');
            dmsk240B=tkor;
            if (taglistaoffline()) return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);

            data = responsexor(data, dmsk240B);
            if (data.includes("<option")) {
                $('#tagidlist').html(data);
                $('#tagid').html(LZString.compressToUTF16(data));
            } else {
                $("#feed_back").html(
                    szovegetide(nyelv, 21)
                );
                uzenet();
                taglistaoffline();
                console.log('mentett taglista');
            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}



function uzenetkuldes() {
    onlinechek();
    online = 1;
    if (offlinech == 1) {
        iconoffline();
        online = 0;
    } else {
        icononline();
        online = 1;
    }
    tk = dmsk240B;
    
    var kinek;
    var radio = $("input[name=kuldes]");
    var valasztottgomb = radio.filter(":checked").val();
    if (valasztottgomb == 'all') {
        kinek = 'all';
    } else {
        var valasztottagok = $('#taglista').val();
        if (typeof valasztottagok === 'string') valasztottagid = valasztottagok;
        else valasztottagid = valasztottagok.join();
        if (valasztottagid == "" && kinek != "all") {
            $("#feed_back").html(
                szovegetide(nyelv, 23)
            );
            uzenet();
            piestop();
            return;
        }
        kinek = valasztottagid;
    }
    kinekor = kinek;
    var ki = SHA1(ego);
    uzenetszoveg = $('#ujuzenet').val();
    if (uzenetszoveg == '' && binary == "") {
        $("#feed_back").html(
            szovegetide(nyelv, 24)
        );
        uzenet();
        piestop();
        return;
    }
    if (secallapot == 0) $('#mentettuzenet').text(LZString.compressToUTF16(uzenetszoveg));
    else $('#mentettuzenet').text('');
    if (secallapot == 1) {
        uzenetszoveg = LZString.compressToBase64(pinxorencode($('#pt').text(), uzenetszoveg));
    }
    if (secallapot == 2) {

        uzenetszoveg = LZString.compressToBase64(xor(uzenetszoveg, kulcscsomo, "secret"));

    }
    if (secallapot == 0) {
        
        // console.log(uzenetszoveg.length);
        // console.log(uzenetszoveg);
        // console.log(LZString.compressToBase64(uzenetszoveg));
        // console.log(LZString.compressToBase64(uzenetszoveg).length);
        
        if (online == 1) uzenetszoveg = xor(LZString.compressToBase64(uzenetszoveg), tk, "secret");
        klt = 0;
        // console.log(uzenetszoveg.length);
        // console.log(uzenetszoveg);
        // uzenetszoveg = encompdmsk(uzenetszoveg);
        
        // console.log(uzenetszoveg);
        // console.log(uzenetszoveg.length);
        // // console.log(encompdmsk(uzenetszoveg));

        // console.log(decompdmsk(uzenetszoveg));
        // console.log(LZString.decompressFromBase64(responsexor(decompdmsk(uzenetszoveg), tk)));

        // console.log(LZString.compressToBase64(uzenetszoveg).length);
        // console.log(LZString.compressToBase64(LZString.compressToBase64(uzenetszoveg)).length);
        
        

    } else klt = secallapot;


    lejarat = $('#maxido').val();
    lejarator = lejarat;
    if (online == 1) lejarat = xor(lejarat, tk, "secret");
    if (online == 1) kinek = xor(kinek, tk, "secret");

    ki = xor(ki, tk, "secret");
    
    if (online == 0) {
        // uzenetszoveg = LZString.compressToBase64(uzenetszoveg);

        uzenetmentese(klt, kinek, lejarat, uzenetszoveg);
        $("#feed_back").html(
            szovegetide(nyelv, 25)
        );
        uzenet();
        $('#ujuzenet').val('');
        $('#allapotjelzo').text('uzenetlista');
        uzenetlista(0);
        window.scrollTo(0, 0);
        piestop();
        return;
    }
    tk = SHA1(dmsk240B);
    adatforgalom(tk, 1);
    adatforgalom(lejarat, 1);
    adatforgalom(uzenetszoveg, 1);
    adatforgalom(kinek, 1);
    adatforgalom(ki, 1);
    adatforgalom(klt, 1);
    $('#szinkron').text('1');
    $.ajax({
        xhr: function () {

            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;

                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                    if (percentComplete === 1) {
                        $('.progress').addClass('hide');
                    }
                }
            }, false);
            xhr.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;

                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                }
            }, false);
            return xhr;
        },
        type: "POST",
        url: elosztas(),
        data: {
            go: 5,
            lejarat: lejarat,
            uzenetszoveg: uzenetszoveg,
            tk: tk,
            kinek: kinek,
            ki: ki,
            klt: klt
            
        },
        error: function () {
            iconoffline();
            //menteni offline
            $('#szinkron').text('0');
            return;
        },
        statusCode: {
            
            413: function () {
                $('#szinkron').text('0');
                kuldes413(kinekor, lejarator, kior, uzenetszoveg, klt);
            }
        },
        success: function (data) {

            // console.log(data);
            adatforgalom(data.length, 0);
            if (data == "nemaktiv") kilepes();
            if (data == 0) {
                $('#szinkron').text('0');
                alert(szovegetide(nyelv, 27));
                kulcsszinkron();
                return;
            }
            $('#pt').text('');
            secret(dmsk240B, SHA1(tk));
            $("#feed_back").html(
                szovegetide(nyelv, 28)
            );

            if (uzenetazonosito != null) {
                olvasva(uzenetazonosito, 0);
                uzenetazonosito = null;
            }
            uzenet();
            $('#ujuzenet').val('');
            $('#allapotjelzo').text('uzenetlista');
            uzenetlista(0);
            window.scrollTo(0, 0);
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
            setTimeout(ajaxprogressreset, 3000);
        }
    });
}
function uzenetekbetoltese(messid) {
    uzenetvedo = 0;
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    tk = SHA1(ego);
    kh = dmsk240B;
    tkor = kh;
    kh = SHA1(kh);
    uzenetid = messid;
    if (tk == "") return;
    else {
        
        secret(dmsk240B, kh);
        adatforgalom(tk, 1);
        adatforgalom(kh, 1);
        adatforgalom(uzenetid, 1);
        piestart();
        $('#szinkron').text('1');
        $.ajax({
            type: "POST",
            url: elosztas(),
            data: {
                go: 24,
                tk: tk,
                kh: kh,
                uzenetid: uzenetid
            },
            error: function () {
                iconoffline();
                $('#szinkron').text('0');
                alert(szovegetide(nyelv, 30));
                dmsk240B=tkor;
                return;
            },

            success: function (data) {

                adatforgalom(data.length, 0);
                if (data.indexOf("#") > 0) {
                    meddig = data.indexOf("#");

                    kodoltadat = LZString.decompressFromBase64(responsexor(data.substr(meddig + 1), dmsk240B));
                    if (kodoltadat == "") {
                        kodoltadat = ekezeteskodcserevissza(responsexor(data.substr(meddig + 1), dmsk240B));
                    }

                } else {
                    meddig = data.indexOf(".");

                    kodoltadat = LZString.decompressFromBase64(data.substr(meddig + 1));


                }
                data = atob(data.substr(0, meddig));
                // console.log(data);
                if (data == 1) {
                    $("#feed_back").html(szovegetide(nyelv, 31));
                    uzenet();
                    $('#szinkron').text('0');
                    return;
                } else if (data == 2) {
                    $("#feed_back").html(szovegetide(nyelv, 32));
                    uzenet();
                    $('#szinkron').text('0');
                    return;
                } else if (data == 3) {
                    $("#feed_back").html(szovegetide(nyelv, 33));
                    uzenet();
                    $('#szinkron').text('0');
                    return;
                }
                if (data == 0) {
                    $("#feed_back").html(
                        szovegetide(nyelv, 34)
                    );
                    uzenet();
                    uzenetcsekk();
                    setup(nyelv);
                } else {
                    elsobetu = data.substr(0, 1); {
                        if (data.substr(2, 3) == "div");
                        else {
                            $('#div1').html(szovegetide(nyelv, 35));
                            $('#szinkron').text('0');
                            return;
                        }
                    }

                    if (elsobetu == "y") {
                        data = data.substr(1, data.length - 1);
                        $('#div1').html(data);
                        $('.a15').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a22').prepend(szovegetide(nyelv, 201));
                        $('.a26').prepend(szovegetide(nyelv, 205));
                        $('.a27').prepend(szovegetide(nyelv, 206));
                        $('.a28').prepend(szovegetide(nyelv, 207));
                        $('.a29').prepend(szovegetide(nyelv, 208));
                        $('.a30').prepend(szovegetide(nyelv, 209));
                        $('.a31').prepend(szovegetide(nyelv, 210));
                        $('.a32').prepend(szovegetide(nyelv, 211));
                        $('.a50').prepend(szovegetide(nyelv, 219));
                        $('#dekodtooltip').text(szovegetide(nyelv, 36));

                        uztip = 2;
                    } else if (elsobetu == "x") {
                        data = data.substr(1, data.length - 1);
                        $('#div1').html(data);
                        $('.a15').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a23').prepend(szovegetide(nyelv, 202));
                        $('.a26').prepend(szovegetide(nyelv, 205));
                        $('.a27').prepend(szovegetide(nyelv, 206));
                        $('.a28').prepend(szovegetide(nyelv, 207));
                        $('.a29').prepend(szovegetide(nyelv, 208));
                        $('.a30').prepend(szovegetide(nyelv, 209));
                        $('.a31').prepend(szovegetide(nyelv, 210));
                        $('.a32').prepend(szovegetide(nyelv, 211));
                        $('.a50').prepend(szovegetide(nyelv, 219));
                        uztip = 1;
                    } else if (elsobetu == "#") {
                        data = data.substr(1, data.length - 1);

                        $('#div1').html(data);
                        $('.a15').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a21').prepend(szovegetide(nyelv, 200));
                        $('.a26').prepend(szovegetide(nyelv, 205));
                        $('.a27').prepend(szovegetide(nyelv, 206));
                        $('.a28').prepend(szovegetide(nyelv, 207));
                        $('.a29').prepend(szovegetide(nyelv, 208));
                        $('.a30').prepend(szovegetide(nyelv, 209));
                        $('.a31').prepend(szovegetide(nyelv, 210));
                        $('.a32').prepend(szovegetide(nyelv, 211));
                        $('.a50').prepend(szovegetide(nyelv, 219));

                        $('#dekodtooltip').text(szovegetide(nyelv, 37));
                        dekodolandoazonosito = '#kapottuzenetszovege' + $('#dekodol').val();
                        $(dekodolandoazonosito).val(kodoltadat);

                        $('#dekodol').prop("disabled", true);
                        uztip = 3;

                    } else if (elsobetu == "z") {
                        data = data.substr(1, data.length - 1);
                        $('#div1').html(data);
                        $('.a10').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a24').prepend(szovegetide(nyelv, 203));
                        $('.a33').prepend(szovegetide(nyelv, 212));
                        $('.a34').prepend(szovegetide(nyelv, 208));
                        $('.a35').prepend(szovegetide(nyelv, 213));
                        $('.a36').prepend(szovegetide(nyelv, 214));
                        $('#dekodtooltip').text(szovegetide(nyelv, 38));
                        //jelszó
                        uztip = 5;
                    } else if (elsobetu == "w") {
                        data = data.substr(1, data.length - 1);
                        $('#div1').html(data);
                        $('.a10').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a25').prepend(szovegetide(nyelv, 204));
                        $('.a33').prepend(szovegetide(nyelv, 212));
                        $('.a34').prepend(szovegetide(nyelv, 208));
                        $('.a35').prepend(szovegetide(nyelv, 213));
                        $('.a36').prepend(szovegetide(nyelv, 214));
                        $('#dekodtooltip').text(szovegetide(nyelv, 39));
                        //otp
                        uztip = 4;
                    
                    } else if (elsobetu == "t") {
                        data = data.substr(1, data.length - 1);
                        $('#div1').html(data);
                        $('.a10').prepend(szovegetide(nyelv, 182));
                        $('.a20').prepend(szovegetide(nyelv, 189));
                        $('.a2').prepend(szovegetide(nyelv, 176));
                        $('.a25a').prepend(szovegetide(nyelv, 255));
                        $('.a33').prepend(szovegetide(nyelv, 212));
                        $('.a34').prepend(szovegetide(nyelv, 208));
                        $('.a35a').prepend(szovegetide(nyelv, 213));
                        $('.a36').prepend(szovegetide(nyelv, 214));
                        $('#dekodtooltip').text(szovegetide(nyelv, 254));
                        //külső kódolásu
                        uztip = 6;
                    }
                    $('#allapotjelzo').text('olvasok');
                    regisztracio();
                }
            },
            complete: function (data, xhr) {
                $('#szinkron').text('0');
                statuszkodlog(data.status, xhr);
                hibakodok(data.status);
                piestop();
            }
        });
    }
}

function dmsk_on(){
    kod = $('#ujdmsk').val();
    if (kod == '' && $('input[name="valasztas"]:checked').val() != "off") {
        
        return 0;
    }else{
        return 2;
    }

}

function dmsksetuprun() {

    if($('#idozarsetup').val()=='');
    else idozarvar = $('#idozarsetup').val();
    if($('#kulcsszinkronsetup').val()=='');
    else ujkulcszinkronido($('#kulcsszinkronsetup').val());
    if ($('#uzenetellenorzessetup').val() == '')uzenetellenorzes(15);
    else uzenetellenorzes($('#uzenetellenorzessetup').val());
   


    if ($('input[name="valasztas"]:checked').val() == "off") {
        dmskf='';
        $("#div1").html(szovegetide(nyelv, 42));
        $("#allapotjelzo").text('');
        $("#vegrehajt").css("visibility", "hidden");
        kulcsszinkron();
        uzenettorlese();
        return;
    }
    if ($('input[name="valasztas"]:checked').val() == "on") {
        $("#dmsk_modosit").css("visibility", "visible");
        if (dmsk_on()==0){
            $("#feed_back").html(
                szovegetide(nyelv, 43)
            );
            uzenet();
            return;
        }
        else kod = $('#ujdmsk').val();
        kod = SHA256($('#ujdmsk').val());
        dmskf=kod;
        $("#vegrehajt").css("visibility", "hidden");
        $("#div1").html(szovegetide(nyelv, 44));
        uzenettorlese();
    }
    if ($('input[name="valasztas"]:checked').val() == "mode") {
        if (dmskf == '') {
            $("#feed_back").html(
                szovegetide(nyelv, 45)
            );
            uzenet();
            return;
        }
        kod = $('#ujdmsk').val();
        if (kod == '') {
            $("#feed_back").html(
                szovegetide(nyelv, 46)
            );
            uzenet();
            return;
        }
        if (kod.length > 199 || kod.length < 8) {
            $("#feed_back").html(szovegetide(nyelv, 47));
            uzenet();
            return;
        }
        b = vanbenrosszkarakter(kod);
        if (b == 1) {
            $("#feed_back").html(szovegetide(nyelv, 47));
            uzenet();
            return;
        }
        if (checkPwd(kod)) return;
        onlinechek();
        if (offlinech == 1) {
            iconoffline();
            return;
        } else {
            icononline();
        }
        var logincode = SHA1(ego);
        var tk = dmsk240B;
        kodor = kod;
        
        kod = xor(kod, tk, "secret");
        tk = SHA1(tk);
        adatforgalom(tk, 1);
        adatforgalom(kod, 1);
        adatforgalom(logincode, 1);
        piestart();
        $('#szinkron').text('1');
        $.ajax({
            type: "POST",
            url: elosztas(),
            data: {
                go: 3,
                logincode: logincode,
                tk: tk,
                sinc: kod
            },
            error: function () {
                iconoffline();
                $('#szinkron').text('0');
                return;
            },

            success: function (data) {
                piestop();
                adatforgalom(data.length, 0);
                if (data == 1);
                else {
                    $("#feed_back").html(szovegetide(nyelv, 49));
                    uzenet();
                    $('#szinkron').text('0');
                    return;
                }
                $("#feed_back").html(szovegetide(nyelv, 50));
                uzenet();
                $("#ujdmsk").val('');
            },
            complete: function (data, xhr) {
                $('#szinkron').text('0');
                piestop();
                statuszkodlog(data.status, xhr);
                hibakodok(data.status);
                secret(dmsk240B, kodor);
                dmskf=SHA256(kodor);
                kulcsszinkron();

            }
        });
    }
    uzenetcsekk();
}
function olvasva(melyik, honnan) {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        alert(szovegetide(nyelv, 30));
        return;
    } else {
        icononline();
    }
    lg = SHA1(ego);
    
    sinc = SHA1(melyik);
    adatforgalom(lg, 1);
    adatforgalom(sinc, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 25,
            sinc: sinc,
            lg: lg
        },
        error: function () {
            iconoffline();
            $('#szinkron').text('0');
            alert(szovegetide(nyelv, 30));
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == 1) {
                uzenetszamtemp = parseInt($('#pirosp').text());
                if (uzenetszamtemp > 0) $('#pirosp').text(uzenetszamtemp - 1);
                if (honnan == 1) {
                    $('#allapotjelzo').text('uzenetlista');
                    uzenetlista(0);
                    window.scrollTo(0, 0);
                }
            } else {
                $("#feed_back").html(szovegetide(nyelv, 51));
                uzenet();
                $('#szinkron').text('0');
                return;
            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            uzenetcsekk();
            piestop();
        }
    });
}
function kilepes() {
    var logincode = ego;
    var tk = dmsk240B;
    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(logincode, 1);
    piestart();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 7,
            logincode: SHA1(logincode),
            tk: tk
        },

        success: function (data) {
            adatforgalom(data.length, 0);

        },
        complete: function (data, xhr) {
            hibakodok(data.status);
            piestop();

            var keys = Object.getOwnPropertyNames(window),
                value;

            for (var i = 0; i < keys.length; ++i) {
                value = window[keys[i]];
                value = null;
            }

            window.location.replace("index.php");
        }
    });
}

function uzenetlista(honnan) {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        if ($('#mentettuzenetlista').text() != '' && $('#allapotjelzo').text() == 'uzenetlista') {
            $("#div1").html(LZString.decompressFromUTF16($('#mentettuzenetlista').text()));
            regisztracio();
        } else {
            $("#div1").html(szovegetide(nyelv, 56));
            regisztracio();
        }
        $('#vegrehajt').css('visibility', 'hidden');
        return;
    } else {
        icononline();
    }
    if (honnan == 0) $('#vegrehajt').css('visibility', 'hidden');
    if ($('#katt').text() == '') {
        $('#katt').text(Math.floor(Date.now() / 1000));
    } else {
        mennyi = $('#katt').text();
        if (parseInt(mennyi) + 1 > Math.floor(Date.now() / 1000)) return;
        else $('#katt').text(Math.floor(Date.now() / 1000));
    }
    var logincode = ego;
    var tk = dmsk240B;
    tk = SHA1(tk);
    
    logincode = SHA1(logincode);
    adatforgalom(logincode, 1);
    adatforgalom(tk, 1);
    $('#szinkron').text('1');
    piestart();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 6,
            logincode: logincode,
            tk: tk
           
        },
        error: function () {
            $('#szinkron').text('0');
            iconoffline();
            if ($('#mentettuzenetlista').text() != '' && $('#allapotjelzo').text() == 'uzenetlista') {
                $("#div1").html(LZString.decompressFromUTF16($('#mentettuzenetlista').text()));
                regisztracio();
            } else {
                $("#div1").html(szovegetide(nyelv, 56));
                regisztracio();
            }
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            data = atob(data);
            if (data == 0) {
                if ($('#allapotjelzo').text() == 'uzenetlista') {
                    $('#vegrehajt').css('visibility', 'hidden');
                    $("#feed_back").html(szovegetide(nyelv, 57));
                    uzenet();
                    setup(nyelv);
                }
                $('#mentettuzenetlista').text('');
                $('#szinkron').text('0');
                return;
            }
            if (data.substr(0, 4) == '<div');
            else {
                if ($('#allapotjelzo').text() == 'uzenetlista') {
                    $("#div1").html(szovegetide(nyelv, 58));
                    regisztracio();
                }
                piestop();
                $('#szinkron').text('0');
                return;
            }
            if ($('#allapotjelzo').text() == 'uzenetlista') {
                uzenettorlese();
                $("#div1").html(data + szovegetide(nyelv, 59));
            }
            $('#a1').prepend(szovegetide(nyelv, 175));
            $('.a2').prepend(szovegetide(nyelv, 176));
            $('.a3').prepend(szovegetide(nyelv, 177));
            $('.a4').prepend(szovegetide(nyelv, 178));
            $('.a5').prepend(szovegetide(nyelv, 179));
            $('.a6').prepend(szovegetide(nyelv, 180));
            $('.a7').prepend(szovegetide(nyelv, 181));
            $('.a7a').prepend(szovegetide(nyelv, 254));
            $('.a8').prepend(szovegetide(nyelv, 182));
            $('.a9').prepend(szovegetide(nyelv, 183));
            $('.a10').prepend(szovegetide(nyelv, 184));
            $('.a11').prepend(szovegetide(nyelv, 185));
            $('.a12').prepend(szovegetide(nyelv, 186));
            $('.a13').prepend(szovegetide(nyelv, 187));
            $('.a14').prepend(szovegetide(nyelv, 188));
            $('#mentettuzenetlista').text(LZString.compressToUTF16(szovegetide(nyelv, 60) + $('#div1').html()));

        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);

            piestop();
        }
    });
}
function feltolte() {
   
    onlinechek();
    online = 1;
    if (offlinech == 1) {
        iconoffline();
        online = 0;
        return 0;
    } else {
        icononline();
        online = 1;
    }
    tk = dmsk240B;
    var radio = $("input[name=kuldes]");
    var valasztottgomb = radio.filter(":checked").val();

    var valasztottagok = $('#taglista').val();
    if (typeof valasztottagok === 'string') valasztottagid = valasztottagok;
    else valasztottagid = valasztottagok.join();
    if (valasztottagid == "") {
        $("#feed_back").html(
            szovegetide(nyelv, 23)
        );
        uzenet();
        piestop();
        return;
    }
    var kinek;
    var ki = SHA1(ego);

    if (valasztottgomb == 'all') {
        kinek = 'all';
    } else {
        kinek = valasztottagid;
    }
    if(titkositott==1)klt=8;
    else klt = secallapot;
    titkositott=0;
    kinekor = kinek;
    lejarat = $('#maxido').val();
    lejarator = lejarat;
    ki = xor(ki, tk, "secret");
    lejarat = xor(lejarat, tk, "secret");
    kinek = xor(kinek, tk, "secret");
    binary = LZString.compressToBase64(binary);
    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(lejarat, 1);
    adatforgalom(binary, 1);
    adatforgalom(kinek, 1);
    adatforgalom(ki, 1);
    adatforgalom(klt, 1);
    
    //    if (binary.length > 2000000) {
    //      kuldes413(kinekor, lejarator, binary, klt);
       
    //     return;
    //   }
    $('#szinkron').text('1');
    $.ajax({
        xhr: function () {

            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    //  console.log(percentComplete);
                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                    if (percentComplete === 1) {
                        $('.progress').addClass('hide');
                    }
                }
            }, false);
            xhr.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    //  console.log(percentComplete);
                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                }
            }, false);
            return xhr;
        },

        type: "POST",
        url: elosztas(),
        data: {
            go: 21,
            lejarat: lejarat,
            uzenetszoveg: binary,
            tk: tk,
            kinek: kinek,
            ki: ki,
            klt: klt
        },
        error: function () {
            iconoffline();
             $('#szinkron').text('0');
            return;
        },
        statusCode: {
            413: function () {
                $('#szinkron').text('0');
                kuldes413(kinekor, lejarator, binary, klt);
                return;
            }
        },
        success: function (data) {

            // console.log(data);
            adatforgalom(data.length, 0);
            if (data == "nemaktiv") kilepes();
            if (data == 0) {
                alert(szovegetide(nyelv, 27));
                piestop();
                return 0;
            }else if(data.length>5){

                hiba=atob(data.substr(0,data.length-1));
                console.log(hiba);
                 $("#feed_back").html(
                     szovegetide(nyelv, 28)
                 );
                 uzenet();
            }else if(data==1){
                 alert(szovegetide(nyelv, 27));
                 piestop();
                 return 0;
            }
            console.log(data);
            $('#pt').text('');
            binary = "";
            //  if (uzenetazonosito != null) {
            //    olvasva(uzenetazonosito, 0);
            uzenetazonosito = null;
            //  }

        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            setTimeout(ajaxprogressreset, 3000);
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
            
        }
    });
}
function feltemp(kinekor, lejarator, darab, csomagszam, klt) {

    kltor = klt;

    kinek = kinekor;
    ki = SHA1(ego);
    lejarat = lejarator;

    binary = darab;

    adatforgalom(lejarat, 1);
    adatforgalom(binary, 1);
    adatforgalom(kinek, 1);
    adatforgalom(ki, 1);
    adatforgalom(klt, 1);
    adatforgalom(csomagszam, 1);
    adatforgalom(csomagazon, 1);
    $('#szinkron').text('1');
    $.ajax({
        xhr: function () {

            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    //  console.log(percentComplete);
                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                    if (percentComplete === 1) {
                        $('.progress').addClass('hide');
                    }
                }
            }, false);
            xhr.addEventListener("progress", function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = evt.loaded / evt.total;
                    $('.progress').css({
                        width: percentComplete * 100 + '%'
                    });
                    $('#bar').text(szovegetide(nyelv, 26) + (percentComplete * 100).toFixed(2) + '%');
                }
            }, false);
            return xhr;
        },

        type: "POST",
        url: elosztas(),
        data: {
            go: 22,
            lejarat: lejarat,
            darab: binary,
            //  tk: tk,
            kinek: kinek,
            ki: ki,
            klt: klt,
            cssz: csomagszam,
            csa: csomagazon
        },
        error: function () {
            iconoffline();
            $('#szinkron').text('0');
            alert(szovegetide(nyelv, 103));
            piestop();
            return;
        },
        success: function (data) {

            console.log(data);
            adatforgalom(data.length, 0);
            if (data == "nemaktiv") kilepes();
            if (data == 0) {
                alert(szovegetide(nyelv, 27));
                piestop();
                $('#szinkron').text('0');
                return 0;
            }
            if (data == 1) {
                setTimeout(kuldtemp(kinekor, lejarator, kltor, 1), 200);
                if (csomagszam - 1 == 1) {
                    $("#feed_back").html(
                        szovegetide(nyelv, 221)
                    );
                } else {
                    $("#feed_back").html(
                        szovegetide(nyelv, 220) + '' + (csomagszam - 1)
                    );
                }
            } else if (data == 2) {
                binary = "";
                darabok = [];
                csomagazon="";
                // $('#allapotjelzo').text('uzenetlista');
                // uzenetlista(0);
                // window.scrollTo(0, 0);
                $("#feed_back").html(
                    szovegetide(nyelv, 28)
                );
                uzenet();

            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            setTimeout(ajaxprogressreset, 200);
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}