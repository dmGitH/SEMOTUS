
function kulcsszinkron() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    if($('#szinkron').text()=='1'){
       
        return;
    }
    
    $('#szinkron').text('1');
    
    sinc = btoa(Math.floor((Math.random() * 999999999)).toString() + Math.floor((Math.random() * 999999999)).toString());
     
    tk = dmsk240B;
    tkor = tk;
    if (tk == "") tk = SHA1(sinc);
    else tk = SHA1(dmsk240B);
   
    dmsk = dmskbe();
    lg = SHA1(ego);
    egoor=ego;
    if(dmsk240B!=""){
        ego = btoa(SHA256(SHA1(sinc))).substr(0,80);
    }
    adatforgalom(sinc, 1);
    adatforgalom(tk, 1);
    adatforgalom(dmsk, 1);
    adatforgalom(lg, 1);
    iconfogratas();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 4,
            sinc: sinc,
            tk: tk,
            dmsk: dmsk,
            lg: lg
        },
        error: function () {
            iconoffline();
            dmsk240B=tkor;
            ego=egoor;
            return;
        },
        success: function (data) {
            sinc=SHA1(sinc);
            if(atma!="start")sinc+=atma;
            icononline();
            adatforgalom(data.length, 0);
            if (dmsk240B == "") {
                tk = addmsk(tk);
                kulcs = sinc + tk+data;
                kulcs = btoa(SHA1(kulcs)).substr(0, 40);
                for (i = 0; i < 5; i++) {
                    kulcs += btoa(SHA1(kulcs + tk+data)).substr(0, 40);
                }
               dmsk240B=kulcs;
                console.log("new");
                
                szinkronhiba++;
                szinkromszam = 0;
                $('#szinkron').text('0');
                return;
            } else {
                console.log("ok");
                ismetles = 3;
                
                secret(dmsk240B, addmsk(sinc));
                
            }
            dataorigin=data;
            data = responsexor(data, dmsk240B);
            if (data != "ok") {
                tk = addmsk(tk);
                kulcs = sinc + tk + dataorigin;
                kulcs = btoa(SHA1(kulcs)).substr(0, 40);
                for (i = 0; i < 5; i++) {
                    kulcs += btoa(SHA1(kulcs + tk + dataorigin)).substr(0, 40);
                }
                dmsk240B=kulcs;
                console.log("*");
                szinkronhiba++;
                szinkromszam = 0;
                ismetles = 0;
                if ($('#dmsk').text() != '')
                    $('#uzenetszam').html(szovegetide(nyelv, 5));
                else
                    $('#uzenetszam').html(szovegetide(nyelv, 6));
            }
            
            if (kltarr.length > 0) {
                offlineuzenetekkuldese();
                console.log('#' + kltarr.length);
            }
        },
        complete: function (data, xhr) {
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            iconfogratasv();
            $('#szinkron').text('0');
            if (ismetles < 2) {
                setTimeout(kulcsszinkron, 4000);
                // setTimeout(uzenetcsekk, 2000);
                ismetles++;

            } else {
                ismetles = 0;
            }

        }
    });
}

function regisztraciotorlese(logincode, p) {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    p = xor(p, dmsk240B, "secret");
    logincode = xor(logincode, dmsk240B, "secret");
    tk = dmsk240B;
    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(logincode, 1);
    adatforgalom(p, 1);
    piestart();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 13,
            logincode: logincode,
            tk: tk,
            p: p
        },
        error: function () {
            iconoffline();
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
        },
        complete: function (data, xhr) {
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
            kilepes();
        }
    });
}
function jelszomodositas() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    regipass = $("#regijelszo").val();
    if (regipass.length < 7) {
        $("#feed_back").html(
            szovegetide(nyelv, 10)
        );
        uzenet();
        return;
    }
    logincode = SHA1(ego);
    
    regipass = xor(regipass, dmsk240B, "secret");
    tk = dmsk240B;
    tk = SHA1(tk);
    adatforgalom(tk, 1);
    adatforgalom(regipass, 1);
    adatforgalom(logincode, 1);
    piestart();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 9,
            sinc: regipass,
            logincode: logincode,
            tk: tk
        },
        error: function () {
            iconoffline();
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == 0101) {
                ujpass_login();
            } else {
                $("#feed_back").html(
                    szovegetide(nyelv, 11)
                );
                uzenet();
                return;
            }
        },
        complete: function (data, xhr) {
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}

function ujpass_login() {
    ujpassa = $("#passa").val();
    ujpassb = $("#passb").val();
    if (ujpassa.length < 10) {
        $("#feed_back").html(
            szovegetide(nyelv, 12)
        );
        uzenet();
        return;
    }
    a = vanbenrosszkarakter(ujpassa);
    b = vanbenrosszkarakter(ujpassb);
    if (b == 1) {
        $("#feed_back").html(szovegetide(nyelv, 13));
        uzenet();
        return;
    }
    if (a == 1) {
        $("#feed_back").html(szovegetide(nyelv, 13));
        uzenet();
        return;
    }
    if (ujpassa != ujpassb) {
        $("#feed_back").html(
            szovegetide(nyelv, 14)
        );
        uzenet();
        return;
    }
    nnm = '0';
    if ($('#ujnicname').val() == "");
    else {
        nnm = $('#ujnicname').val();
        if (nnm.length < 4) {
            $("#feed_back").html(
                szovegetide(nyelv, 15)
            );
            uzenet();
            return;
        }
        if (vanbenrosszkarakter(nnm) == 1) {
            $("#feed_back").html(szovegetide(nyelv, 16));
            uzenet();
            return;
        }
    }
    if (checkPwd(ujpassa)) return;
    tk = dmsk240B;
    sincor = ujpassa;
    sinc = xor(ujpassa, tk, "secret");
    nnm = xor(nnm, tk, "secret");
    logincode = SHA1(ego);
    
    tk = SHA1(tk);
    $('#szinkron').text('1');

    adatforgalom(tk, 1);
    adatforgalom(logincode, 1);
    adatforgalom(sinc, 1);
    adatforgalom(nnm, 1);
    piestart();
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 10,
            sinc: sinc,
            logincode: logincode,
            tk: tk,
            nnm: nnm
        },
        error: function () {
            iconoffline();
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == 2) {
                $("#feed_back").html(
                    szovegetide(nyelv, 17)
                );
                uzenet();
                secret(dmsk240B, sincor);
                return;
            } else if (data == 1);
            else {
                $("#feed_back").html(
                    szovegetide(nyelv, 18)
                );
                uzenet();
               secret(dmsk240B, sincor);
                return;
            }
            $("#feed_back").html(
                szovegetide(nyelv, 19)
            );
            uzenet();
            $("#passa").val("");
            $("#passb").val("");
            $("#regijelszo").val("");
            $('#ujnicname').val("");
            secret(dmsk240B, sincor);
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}

function belepes(mennyi) {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    var nickname = $("#loginname").val();
    var so = nickname;
    var tk = dmsk240B;
    var loginpass = $("#loginpass").val();
    var cb;
    if ($('#kileptetes')[0].checked) cb = 1;
    else cb = 0;
    if (nickname.length < 4 || loginpass.length < 7) {
        $("#feed_back").html(szovegetide(nyelv, 90));
        uzenet();
        return;
    }
    tk = SHA1(tk);
    if (vanbenrosszkarakter(nickname)) {
        alert(szovegetide(nyelv, 91));
        return;
    }
    nickname = xor(nickname, dmsk240B, "secret");
    loginpass = xor(loginpass, dmsk240B, "secret");
    $('#szinkron').text('1');
    adatforgalom(tk, 1);
    adatforgalom(nickname, 1);
    adatforgalom(cb, 1);
    adatforgalom(loginpass, 1);
    piestart();

    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 1,
            nickname: nickname,
            tk: tk,
            loginpass: loginpass,
            cb: cb,
            nyelv: nyelv
        },
        error: function () {
            $("#feed_back").html(
                szovegetide(nyelv, 88)
            );
            uzenet();
            return;
        },
        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == -3) {
                window.location.replace("block.php");
            }
            if (data == -4) {
                window.location.replace("elutasit.php");
            }
            secret(dmsk240B, so);
            data = responsexor(data, dmsk240B);

            if (data.substr(0, 4) == "val:");
            else {
                dmsk240B="";
                kulcsszinkron();
                alert(
                    szovegetide(nyelv, 92)
                );
                return;
            }

            if (data.substr(4, 5) == "login") {
                nyelv = data.substr(9, 1);
                tk = SHA1(dmsk240B);
                window.location.replace(
                    "belepve.php?loginkod=" +
                    encodeURIComponent(xor(data.substr(10), dmsk240B, "secret")) +
                    "&tk=" +
                    tk +
                    "&nyelv=" + nyelv + ""
                );
                return;
            } else {
                $("#feed_back").html(data.substr(4));
                if (data.indexOf("a40") != -1) $('#a40').prepend(szovegetide(nyelv, 215));
                if (data.indexOf("a41") != -1) $('#a41').prepend(szovegetide(nyelv, 216));
                if (data.indexOf("a42") != -1) $('#a42').prepend(szovegetide(nyelv, 217));
                return;
            }
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}
function regsucces() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    var kapottkod = $("#regkod").val();
    var so = $("#regkod").val();
    kapottkod = xor(kapottkod, dmsk240B, "secret");
    var tk = dmsk240B;
    tk = SHA1(tk);
    if (kapottkod.length < 1) {


        $("#feed_back").html(szovegetide(nyelv, 93));
        uzenet();
        return;
    }
    adatforgalom(tk, 1);
    adatforgalom(kapottkod, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 16,
            kapottkod: kapottkod,
            tk: tk
        },
        error: function () {
            $("#feed_back").html(
                szovegetide(nyelv, 88)
            );
            uzenet();
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            secret(dmsk240B, so);
            data = responsexor(data, dmsk240B);
            if (data == "<h1>----</h1>") {
                data = szovegetide(nyelv, 94);
                regbetoltese(data);
                return;
            }
            fooldal();
            $("#feed_back").html(szovegetide(nyelv, 95));
            uzenet();
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}
function loginregisztracio() {
    onlinechek();
    if (offlinech == 1) {
        iconoffline();
        return;
    } else {
        icononline();
    }
    var email = $("#email").val();
    var so = email;
    var tk = dmsk240B;
    var name = $("#name").val();
    if (name == 'system') {
        $("#feed_back").html(szovegetide(nyelv, 96));
        uzenet();
        return;
    }
    if (name.length < 4 || email.length < 7) {
        $("#feed_back").html(szovegetide(nyelv, 97));
        uzenet();
        return;
    }
    tk = SHA1(tk);
    if (emailok(email))
        email = xor(email, dmsk240B, "secret");
    else {


        $("#feed_back").html(szovegetide(nyelv, 98));
        uzenet();
        return;
    }
    b = vanbenrosszkarakter(name);
    if (b == 1) {
        $("#feed_back").html(szovegetide(nyelv, 99));
        uzenet();
        return;
    }
    name = xor(name, dmsk240B, "secret");
    adatforgalom(tk, 1);
    adatforgalom(email, 1);
    adatforgalom(name, 1);
    piestart();
    $('#szinkron').text('1');
    $.ajax({
        type: "POST",
        url: elosztas(),
        data: {
            go: 12,
            email: email,
            tk: tk,
            name: name
        },
        error: function () {
            $("#feed_back").html(
                szovegetide(nyelv, 88)
            );
            uzenet();
            return;
        },

        success: function (data) {
            adatforgalom(data.length, 0);
            if (data == "foglalt") {
                $("#feed_back").html(
                    szovegetide(nyelv, 100)
                );
                secret(dmsk240B, so);
                return;
            }
            if (data.search("hiba") != -1) {
                $("#feed_back").html(
                    szovegetide(nyelv, 27)
                );
                uzenet();
                secret(dmsk240B, so);
                return;
            }
            secret(dmsk240B, so);
            data = responsexor(data, dmsk240B);
            uzenettorlese();
            $("#feed_back").html(data);
            $('.a80').append(szovegetide(nyelv, 240));
            $('.a81').append(szovegetide(nyelv, 241));
            $('.a82').append(szovegetide(nyelv, 242));

            $("#div1").html(
                szovegetide(nyelv, 101)
            );
            uzenet();
            $('#btn').val(szovegetide(nyelv, 69));
        },
        complete: function (data, xhr) {
            $('#szinkron').text('0');
            statuszkodlog(data.status, xhr);
            hibakodok(data.status);
            piestop();
        }
    });
}