<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
}

function tokenkiller()
{

    include 'd234_kopl_456_db.php';
    $y = "delete from sec where date<" . (time() - (60 * 3)) . ";";
    $db->exec($y);
    $db = null;

}

function hassolo($hash, $so)
{
    $i = strlen($so);
    $sohash = sha1($so);

    for ($a = 0; $a < $i; $a++) {
        $hash = hash('sha256', $hash . $sohash . $a . $so);
    }
    return $hash;
}

function ipgen()
{
    return $randIP = "" . mt_rand(0, 127) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255);
}

function inaktivregisztraciotorlese()
{

    include 'd234_kopl_456_db.php';

    $y = "delete from reg where aktiv=0 and regisztralt<" . (time() - (60 * 15)) . ";";
    $db->exec($y);
    $db = null;

}

function rpass()
{
    return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, mt_rand(8, 18));
}

function hashellenor($tk)
{

    include 'd234_kopl_456_db.php';

    $kulcs;
    $hash = $tk;
    if (strlen($hash) != 40) {
        http_response_code(404);
        exit();
    }

    if ($result = $db->query("select kulcs from sec where kulcs_hash='$hash';")) {

        if ($result->rowCount()) {
            $eredmeny = $result->fetchAll(PDO::FETCH_ASSOC);

            $kulcs = $eredmeny[0]['kulcs'];

        } else {

            $db = null;
            return null;

        }
    } else {
        echo "Lekérdezési hiba";
    }
    $db = null;
    return $kulcs;
}


function lejaruzenettorlese()
{

    include 'd234_kopl_456_db.php';

    $y = "delete from message where lejar<" . time() . " ;";
    $db->exec($y);

    $z = "DELETE from `kiknek` WHERE `statusz`=1;";
    $db->exec($z);
    //azokat az uzenet szemeteket amik nincsenek a kinek táblával kapcsolatban
    if ($result = $db->query("SELECT id, MIN(lejar) FROM message group BY sor;")) {
        if ($result->rowCount()) {
            $uzenetellenor = "";
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $uzenetellenor = $row[0];
                if ($result2 = $db->query("SELECT id FROM kiknek where message_id=$uzenetellenor;")) {
                    if ($result2->rowCount()) {
                    } else {
                        if ($result3 = $db->query("SELECT `sor` from message where id=$uzenetellenor;")) {
                            if ($result3->rowCount()) {
                                $sor = "";
                                while ($row2 = $result3->fetch(PDO::FETCH_NUM)) {
                                    $sor = $row2[0];
                                }
                                $query = "update message SET `sor`=1 where `sor`='$sor';";
                                $db->exec($query);
                            } else {
                            }
                        } else {
                        }
                    }
                }
            }
        }
    }

    $z = "DELETE FROM `message`  WHERE message.sor='1';";
    $db->exec($z);

    $x = "DELETE from kiknek where message_id not in (select id from message);";
    $db->exec($x);
    
    $x = "DELETE from kiknek where kinek not in (select id from reg);";
    $db->exec($x);

    $q = "DELETE from `message` where reg_id not in (select id from reg);";
    $db->exec($q);
    
    $sql="DELETE FROM `temp413` WHERE `time` <".(time() - (60 * 60)).";";
    $db->exec($sql);
    
    // $q = "DELETE from `temp413` where `time`<" .(time()*60*30).";";
    // $db->exec($q);

    if ($result = $db->query("SELECT * from message;")) {
        if ($result->rowCount());
        else{
            $s = "DELETE from reg where nickname='system';";
            $db->exec($s);
        }
    }
    $db = null;
    return;
}

function secxor($mit, $mivel)
{
    $mit= decompdmsk($mit);
    $ato = $mit;
    $tmp2 = "";
    $kodolando = "";
    $valto = 0;
    $mivelchar = "";
    $dekod_char = 0;
    for ($i = 0; $i < strlen($ato); $i++) {
        if (strlen($mivel) - 1 < $valto) {
            $valto = 0;
            $mivel = substr(base64_encode(hash('sha256',$mivel)), 0, 64);
        }
        $h = $ato[$i];
        for ($c = 0; $c < $h; $c++) {
            $i++;
            if ($i < strlen($ato)) {
                $kodolando .= $ato[$i];
            }

        }

        $mivelchar = substr($mivel, $valto, 1);

        $seged = (int) $kodolando;
        $dekod_char = ($seged ^ ord($mivelchar));

        $tmp2 = $tmp2 . chr($dekod_char);

        $kodolando = "";
        $valto++;

    }
    return $tmp2;

}
function secxordatabase($mit, $mivel)
{
    // $emp = gzinflate($mit);

    // $mit = $emp;

    $mit = substr($mit, 1);
    $index = strpos($mivel, '#');
    $indexh = strpos($mit, '.');

    $hossz = substr($mit, $indexh + 1, strlen($mit) - 1);
    $mit = substr($mit, 0, strlen($mit) - 1 - strlen($hossz));

    $hash = hash('sha256', substr($mivel, 0, $index - 1) . $hossz);
    $ip = substr($mivel, $index + 1, strlen($mivel) - 1);

    $ato = $mit;
    $tmp2 = "";
    $kodolando = "";
    $valto = 0;
    $mivelchar = "";
    $dekod_char = 0;
    $hanyszor = 0;
    for ($i = 0; $i < strlen($ato); $i++) {
        if (strlen($hash) - 1 < $valto) {
            $valto = 0;
            $hash = hash('sha256', $ip . $hash . $hanyszor . $hossz);
            $hanyszor++;
        }
        $h = $ato[$i];
        for ($c = 0; $c < $h; $c++) {
            $i++;
            if ($i < strlen($ato)) {
                $kodolando .= $ato[$i];
            }

        }

        $mivelchar = substr($hash, $valto, 1);

        $seged = (int) $kodolando;
        $dekod_char = ($seged ^ ord($mivelchar));

        $tmp2 = $tmp2 . chr($dekod_char);

        $kodolando = "";
        $valto++;

    }
    return $tmp2;

}

//lecserélni az ékezetes karaktereket a kódjukra
function karaktercsere($data)
{
    $search = array('á', 'é', 'í', 'ó', 'ö', 'ő', 'ú', 'ü', 'ű', 'Á', 'É', 'Í', 'Ó', 'Ö', 'Ő', 'Ú', 'Ü', 'Ű');
    $replace = array('&aacute;', '&eacute;', '&iacute;', '&oacute;', '&ouml;', '&#337;', '&uacute;', '&uuml;', '&#369;', '&Aacute;', '&Eacute;', '&Iacute;', '&Oacute;', '&Ouml;', '&#336;', '&Uacute;', '&Uuml;', '&#368;');
    $result = str_replace($search, $replace, $data);
    return $result;
}
function ekezetlenites($data)
{
    $search = array('á', 'é', 'í', 'ó', 'ö', 'ő', 'ú', 'ü', 'ű', 'Á', 'É', 'Í', 'Ó', 'Ö', 'Ő', 'Ú', 'Ü', 'Ű');
    $replace = array('a', 'e', 'i', 'o', 'o', 'o', 'u', 'u', 'u', 'A', 'E', 'I', 'O;', 'O;', 'O', 'U', 'U', 'U');
    $result = str_replace($search, $replace, $data);
    return $result;
}

function responsxor($mit, $mivel)
{

    $ato = $mit;
    $ato = karaktercsere($ato);
    $tmp2 = "";

    $valto = 0;
    $mivelchar = "";
    $dekod_char = 0;

    for ($i = 0; $i < strlen($ato); $i++) {
        if (strlen($mivel) - 1 < $valto) {
            $valto = 0;
            $mivel = substr(base64_encode(hash('sha256', $mivel)), 0, 64);
        }

        $mivelchar = substr($mivel, $valto, 1);

        $dekod_char = ord($ato[$i]) ^ ord($mivelchar);

        $tmp2 = $tmp2 . strlen($dekod_char) . $dekod_char;

        $valto++;

    }

    return encompdmsk($tmp2);

}

function responsxordatabase($mit, $mivel)
{

    $hossz = strlen($mit);

    $index = strpos($mivel, '#');

    $hash = hash('sha256', substr($mivel, 0, $index - 1) . $hossz);
    $ip = substr($mivel, $index + 1, strlen($mivel) - 1);

    $ato = $mit;
    // $ato=karaktercsere($ato);
    $tmp2 = "";

    $valto = 0;
    $mivelchar = "";
    $dekod_char = 0;

    $hanyszor = 0;
    for ($i = 0; $i < strlen($ato); $i++) {
        if (strlen($hash) - 1 < $valto) {
            $valto = 0;
            $hash = hash('sha256', $ip . $hash . $hanyszor . $hossz);
            $hanyszor++;
        }

        $mivelchar = substr($hash, $valto, 1);

        $dekod_char = ord($ato[$i]) ^ ord($mivelchar);

        $tmp2 = $tmp2 . strlen($dekod_char) . $dekod_char;

        $valto++;

    }

    return gzcompress('#' . $tmp2 .= '.' . $hossz);
    // return gzdeflate($tmp2,9);

}

function dmskkeres($lg_sha1)
{

    include 'd234_kopl_456_db.php';
    include 'login_class.php';
    include 'reg_class.php';

    if ($result = $db->query("select * from login;")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Login');
        if ($result->rowCount()) {

            while ($row = $result->fetch()) {
                $reg_id = $row->reg_id;
                $logincode = $row->loginkod;
                if ($logincode == ujloginkod($lg_sha1)) {
                    break;
                }

            }

        } else {
            $db = null;
            echo 0;
            exit;
        }
    } else {
        $db = null;
        echo 0;
        exit;
    }
    $dmsk = "";
    if ($result = $db->query("select * from reg where id='$reg_id';")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

        if ($result->rowCount()) {

            while ($row = $result->fetch()) {
                $dmsk = $row->dmsk;

            }

        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
    $db = null;
    return $dmsk;

}

function ujkucs($kulcs, $so)
{

    include 'd234_kopl_456_db.php';

    $azonosito = "off";
    // foreach (getallheaders() as $name => $value) {
    //     $azonosito .= "$name: $value\n";
    // }
    // $azonosito = sha1($azonosito);

    // $kulcshas = sha1($kulcs);
    // $sql = "delete from sec where kulcs='$kulcs';";
    // $db->exec($sql); $y = "delete from sec where date<" . (time() - (60 * 10)) . ";";
    
    // $sql = "DELETE from sec where azonosito='$azonosito' AND date<" . (time() - (60)) . ";";
    // $db->exec($sql);

    $kulcsor = $kulcs;
    $kulcs = $kulcs . $so;
    //  echo $kulcs;
    //  exit;
    $kulcs = substr(base64_encode(sha1($kulcs)), 0, 40);

    for ($i = 0; $i < 5; $i++) {
        $kulcs .= substr(base64_encode(sha1($kulcs . $so)), 0, 40);
    }

    $kulcsh = sha1($kulcs);
    $query = $db->prepare("insert into sec (`kulcs`,`kulcs_hash`,`date`,`azonosito`) VALUES(?,?,?,?);");
    $query->execute(array($kulcs, $kulcsh, time(), $azonosito));

    $db = null;

    tokenkiller();

    inaktivregisztraciotorlese();
    sqlproceskill();
    return $kulcs;

}

function sqlproceskill()
{

    include 'd234_kopl_456_db.php';
    $sql = "select concat('KILL ',id,';') from information_schema.processlist where time>200;";
    $db->exec($sql);
    $db = null;

}

function hibauzenetek($szam)
{
    if ($szam = "403") {
        return karaktercsere('<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="css/master.css" /></head><body class="not">

   <br><br><br><br><br><a  href="http://dm.semotus.hu">Kérem térjen vissza a helyes ösvényre</a><br>
   <div id="sec-1" class="section">
   <div id="ctn">
    <div class="marquee">
      <div class="marquee-text">Hozzáférés megtagadva&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hagyja el az oldalt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACCESS DENIED</div>
    </div>
    <div id="forbidden">TILTOTT ESEMÉNY</div>
    <br>
    <div class="marquee">
      <div class="marquee-text">ACCESS DENIED&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hozzáférés megtagadva&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACCESS DENIED</div>
    </div>
  </div>
  </div></body></html>');
    }

    if ($szam = "404") {
        return karaktercsere('<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="css/master.css" /></head><body class="not">

   <br><br><br><br><br><a  href="http://dm.semotus.hu">Kérem térjen vissza a helyes ösvényre</a><br>
   <div id="sec-1" class="section">
   <div id="ctn">
    <div class="marquee">
      <div class="marquee-text">Hozzáférés megtagadva&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hagyja el az oldalt&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACCESS DENIED</div>
    </div>
    <div id="forbidden">TILTOTT ESEMÉNY</div>
    <br>
    <div class="marquee">
      <div class="marquee-text">ACCESS DENIED&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hozzáférés megtagadva&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACCESS DENIED</div>
    </div>
  </div>
  </div></body></html>');
    }

}

function hasznalteszkozok($id)
{
    include 'd234_kopl_456_db.php';
    $valasz = '<ol id="eszkozlista' . $id . '" style="display:none">';
    if ($result = $db->query("select * from login where reg_id='$id';")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Login');

        if ($result->rowCount()) {

            while ($row = $result->fetch()) {
                $bejelentkezve = $row->loginkod;
                $betime = $row->bejelentkezett;
                $mikor = date('Y/m/d H:i', $betime);
                if (strlen($bejelentkezve) < 20) {
                    $bejelentkezve = '<p style="color:lightblue" class="a72"></p>';
                } else {
                    $bejelentkezve = '<p style="color:orange" class="a73">' . $mikor . ' óta</p>';
                }
                $valasz .= '<li><h4>' . $row->eszkoz_azon . '<br><p class="a74" style="color:lightgreen">' . $row->statusz . '</p>
               ' . $bejelentkezve . '</h4></li>';
            }

        } else {
            $db = null;
            return null;
        }
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
    $db = null;
    return $valasz . '</ol>';

}

function aktivezafelhasznalo($id)
{
    include 'd234_kopl_456_db.php';
    if ($result = $db->query("select * from reg where id='$id';")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
        $aktiv;
        if ($result->rowCount()) {

            while ($row = $result->fetch()) {
                $aktiv = $row->aktiv;
            }
            // if($aktiv==-1){
            //     $db=null;
            //     echo 'nemaktiv';
            //     exit;
            // }
            if ($aktiv > 0) {
                return $aktiv;
            } else {
                $db = null;
                echo 'nemaktiv';
                exit;
            }

        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}

function dmsksecd()
{
    include 'd234_kopl_456_db.php';

    $s = "";
    $ip = "";
    if ($result = $db->query("SELECT * from reg where nickname='system';")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
        if ($result->rowCount()) {

            while ($row = $result->fetch()) {
                $s = $row->passhash;
                $ip = $row->ip;
            }
        } else {
            $query = $db->prepare("insert into reg (`hash`,`aktiv`,`regisztralt`,`ip`,`nickname`,`passhash`,`dmsk`) VALUES(?,?,?,?,?,?,?);");
            $jelszohash = hash('sha256', sha1(rand() . rand()));
            $query->execute(array(hash('sha256', sha1(rand())), '2', time(), ipgen(), 'system', $jelszohash, str_shuffle(12234122453657)));

            if ($result = $db->query("SELECT * from reg where nickname='system';")) {
                $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
                if ($result->rowCount()) {

                    while ($ro = $result->fetch()) {
                        $s = $ro->passhash;
                        $ip = $ro->ip;
                    }
                }
            }
        }
    }

    $db = null;

    return $s . '#' . $ip;
}
function aid()
{
    include 'd234_kopl_456_db.php';
    $admin_id;
    if ($result = $db->query("select `id` from reg where aktiv=3;")) {
        if ($result->rowCount()) {
            $eredmeny = $result->fetchAll();
            $admin_id = $eredmeny[0][0];
        } else {
            echo '<h1>Rendszerhiba a Aid keresésekor. 1</h1>';
        }

    } else {
        echo '<h1>Rendszerhiba a Aid keresésekor. 2</h1>';
    }
    $db = null;
    return $admin_id;

}

function kinek($kinek,$reg_id,$utolso_uzenet_id)
{
    include 'd234_kopl_456_db.php';
    if ($kinek == 'all') {
        if ($result = $db->query("select * from reg where `id` <> '$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $id = $row->id;
                    $query = $db->prepare("insert into kiknek (`message_id`,`kinek`,`statusz`) VALUES(?,?,?);");
                    if ($query->execute(array($utolso_uzenet_id, $id, 0)));
                    else {
                        echo 0;
                        $db = null;
                        exit;
                    }
                }

            } else {
                $db = null;
                echo 0;
                exit;
            }
        } else {
            $db = null;
            echo 0;
            exit;
        }
    } else {
        $kiknek = explode(',', $kinek);
        foreach ($kiknek as $egyenkent) {
            $query = $db->prepare("insert into kiknek (`message_id`,`kinek`,`statusz`) VALUES(?,?,?);");
            if ($query->execute(array($utolso_uzenet_id, (int)$egyenkent, 0)));
            else {
                echo 0;
                $db = null;
                exit;
            }
        }
    }
    $db=null;
    return;
}
function encompdmsk($mit)
{
    $tmp = "";
    $eredmeny = "";
    $hossz = strlen($mit);
    for ($i = 0; $i < $hossz; $i ++) {
        if ($i + 1 == $hossz) {
            $tmp = $mit[$i];
        } else {
            if ($mit[$i] == '0') $tmp = '0';
            else {
                $tmp .= $mit[$i].$mit[$i+1];
                $i++;
            }
        }

        $eredmeny .= chr((int)$tmp+64);
        $tmp = "";
    }
    return base64_encode($eredmeny);
    // return $eredmeny;
}

function decompdmsk($mit)
{
    $mit=base64_decode($mit);
    $hossz = strlen($mit);
    $eredmeny = "";
    for ($i = 0; $i < $hossz; $i ++) {
        $tmp = (ord($mit[$i])-64);
        if ($tmp == 0) $eredmeny .= '0';
        else $eredmeny .= $tmp;
    }
    return $eredmeny;
}
function ujloginkod($loginkod){
    return substr(base64_encode(hash('sha256', $loginkod . sha1($_SERVER['REMOTE_ADDR']))),0,80);
}

function kikerdezi($loginkod){
   
    include 'd234_kopl_456_db.php';
    if ($result = $db->query("select * from login;")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Login');
        $i = 0;
        if ($result->rowCount()) {
            $van = '';
            while ($row = $result->fetch()) {
                $reg_id = $row->reg_id;
                $logincode = $row->loginkod;
               
                if ($logincode==ujloginkod($loginkod)) {
                    $van = '1';
                    break;
                }
            }
            if ($van == '1');
            else {
                $db = null;
                echo 1;
                exit;
            }
            $olvasostatusza = aktivezafelhasznalo($reg_id);
        } else {
            $db = null;
            echo 2;
            exit;
        }
    } else {
        $db = null;
        echo 3;
        exit;
    }
    return $reg_id;
}
