<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Uzenetek_m
{
    public $neve;
    public $uzente;
    public $mikor;
    public $uzenetazonositoja;
    public $kuldoazonositoja;
   

    public function __construct()
    {

    }

}