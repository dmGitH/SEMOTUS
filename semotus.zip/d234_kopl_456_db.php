<?php
require_once 'csek.php';

// if (!ipcsekk($_SERVER["REMOTE_ADDR"])) {
//     echo $_SERVER["REMOTE_ADDR"];
//     exit;
// } else {

// }

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};
// if (count(get_included_files()) == 1)
// {
//     http_response_code(404);
//     exit;
// }
try {
    $db = new PDO(d('server'), u('server'), p('server'));
    //$db->exec("set names utf8");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   //,array(PDO::MYSQL_ATTR_MAX_BUFFER_SIZE, 1024 * 1024 * 50)
    
            //http_response_code(200);
    } catch (PDOException $e) {
    echo $e->getMessage();
    die('Adatbázis kapcsolódási hiba');
}
