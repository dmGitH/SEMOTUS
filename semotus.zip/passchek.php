<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function passcsek()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);
        if ($kulcs == null) {
            echo 0;
            $db = null;
            exit;
        }
        $loginkod_passmodositas_sha1 = $_POST["logincode"];
        $regipass = strip_tags(trim(secxor($_POST["sinc"], $kulcs)));

        // $ujkulcs = ujkucs($kulcs, $regipass);
        //meg kell keresni a felhasználói nevet
        $reg_id=kikerdezi($loginkod_passmodositas_sha1);
        $nickname = "";
        if ($result = $db->query("select * from reg where id='$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $nickname = $row->nickname;

                }

            } else {
                $db = null;
                echo hibauzenetek(403);
                exit;
            }
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }
        //itt össze kell hozni a jelszohast
        $jelszohash = hash('sha256', $regipass . $nickname);
        $jelszohash = hassolo($jelszohash, $nickname);
        if ($result = $db->query("select * from reg where id='$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $nickname = $row->passhash;
                    if ($nickname == $jelszohash) {
                        echo 0101;
                        $db = null;
                        exit;
                    } else {
                        echo 0;
                    }

                }

            } else {
                $db = null;
                echo 0;
                exit;
            }
        } else {
            $db = null;
            echo 0;
            exit;
        }

        $db = null;

    } else {
        echo hibauzenetek(403);
    }
}
