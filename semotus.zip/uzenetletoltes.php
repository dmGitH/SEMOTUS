<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function uzenetletoltes()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'uzeneteim_class.php';
    require_once 'mailmessage_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $logincode_sha1 = $_POST["tk"];

        $kulcshash = $_POST["kh"];
        $kulcs = hashellenor($kulcshash);
        $uzenetid = $_POST["uzenetid"];
        $ujkulcs = ujkucs($kulcs, $kulcshash);
        $reg_id = kikerdezi($logincode_sha1);
        $olvasostatusza = aktivezafelhasznalo($reg_id);
       
        $kulcsfile = 0;
        $sor;
        $valasz = '<div id="page-wrapper"><div id="uzikeret"><h1 class="a20"></h1><br><br><ol>';
        if ($result = $db->query("SELECT message.uzenet as uzenet, reg.nickname as kuldo, reg.id as kuldoazonositoja, message.time as kuldte, kiknek.id as uzenetazonosito, message.id as valaszcim, kiknek.statusz, message.sor as sor FROM `message` INNER JOIN reg ON reg.id=message.reg_id INNER JOIN kiknek on kiknek.message_id=message.id WHERE kiknek.id=$uzenetid;")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Uzeneteim');
            $uzenetellenor = "";
            if ($result->rowCount()) {
                while ($row = $result->fetch()) {
                    $uzenetellenor = gzuncompress($row->uzenet);
                    $sor = $row->sor;
                    if (substr($uzenetellenor, 0, 1) == '#') {
                        $kulcsfile = 5;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a21\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<label class=\"a50\" style=\"color:lightblue\"></label><button class=\"gombok tooltip a26\" id=\"valasz\" value=\"$row->kuldoazonositoja\"><span class=\"tooltiptext a27\"></span></button><button class=\"gombok tooltip a28\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a29\"></span></button><button class=\"gombok tooltip\" id=\"dekodol\" value=\"$row->uzenetazonosito\">Dekódolom<span id=\"dekodtooltip\" class=\"tooltiptext a30\"></span></button><button class=\"gombok tooltip a31\" id=\"tovabbit\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a32\"></span></button></div></li><br><br>";
                    } else if (substr($uzenetellenor, 0, 1) == '0') {
                        $kulcsfile = 1;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a22\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<label  class=\"a50\" style=\"color:lightblue\"></label><button class=\"gombok tooltip a26\" id=\"valasz\" value=\"$row->kuldoazonositoja\"><span class=\"tooltiptext a27\"></span></button><button class=\"gombok tooltip a28\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a29\"></span></button><button class=\"gombok tooltip\" id=\"dekodol\" value=\"$row->uzenetazonosito\">Dekódolom<span id=\"dekodtooltip\" class=\"tooltiptext a30\"></span></button><button class=\"gombok tooltip a31\" id=\"tovabbit\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a32\"></span></button></div></li><br><br>";
                    } else if (substr($uzenetellenor, 0, 1) == '1') {
                        $kulcsfile = 2;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a23\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<label class=\"a50\"  style=\"color:lightblue\"></label><button class=\"gombok tooltip a26\" id=\"valasz\" value=\"$row->kuldoazonositoja\"><span class=\"tooltiptext a27\"></span></button><button class=\"gombok tooltip a28\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a29\"></span></button><button class=\"gombok tooltip\" id=\"dekodol\" value=\"$row->uzenetazonosito\">Dekódolom<span id=\"dekodtooltip\" class=\"tooltiptext a30\"></span></button><button class=\"gombok tooltip a31\" id=\"tovabbit\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a32\"></span></button></div></li><br><br>";
                    } else if (substr($uzenetellenor, 0, 1) == 'p') {
                        $kulcsfile = 3;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a24\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<button class=\"gombok tooltip a33\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a34\"></span></button><button class=\"gombok tooltip a35\" id=\"dekodol\" value=\"$row->uzenetazonosito\"><span id=\"dekodtooltip\" class=\"tooltiptext a36\"></span></button></div></li><br><br>";
                    } else if (substr($uzenetellenor, 0, 1) == 'f') {
                        $kulcsfile = 4;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a25\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<button class=\"gombok tooltip a33\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a34\"></span></button><button class=\"gombok tooltip a35\" id=\"dekodol\" value=\"$row->uzenetazonosito\"><span id=\"dekodtooltip\" class=\"tooltiptext a36\"></span></button></div></li><br><br>";
                    
                    } else if (substr($uzenetellenor, 0, 1) == 't') {
                        $kulcsfile = 6;
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><div id=\"alap\" class=\"a15\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br><br><textarea disabled id=\"kapottuzenetszovege$row->uzenetazonosito\" class=\"uzenettorzs a25a\" rows=\"20\" cols=\"20\"></textarea><br>";
                        $valasz .= '<script>var $textarea' . $row->uzenetazonosito . ' = $("#kapottuzenetszovege' . $row->uzenetazonosito . '");$textarea' . $row->uzenetazonosito . ' . scrollTop($textarea' . $row->uzenetazonosito . '[0] . scrollHeight);</script>';
                        $valasz .= "<button class=\"gombok tooltip a33\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a34\"></span></button><button class=\"gombok tooltip a35a\" id=\"dekodol\" value=\"$row->uzenetazonosito\"><span id=\"dekodtooltip\" class=\"tooltiptext a36\"></span></button></div></li><br><br>";
                    }

                }
                $valasz .= '</ol></div>';

                if ($result = $db->query("SELECT `uzenet`,`lejar` FROM `message` where `sor`= '" . $sor . "' ORDER BY `lejar` ASC;")) {
                    if ($result->rowCount()) {
                        $uzenetellenor = "";
                        while ($row = $result->fetch(PDO::FETCH_NUM)) {
                            $uzenetellenor .= gzuncompress($row[0]);
                        }

                    } else {
                        $db = null;
                        echo 0;
                        exit;
                    }
                }
                $db = null;
                if ($kulcsfile == 1) {
                    echo Base64_encode(karaktercsere($valasz = 'y' . $valasz));
                    echo '.' . substr($uzenetellenor, 1);
                } else if ($kulcsfile == 2) {
                    echo Base64_encode(karaktercsere($valasz = 'x' . $valasz));
                    echo '.' . substr($uzenetellenor, 1);

                } else if ($kulcsfile == 3) {
                    echo Base64_encode(karaktercsere($valasz = 'z' . $valasz));
                    echo '.' . substr($uzenetellenor, 1);

                } else if ($kulcsfile == 4) {
                    echo Base64_encode(karaktercsere($valasz = 'w' . $valasz));
                    echo '.' . substr($uzenetellenor, 1);

                } else if ($kulcsfile == 5) {
                    echo Base64_encode(karaktercsere($valasz = '#' . $valasz));
                    $uzenetellenor = secxordatabase($uzenetellenor, dmsksecd());
                    echo '#' . responsxor($uzenetellenor, $ujkulcs);
                
                } else if ($kulcsfile == 6) {
                    echo Base64_encode(karaktercsere($valasz = 't' . $valasz));
                    echo '.' . substr($uzenetellenor, 1);
                }

                exit;

            } else {

            }
        } else {

            $db = null;
            echo 0;
            exit;
        }
        $db = null;

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
