<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Uzenet
{

    public $id;
    public $reg_id;
    public $uzenet;
    public $time;
    public $lejar;
    public $sor;


    public function __construct()
    {

    }


}