<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function regdelet()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'login_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);

        if ($kulcs == null) {
            echo 'Kulcsszinkron hiba. Próbálja meg újra a műveletet<br><button class="gombok" id="felhasznalok">Felhasználók</button>';
            exit;
        }
        $p = secxor($_POST["p"], $kulcs);
        $logincode = secxor($_POST["logincode"], $kulcs);
        if ($logincode == null) {
            $db = null;

            exit;
        }
        $reg_id=kikerdezi($logincode);
        $nickname;
        $passhash;
        if ($result = $db->query("select * from reg where id=$reg_id;")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {
                $van = '';
                while ($row = $result->fetch()) {
                    $nickname = $row->nickname;
                    $passhash = $row->passhash;
                    if ($reg_id = $row->id) {
                        $van = '1';
                        break;
                    }
                }
                if ($van == '1');
                else{
                    $db = null;
                    echo 1;
                    exit;
                }

            } else {
                $db = null;
                echo 0;
                exit;
            }
        } else {
            $db = null;
            echo 0;
            exit;
        }
        $jelszohash = hash('sha256', $p . $nickname);
        $jelszohash = hassolo($jelszohash, $nickname);
        if ($passhash == $jelszohash) {
            $sql = "delete from reg where id=(select reg_id from login where loginkod='$logincode')";
            $db->exec($sql);
            $db=null;
            echo hibauzenetek(403);
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
