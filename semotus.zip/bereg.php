<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo 0;
    exit();
}

function bereg()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'csek.php';

    

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //developer ver, élesben törölni kella komment jelet
        // $sql = "delete from bereg where `time`<" . (time() - 60) . ";";
        // $db->exec($sql);
        // Get the form fields and remove whitespace.
        $klt = $_POST["klt"];
        if (strlen($klt) != 128) exit;

        $ip = $_SERVER['REMOTE_ADDR'];

        $mikene = $_POST['kell'];
        $nick = $_POST['nick'];

        $kikvannak = "";
        $cimeik = "";

        if ($mikene == '1') {
            if ($nick == "") {
                $db = null;
                echo 1;
                exit;
            }
           
            if ($result = $db->query("SELECT `ip`,`kh`,`nick` from  bereg  where kh='".$klt."';")) {
                
                if ($result->rowCount()) {
                  
                    while ($row2 = $result->fetch(PDO::FETCH_NUM)) {
                        if ($row2[1] == $klt && $row2[0] == $ip && $row2[2] == $nick) {
                           
                            $query = "update bereg SET `time`='" . time() . "'  where ip='".$ip."' and kh='" . $klt . "' and nick='" . $nick . "';";
                            $statement = $db->prepare($query);
                            $statement->execute();
                            $db=null;
                            echo "upd";
                            exit;
                        }
                    }

                } else {
                   
                   
                }
            } else {
                $db = null;
                echo 'Error';
                exit;
            }
            $query = $db->prepare("insert into bereg (`kh`,`ip`,`time`,`nick`) VALUES(?,?,?,?);");
            $query->execute(array($klt, $ip, time(), $nick));
            $db = null;
            echo "reg";
            exit;
        } else if ($mikene == '2') {

            if ($result = $db->query("SELECT `ip`,`kh`,`nick` from  bereg  where kh='$klt';")) {
                if ($result->rowCount()) {
                    $sor = "";
                    while ($row2 = $result->fetch(PDO::FETCH_NUM)) {
                        $sor = $row2[1];
                        if ($sor == $klt) { //&& $row2[0] != $ip
                            $kikvannak = $kikvannak.'¤'. $row2[2].':'.$row2[0];
                            // $cimeik .= '*'.$row2[0];
                        }
                    }
                    if ($kikvannak != "") {
                        
                            echo base64_encode($kikvannak);
                            $db = null;
                            exit;
                        
                    } else {
                        echo base64_encode('>>');
                        $db = null;
                        exit;
                    }
                } else {
                    $db = null;
                    echo base64_encode('ures');
                    exit;
                }
            } else {
                $db = null;
                echo base64_encode('Error');
                exit;
            }
        } else if ($mikene == '3') {
            $sql = "delete from bereg where kh='$klt' and ip='$ip' and nick='$nick';";
            $db->exec($sql);
            $db = null;
            echo 'Ok';
            exit;
        } else {
            $db=null;
            echo 'nincs';
            exit;
        }

    } else {
        $db = null;
        echo 'Error';
    }
}
