<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function lista()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'uzeneteim_class.php';
    require_once 'mailmessage_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $logincode_sha1 = $_POST["logincode"];
        $kulcshash = $_POST["tk"];
        $kulcs = hashellenor($kulcshash);
       
        // $ujkulcs = ujkucs($kulcs, SHA1($logincode_sha1));

        $reg_id = kikerdezi($logincode_sha1);

        $kodolt = 0;
        $valasz = '<div id="page-wrapper"><div id="uzikeret"><h1 id="a1"></h1><br><br><ol id="listamess">';
        if ($result = $db->query("SELECT message.uzenet as uzenet, reg.nickname as kuldo, reg.id as kuldoazonositoja, message.time as kuldte, kiknek.id as uzenetazonosito, message.id as valaszcim, kiknek.statusz, message.sor as sor FROM `message` INNER JOIN reg ON reg.id=message.reg_id INNER JOIN kiknek on kiknek.message_id=message.id WHERE kiknek.kinek=$reg_id AND kiknek.statusz=0  order by kuldte asc")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Uzeneteim');
            $uzenetellenor = "";
            if ($result->rowCount()) {
                $admin = 1;
                $meretossz = 0;
                while ($row = $result->fetch()) {
                    $uzenetellenor = gzuncompress($row->uzenet);
                    $keresem = $row->sor;
                    $index = strpos($keresem, ":");
                    $merete = ((int) (substr($keresem, $index + 1)) / 1024 / 1024);

                    if ($merete > 1) {
                        $merete = round($merete);
                    } else {
                        $merete = round($merete, 4);
                    }

                    $statusz = substr($uzenetellenor, 0, 1);
                    if ($statusz == '#') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a3\" style=\"color:white\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";
                    } else if ($statusz == '0') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a4\" style=\"color:green\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";
                    } else if ($statusz == 'f') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a5\" style=\"color:lightblue\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";

                    } else if ($statusz == 'p') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a6\" style=\"color:lightblue\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";

                    } else if ($statusz == '1') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a7\" style=\"color:red\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";
                    
                    } else if ($statusz == 't') {
                        $valasz .= "<li class=\"valaszli\"><h2 class=\"a2\">$row->kuldo </h2><br><h2 class=\"a7a\" style=\"color:orange\"></h2><br><div class=\"a8\" id=\"alap\">" . date('Y F j h:i:s A ', $row->kuldte) . "<br>";
                    }

                    $valasz .= '<h2 class="a9" >' . $merete . ' MB</h2>';
                    $valasz .= "<button class=\"gombok tooltip a11\" id=\"letolt\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a12\"></span></button><button class=\"gombok tooltip a13\" id=\"olvasva\" value=\"$row->uzenetazonosito\"><span class=\"tooltiptext a14\"></span></button></div></li><br><br>";
                    $meretossz = $meretossz + $merete;
                }
                if ($meretossz > 1) {
                    $meretossz = round($meretossz);
                } else {
                    $meretossz = round($meretossz, 3);
                }

                $valasz .= '<h2 class="a10">' . round($meretossz, 3) . ' MB</h2><br><br></ol></div>';

                $db = null;
                // echo responsxor($valasz, $ujkulcs);
                echo base64_encode($valasz); //($valasz, $ujkulcs);
                exit;

            } else {

            }
        } else {
            if ($olvasostatusza != 3) {
                $db = null;
                echo 0;
                exit;
            }
        }

        $db = null;

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
