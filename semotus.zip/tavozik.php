<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function tavozik()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);

        if ($kulcs == null) {
            echo 'Kulcsszinkron hiba. Próbálja meg ujra a műveletet<br>';
            exit;
        }
        $loginkod_sha1 = $_POST['lc'];
        $name;
        $ph;
        $pw = strip_tags(trim(secxor($_POST["p"], $kulcs)));
        $ujkulcs = ujkucs($kulcs, ($tk . $loginkod_sha1));
        $reg_id=kikerdezi($loginkod_sha1);
        if ($result = $db->query("select * from reg where id=$reg_id;")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
            if ($result->rowCount()) {

                while ($row = $result->fetch()) {

                    $name = $row->nickname;
                    $ph = $row->passhash;

                }
                $jelszohash = hash('sha256', $pw . $name);
                $jelszohash = hassolo($jelszohash, $name);
                if ($ph == $jelszohash);
                else{
                    $db = null;
                    echo 3;
                    exit;
                }

            } else {
                $db = null;
                echo 1;
                exit;
            }
        } else {
            $db = null;
            echo 2;
            exit;
        }
        $id = (int) strip_tags(trim(secxor($_POST["sinc"], $kulcs)));
        $statusz = (int) strip_tags(trim(secxor($_POST["st"], $kulcs)));

        if ($statusz < 3) {
            $query = "DELETE FROM reg where id=$id;";
            $db->exec($query);
            $db = null;
        } else if ($statusz == 3) {
            $sql = "delete from reg;";
            $db->exec($sql);
            $sql = "delete from message;";
            $db->exec($sql);
            $sql = "delete from kiknek;";
            $db->exec($sql);
            $sql = "delete from login;";
            $db->exec($sql);
            $sql = "delete from sec;";
            $db->exec($sql);
            $sql = "delete from sikertelen;";
            $db->exec($sql);
            $sql = "delete from uzenetek;";
            $db->exec($sql);
            $db = null;
            exit();
        }
        $db = null;
    } else {
        echo hibauzenetek(403);
    }
}
