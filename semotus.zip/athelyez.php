<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
}


function athelyezes($csa)
{
    include 'd234_kopl_456_db.php';
    include 'athelyez_class.php';
    $reg_id;
    $kinek;
    $lejarat;
    $uzenetszoveg = "";
    $klt;
    if ($result = $db->query("SELECT * from temp413 where azonosito='$csa' ORDER BY id;")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Athelyez');
        if ($result->rowCount()) {
            while ($row = $result->fetch()) {
                $uzenetszoveg .= gzuncompress($row->darab);
                $reg_id = $row->ki;
                $kinek = $row->kinek;
                $lejarat = $row->lejar;
                $klt = $row->klt;
            }
        } else {
            $db = null;
            return 0;
        }
    } else {
        $db = null;
        return 0;
    }
//athelyezés a message tablaba
    if ($klt == 1) {
        $uzenetszoveg = 'p' . $uzenetszoveg;
    } else if ($klt == 2) {
        $uzenetszoveg = 'f' . $uzenetszoveg;
    
    } else if ($klt == 8) {
        $uzenetszoveg = 't' . $uzenetszoveg;
    }
    $utolso_uzenet_id;
    $reszadat;
    $a = 0;
    $hossza = strlen($uzenetszoveg);
    $hosszaor = $hossza;
    $sor = sha1(time() + $hossza);

    $j = 0;
    $uid = 0;
    $i = 0;
    while ($hossza > 0) {

        if ($hossza > 61440) {
            $reszadat = gzcompress(substr($uzenetszoveg, $a, 61440));

        } else {
            $reszadat = gzcompress(substr($uzenetszoveg, $a, $hossza));
            $j = 1;
        }

        $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
        if ($query->execute(array($reg_id, $reszadat, time(), time() + ($lejarat * 60 * 60) + $i, $sor . ':' . $hosszaor)));
        else{
            $db = null;
            return 0;
        }
        $i++;
        if ($uid == 0) {
            $utolso_uzenet_id = $db->lastInsertId();
            $uid = 1;
            kinek($kinek, $reg_id, $utolso_uzenet_id);

        }
        if ($j == 1) {
            break;
        }

        $a += 61440;

        if ($hossza < 61440) {

        } else {
            $hossza = $hosszaor - $a;
        }
    }

    $arr = $query->errorInfo();
    if ($arr != null) {

        // echo responsxor($arr[0] . '--SQL hibakod' . $arr[1] . '--illesztoprogram hibakod' . $arr[2] . '--illesztoprogram hibauzenet', $ujkulcs);
        //echo 1;
    }
    //kiknek
    
    $sql = "DELETE from temp413 where azonosito='$csa';";
    $db->exec($sql);
    $db = null;
    return 1;
    
}
