<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function kuldott()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'csek.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $klt = $_POST["klt"];

        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);
        
        $ujkulcs = ujkucs($kulcs, sha1($tk));
        if ($kulcs == null) {
            echo 0;
            $db = null;
            exit;
        }
        $lejarat = strip_tags(trim(secxor($_POST["lejarat"], $kulcs)));
        if ($klt == 0) {
            $mero = strlen($_POST["uzenetszoveg"]);
            $uzenetszoveg = strip_tags(trim(secxor($_POST["uzenetszoveg"], $kulcs)));
        } else if ($klt == 1) {
            $uzenetszoveg = '1' . $_POST["uzenetszoveg"];
        } else if ($klt == 2) {
            $uzenetszoveg = '0' . $_POST["uzenetszoveg"];
        }

        $kinek = strip_tags(trim(secxor($_POST["kinek"], $kulcs)));
        $ki = strip_tags(trim(secxor($_POST["ki"], $kulcs)));
        $reg_id=kikerdezi($ki);
        
        //beírni az üzenetet akiknek szól
       
        $hossza = strlen($uzenetszoveg);
        $utolso_uzenet_id;
        if ($klt != 0) {
            $reszadat;
            $a = 0;
           
            $hosszaor = $hossza;
            $sor = sha1(time() + $hossza);
            if ($hossza > 61440) {
                $j = 0;
                $uid = 0;
                $i = 0;
                while ($hossza > 0) {

                    if ($hossza > 61440) {
                        $reszadat = gzcompress(substr($uzenetszoveg, $a, 61440));

                    } else {
                        $reszadat = gzcompress(substr($uzenetszoveg, $a, $hossza));
                        $j = 1;
                    }

                    $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
                    if ($query->execute(array($reg_id, $reszadat, time(), time() + ($lejarat * 60 * 60) + $i, $sor . ':' . $hosszaor)));
                    else{
                        echo 0;
                        $db = null;
                        exit;
                    }
                    $i++;
                    if ($uid == 0) {
                        $utolso_uzenet_id = $db->lastInsertId();
                        $uid = 1;
                        kinek($kinek, $reg_id, $utolso_uzenet_id);
                    }
                    if ($j == 1) {
                        break;
                    }

                    $a += 61440;

                    if ($hossza < 61440) {

                    } else {
                        $hossza = $hosszaor - $a;
                    }
                }
            } else {
                $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
                if ($query->execute(array($reg_id, gzcompress($uzenetszoveg), time(), time() + ($lejarat * 60 * 60), $sor . ':' . $hosszaor)));
                else{
                    echo 0;
                    $db = null;
                    exit;
                }
                $utolso_uzenet_id = $db->lastInsertId();
                kinek($kinek, $reg_id, $utolso_uzenet_id);
            }
            $arr = $query->errorInfo();
            if ($arr != null) {

                // echo responsxor($arr[0] . '--SQL hibakod' . $arr[1] . '--illesztoprogram hibakod' . $arr[2] . '--illesztoprogram hibauzenet', $ujkulcs);
                echo 1;
            }

        } else {
            // $hossza = strlen($uzenetszoveg);
            $sor = sha1(time() + $hossza);
            $uzenetszoveg = responsxordatabase($uzenetszoveg, dmsksecd());
            $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
            if ($query->execute(array($reg_id, $uzenetszoveg, time(), time() + ($lejarat * 60 * 60), $sor . ':' . $mero)));
            else{
                echo 0;
                $db = null;
                exit;
            }
            $arr = $query->errorInfo();
            if ($arr != null) {

                // echo responsxor($arr[0] . '--SQL hibakod' . $arr[1] . '--illesztoprogram hibakod' . $arr[2] . '--illesztoprogram hibauzenet', $ujkulcs);
                echo 1;
            }
            $utolso_uzenet_id = $db->lastInsertId();
            kinek($kinek, $reg_id, $utolso_uzenet_id);
        }

        //kiknek

        $db = null;
        exit;
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }

}
