<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function logout()
{

    require_once 'd234_kopl_456_db.php';

    require_once 'secus.php';
    require_once 'csek.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);

        //$logincode = secxor($_POST["logincode"], $kulcs);
        $logincode = ujloginkod($_POST['logincode']);
        $ujkulcs = ujkucs($kulcs, $logincode);

        //bejelentkezett felhasználó loginkod kinulláz a kilépés előtt

        $query = "update login SET `kijelentkezes`='" . time() . "',`loginkod`='kilépve'  where loginkod='$logincode';";
        $statement = $db->prepare($query);
        $statement->execute();
        $db = null;
        echo "logout";

    } else {
        $db = null;
        echo hibauzenetek(404);
        exit;
    }

}
