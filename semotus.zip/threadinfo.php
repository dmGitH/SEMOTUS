<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function threadinfo()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'login_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $logincod_tagid_sha1 = $_POST["lc"];
        // $reg_id=kikerdezi($logincod_tagid_sha1);

        if ($result = $db->query("SHOW STATUS WHERE `variable_name` = 'Threads_connected';")) {

            if ($result->rowCount()) {
                $tr = $result->fetchAll(PDO::FETCH_ASSOC);

                $kiir = $tr[0]['Value'];
                echo "-- $kiir";
                $db = null;
                exit;

            } else {
                $db = null;
                echo 0;
                exit;
            }
        } else {
            $db = null;
            echo 0;
            exit;
        }

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
