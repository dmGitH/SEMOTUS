<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function sucess()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);
        $kapottkod = strip_tags(trim(secxor($_POST["kapottkod"], $kulcs)));

        $ujkulcs = ujkucs($kulcs, $kapottkod);

        //---kell egy lekérdezés hogy ven-e ilyen regkod
        $reg_id;
        $ninckname;
        if ($result = $db->query("select * from reg where hash='$kapottkod';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
            if (!$result->rowCount()) {
                echo responsxor("<h1>----</h1>", $ujkulcs);
                $db = null;
                exit();
            } else {
                while ($row = $result->fetch()) {
                    $reg_id = $row->id;
                    $ninckname = $row->nickname;
                }
            }

        } else {
            echo responsxor("<h1>A megadott regisztrációs kód nem érvényes</h1>", $ujkulcs);
            $db = null;
            exit();
        }

        //-------itt aktiválom az adatbázisban
        if ($result = $db->query("select `aktiv` from reg where aktiv=3 and hash='$kapottkod';")) {

            if ($result->rowCount()) {
                $db = null;
                echo responsxor("<h1>A regisztráció befejeződött.</h1>", $ujkulcs);
                exit();
            }

        }
        $admin_id = aid();
        $query = "update reg SET `aktiv`= 1 where hash='$kapottkod';";
        $db->exec($query);
        //----uzenet az adminnak hogy uj felhasznaló regisztrált

        $uzenetszoveg = "Rendszerüzenet: A csoportba $ninckname néven új tag regisztrált, adminisztrátori aktiválásra vár.";
        $uzenetszoveg .= "System Message: A new member named $ninckname is waiting for the administrator to activate.";
        $hossza = strlen($uzenetszoveg);
        $sor = sha1(time() + $hossza);
        $uzenetszoveg = responsxordatabase($uzenetszoveg, dmsksecd());
        $query = $db->prepare("insert into message (`reg_id`,`uzenet`,`time`,`lejar`,`sor`) VALUES(?,?,?,?,?);");
        $query->execute(array($reg_id, $uzenetszoveg, time(), time() + (168 * 60 * 60), $sor . ':' . $hossza));
        $utolso_uzenet_id = $db->lastInsertId();
        $query = $db->prepare("insert into kiknek (`message_id`,`kinek`,`statusz`) VALUES(?,?,?);");
        $query->execute(array($utolso_uzenet_id, $admin_id, 0));
        $db = null;
        echo responsxor("<h1>A regisztráció befejeződött.</h1>", $ujkulcs);
    } else {
        echo hibauzenetek(403);
    }
}
