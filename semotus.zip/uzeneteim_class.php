<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Uzeneteim
{

    public $uzenet;
    public $kuldo;
    public $kuldte;
    public $uzenetazonosito;
    public $valaszcim;
    public $kuldoazonositoja;
    public $statusz;
    public $sor;


    public function __construct()
    {

    }


}