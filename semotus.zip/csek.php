<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};


function u($c)
{
    if ($c == 'server') {
        return 'user';
    }

}

function p($c)
{
    if ($c == 'server') {
        return 'database_password';
    }

}

function d($c)
{
    if ($c == 'server') {
        return 'mysql:host=127.0.0.1;dbname=database_name';
    }

}

function forvardemailadress(){
    return "info@site.xx";
}

function dmsksec(){
    return "dmsksec_password";
}