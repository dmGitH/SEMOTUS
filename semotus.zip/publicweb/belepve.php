<?php

require_once '../d234_kopl_456_db.php';
require_once '../reg_class.php';
require_once '../login_class.php';
require_once '../secus.php';
require_once '../csek.php';
require_once '../uzenetek_class.php';

//ellenörizd, hogy a felhasználó belépett e és csak akkor engedd ennek az oldalnak a megjelenítését
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
    header("Pragma: no-cache"); // HTTP 1.0.
    header("Expires: 0"); // Proxies.

    if(count($_GET)!=3){
        header("Location: https://dm.semotus.hu/index.php"); /* Redirect browser */
        exit();
    }

    $tk = $_GET["tk"];
    $kulcs = hashellenor($tk);
    $nyelv = $_GET["nyelv"];
    
    // Get the form fields and remove whitespace.

    $loginkod = secxor($_GET["loginkod"], $kulcs);
    $ujkulcs=ujkucs($kulcs,sha1($tk));
    $name;
    $reg_id;
    $passhashmd5;
    //itt ellenorizni kell hogy a loginkod szerepel e az adatbázisban
    if ($result = $db->query("select * from login where loginkod='$loginkod';")) {
        $result->setFetchMode(PDO::FETCH_CLASS, 'Login');
        if ($result->rowCount()) {

            while ($row = $result->fetch()) {

                $reg_id = $row->reg_id;
                $loginkod = $row->loginkod;
                
            }

        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;

        }

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }

} else {
    $db = null;
    echo hibauzenetek(403);
    exit;
}
//a nicnev és a loginstusz kikeresése
$felhasznalostusza;
$voltproba = 0;
$java_uzenetszam_lekerdezo_kliens_kod;
if ($result = $db->query("select * from reg where id='$reg_id';")) {
    $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
    if ($result->rowCount()) {

        while ($row = $result->fetch()) {
            $name = $row->nickname;
            $felhasznalostusza = $row->aktiv;
            $passhashmd5 = md5($row->passhash);
            $java_uzenetszam_lekerdezo_kliens_kod= substr(base64_encode(sha1($row->passhash . $row->dmsk)), 0, 40);
        }
        if ($result2 = $db->query("SELECT count(username) FROM `sikertelen` where `username`='" . $name . "';")) {
            if ($result2->rowCount()) {
                $eredmeny = $result2->fetchAll(PDO::FETCH_NUM);
                $voltproba = $eredmeny[0][0];
                // echo $voltproba;
                // $db=null;
                // exit;
                $sql = "DELETE from sikertelen where username='$name';";
                $db->exec($sql);
            } else {

            }

        } else {

        }

    }
} else {
    $db = null;
    echo hibauzenetek(403);
    exit;
}

$sql = "delete from sec where kulcs='$kulcs';";
$db->exec($sql); //ujloginkod($loginkod)
$ujloginkod= ujloginkod(sha1($loginkod));
$update= "UPDATE `login` SET `loginkod`='$ujloginkod' WHERE `loginkod`='$loginkod';" ;
$db->exec($update);

?>
<!DOCTYPE HTML>
<html lang="hu">
<head id="head">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Cache-control" content="no-chache">
    <title id="title">Bejelentkezve</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Description" content="private communication web application, author: matyo95">
    <meta name="theme-color" content="#d2691e"/>
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" href="css/jquery-ui.css" />
    <link href="css/fonts.css" rel="css/stylesheet" type="text/css" />
     <link rel="stylesheet" href="css/pie.css"/>
    <link rel="manifest" href="manifest.json">
     <?php
    echo '<style> ' . file_get_contents("css/master.css") . ' </style>';
    ?>
</head>
<body id="body" onload="kulcsszinkron()<?php if ($voltproba != 0) {
    echo ',belepesprobak(' . $voltproba . ')';
}
?>">
     <img id="ks" src="ico/burn.png" alt="on">
    <img id="fel" src="ico/le.png" alt="upp">
    <img id="le" src="ico/fel.png" alt="down">
    <img id="lang" src="ico/hun.png" alt="language">

    <h2 id="ofpng" style="color:red">OFFLINE</h2>
    <nav class="nav">
         <span>S</span><span>E</span><span>M</span><span>O</span><span>T</span><span>U</span><span>S.</span><span>A</span><span>P</span><span>P</span>
        <div id="szszam"></div>
        <div id="szhiba"></div>
    </nav>
    <br>
    <br class="eltuntetni">
    <br class="eltuntetni">
    <div class="divh1">
        <h1 id="focim" class="eltuntetni"></h1>
    </div>
    <div class="buttons" id="menu">
    <?php
if ($felhasznalostusza >= 1) {
    echo "<button class=\"gombok tooltip\" id=\"kijelentkezes\"></button>";
    echo "<button class=\"gombok tooltip\" id=\"full\"></button>";
}
if ($felhasznalostusza > 1) {
    echo "<button class=\"gombok tooltip\" id=\"uzenetek\"></button>";
}
if ($felhasznalostusza > 1) {
    echo "<button class=\"gombok tooltip\" id=\"uzenetkuldes\"></button>";
    echo "<button class=\"gombok tooltip\" id=\"dmsk_setup\"></button>";
}
if ($felhasznalostusza < 3) {
    echo "<button class=\"gombok tooltip\" id=\"beallitasok\"></button>";

}
if ($felhasznalostusza >= 3) {
    echo "<button class=\"gombok tooltip\" id=\"admin\"></button>";
}
?>
  </div>

    <br><br class="rejtett"><br class="rejtett"><br class="rejtett">
    <?php
if ($felhasznalostusza == 1) {
    echo '<div id="ki"><h1 class="ki1">';
}
if ($felhasznalostusza == 2) {
    echo '<div id="ki"><h1 class="ki2">';
}
if ($felhasznalostusza == 3) {
    echo '<div id="ki"><h1 class="ki3">';
}
echo '</h1>'
?></div>
    <div class="container" id="div1">
    </div>

    <div class="fb" id="feed_back">
    </div>
    <div id="fogomb">
        <img src="ico/enter.png" id="vegrehajt" value="" />
    </div>
    <div class="test"></div>
    <script src="js/TweenMax.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/nyelvek.js"></script>
   <script>
    document.addEventListener("touchstart", function() {},false);
    </script>

    <script>
    <?php
  
echo file_get_contents("../js/sha1.js");
echo file_get_contents("../js/sha2.js");
echo file_get_contents("../js/lz-string.min.js");
echo file_get_contents("../js/Blob.js");
echo file_get_contents("../js/ajax-be.js");
echo file_get_contents("../js/belepett.js");
echo file_get_contents("../js/ajax-index.js");

    echo ' var ego="' . $loginkod . '"; ';
    echo ' var dmsk240B="'.$ujkulcs.'"; ';
    echo ' var atma="'. $passhashmd5 .'"; ';
    echo ' var juszlkk="'. $java_uzenetszam_lekerdezo_kliens_kod .'"; ';

echo file_get_contents("../js/motor.js");
echo file_get_contents("../js/ping.js");
   
echo ' var nyelv='.$nyelv.'; ';

echo file_get_contents("../js/master.js");
echo ' setup(nyelv); ';
if ($felhasznalostusza >= 3) {
    echo file_get_contents("../js/a.js");
}if ($felhasznalostusza > 1) {
    echo file_get_contents("../js/sec.js");
}

?></script>
    
    <script>setTimeout(tagidlistabetoltese,5000);</script>
    <br/>
    <p id="allapotjelzo"><?php if ($felhasznalostusza > 1) {
    echo "15";
} else {
    echo "30";
}
?></p>
    <p id="sincronmp"><?php if ($felhasznalostusza > 1) {
    echo "29";
} else {
    echo "55";
}
?></p>
    
    <br/>
    <p id="pt"></p>
    <p id="mentettuzenet"></p>
    <p id="szinkron"></p>
    <p id="katt"></p>
    <p id="kszkibe">be</p>
    <p id="osszuzenet"></p>
    <p id="mentettuzenetlista"></p>
    <div id="tagid"></div>
    <div class="mk-spinner-wrap" id="pie">
          <div class="mk-spinner-pie"></div>
    </div>
    <div class="keptarto">
    <img class="keptarto" src="ico/info.png" alt="katt"/>
    <img class="keptarto" src="ico/eszkozok.png" alt="eszkozok"/>
    <img class="keptarto" src="ico/gear.png" alt="gear"/>
    <img class="keptarto" src="ico/lock.png" alt="zar"/>
    <img class="keptarto" src="ico/ulock.png" alt="nyit"/>
    <img id="hun" class="keptarto" src="ico/eng.png" alt="angol"/>
    <img id="eng" class="keptarto" src="ico/hun.png" alt="magyar"/>

    </div>
    
    <input type="file"  name="fel" id="felf"/>
    <input type="file" name="filed" id="dekodfile"/>
    <div id="hanguzenet">
         <h1>Hangrögzítés</h1>
    
    <p>A hangfelvétel konvertálása:<br>
        <select id="encodingTypeSelect">
            
            <option value="mp3">MP3 (MPEG-1) (.mp3)</option>
            <option value="ogg">Ogg Vorbis (.ogg)</option>
        </select>
    </p>
    <div id="controls">
        <button id="recordButton">Felvétel időlimit 2 minute</button>
        <button id="stopButton" disabled>Stop</button>
    </div>
    <div id="formats"></div>
    <h3>Log</h3>
    <pre id="log"></pre>

    <h3></h3>
    <button id="megsemhang">CLOSE-CLEAR</button>
    
    <script src="js/WebAudioRecorder.min.js"></script>
    <script src="js/app.js"></script>
    <script>
if('serviceWorker' in navigator) {
  navigator.serviceWorker
           .register('js/sw.js')
           .then(function() { console.log("Service Worker Registered"); });
}
</script>
    </div>
    <footer class="footer">
    <div class="statuszsor" id="statusz">

        <span class="statuszspan" id="uzenetszam" <?php
if ($result = $db->query("select id from kiknek where kinek='$reg_id' and statusz=0;")) {
    $result->setFetchMode(PDO::FETCH_CLASS, 'Uzenetek');
    $i = 0;
    if ($result->rowCount()) {
        while ($row = $result->fetch()) {
            $id = $row->id;
            $i++;
        }
        echo " style=\"color:lightgreen\">" . $i . "&nbsp;<img id=\"messimg\" src=\"ico/env.png\" alt=\"env\"/></span>";
    } else {
        echo " style=\"color:lightgreen\">" . $i . "&nbsp;<img id=\"messimg\" src=\"ico/env.png\"  alt=\"env\"/></span>";
    }
} else {
    $db = null;
    echo hibauzenetek(403);
    exit;
}
$db = null;
?><div class="progress" id="bar"></div></div>
    <h3 id="help" class="footer-h3">&copy; Matyo95  (no Cookie) Online help Ctrl+F1</h3>
    </footer>

</body>
</html>