<!DOCTYPE HTML>
<html id="fooldal" lang="hu">
<head>
    <meta http-equiv="Cache-control" content="no-chache">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="Description" content="private communication web application, author: matyo95">
    <meta name="theme-color" content="#d2691e"/>
    <meta name="google-site-verification" content="bUqDek6k0iVa56w35PMB7C3zY7B1IHfxmPXj_RaG2ic" />
    <title>Főoldal</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/fonts.css" rel="css/stylesheet" type="text/css" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" href="css/pie.css"/>
    <link rel="manifest" href="manifest.json">

     <?php
    echo '<style> '.file_get_contents("css/master.css").' </style>';
    ?>
</head>
<body onload="kulcsszinkron(),feliratok()">
    <noscript>
            <div class="alert alert-warning">
                it does not work without javascript sorry (Ez az oldal jávaszcript nélkül sajnálom, de nem működik)
            </div>
        </noscript>
<img id="ks" src="ico/burn.png" alt="keysinc" oncontextmenu="return false;">
<img id="fel" src="ico/le.png" alt="upp">
 <img id="lang" src="ico/hun.png" alt="language">
    <img id="le" src="ico/fel.png" alt="down">
<h2 id="ofpng" style="color:red">OFFLINE</h2>
<nav class="nav">
   <span>S</span><span>E</span><span>M</span><span>O</span><span>T</span><span>U</span><span>S.</span><span>A</span><span>P</span><span>P</span>
</nav>
<br>

<br>
<div class="divh1">

</div>

<div class="buttons" id="menu">
    <button class="gombok tooltip" id="info">
    </button>
    
    
    <button class="gombok tooltip" id="kozlemeny">
    </button>
    <button class="gombok tooltip" id="regisztracio">
    </button>
</div>
<br>
<div class="container" id="div1">

</div>
<div class="fb" id="feed_back"></div>
<div id="fogomb">
    <input type="button" id="btn" value=""/>
    <br>
    <br>
</div>

<div class="test"></div>
<div class="keptarto">
    
    <img id="hun" class="keptarto" src="ico/eng.png" alt="angol"/>
    <img id="eng" class="keptarto" src="ico/hun.png" alt="magyar"/>
    
</div>
<script src="js/TweenMax.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/nyelvek.js"></script>
<script>
    document.addEventListener("touchstart", function() {},false);
</script>
<script>

 <?php
echo file_get_contents("../js/sha1.js");
echo file_get_contents("../js/sha2.js");
echo file_get_contents("../js/Blob.js");
echo file_get_contents("../js/ping.js");
echo file_get_contents("../js/lz-string.min.js");
echo file_get_contents("../js/ajax-index.js");
echo ' var ego="start"; ';
echo ' var dmsk240B=""; ';
echo ' var atma="start"; ';

echo file_get_contents("../js/motor.js");
echo ' var nyelv=1; '; //default language code setup
echo file_get_contents("../js/master.js");
 ?>
</script>
<script>
if('serviceWorker' in navigator) {
  navigator.serviceWorker
           .register('js/sw.js')
           .then(function() { console.log("Service Worker Registered"); });
}
</script>
<br/><p id="allapotjelzo"><?php echo "60";?></p>
    <p id="sincronmp"><?php echo "60";?></p>
    <div class="mk-spinner-wrap" id="pie">
          <div class="mk-spinner-pie"></div>
    </div>
<br/>

<footer class="footer">
<h3 id="help" class="footer-h3">&copy; Matyo95 (no Cookie)</h3>
</footer>
</body>
</html>