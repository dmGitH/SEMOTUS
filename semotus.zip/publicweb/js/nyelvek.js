// nyelvek: myagyar(HUN) 1
// 


function szovegetide(milyennyelven, hovakered) {

    if (milyennyelven == 1) {
        switch (hovakered) {
            case 1:
                return 'Teljeskép-ki<span class=\"tooltiptext\">Teljes képernyős mód ki és bekapcsolása</span>';
            case 2:
                return 'Teljeskép-be<span class=\"tooltiptext\">Teljes képernyős mód ki és bekapcsolása</span>';
            case 3:
                return '<audio controls autoplay hidden><source src=\"1.mp3\" type=\"audio/mpeg\"></audio>';
            case 4:
                return 'Üzenet: ';
            case 5:
                return '<img id=\"messimg\" src=\"ico/error.png\"><img id=\"messimg\" src=\"ico/erdsmk.png\">';
            case 6:
                return '<img id=\"messimg\" src=\"ico/error.png\">';
            case 7:
                // return '<div id="adatvedelem">' +
                //     '<h2></br>ADATVÉDELMI ÉS ADATKEZELÉSI SZABÁLYZAT 2018. </br>Hatályos: 2018. május 25. napjától</h2><h3>Általános rendelkezések</h3> A Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95), mint az Adatkezelő aáltala üzemeltetett http:// egyuttmozgas.probaljaki.hu weboldal és az ott meghatározott egyéb címeken elérhető weboldalak(a továbbiakban: „weboldal”) által nyújtott szolgáltatásaihoz kapcsolódóan a felhasználó természetes személyek („ügyfél“) valamennyi adatkezelése során a jelen Adatvédelmi és Adatkezelési Szabályzat és Tájékoztató alapján jár el. Az Ügyfél a weboldalra történő belépéssel, és a weboldal használatával magára nézve kötelezőnek fogadja el a jelen szabályzat rendelkezéseit. A szabályzat célja, hogy meghatározza az Adatkezelő által kezelt személyes adatok körét, az adatkezelés módját, valamint biztosítsa az adatvédelem és adatkezelés alkotmányos elveinek, az adatbiztonság követelményeinek érvényesülését annak érdekében, hogy a felhasználó természetes személyek magánszférájának a tiszteletben tartása megvalósuljon az érintettek személyes adatainak gépi feldolgozása, illetőleg kezelése során. <h3>1. Értelmező rendelkezések</h3> <h4>1.1. Adatkezelő:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, a ki vagy amely önállóan vagy másokkal együtt az adat kezelésének célját meghatározza, az adatkezelésre (beleértve a felhasznált eszközt) vonatkozó döntéseket meghozza és végrehajtja, vagy az adatfeldolgozóval végrehajtatja.<h4> 1.2. Adatkezelés:</h4> az alkalmazott eljárástól függetlenül az adaton végzett bármely művelet vagy a műveletek összessége, így különösen gyűjtése, felvétele, rögzítése, rendszerezése, tárolása, megváltoztatása, felhasználása, lekérdezése, továbbítása, nyilvánosságra hozatala, összehangolása vagy összekapcsolása, zárolása, törlése és megsemmisítése, valamint az adat további felhasználásának megakadályozása, fénykép-, hang- vagy képfelvétel készítése, valamint a személy azonosítására Adatvédelmi és Adatkezelési Szabályzat 2018 2 alkalmas fizikai jellemzők (pl. ujj- vagy tenyérnyomat, DNS-minta, íriszkép) rögzítése. <h4>1.3. Személyes adat:</h4> az érintettel kapcsolatba hozható adat - különösen az érintett neve, azonosító jele, valamint egy vagy több fizikai, fiziológiai, mentális, gazdasági, kulturális vagy szociális azonosságára jellemző ismeret -, valamint az adatból levonható, az érintettre vonatkozó következtetés.<h4> 1.4. Hozzájárulás:</h4> az érintett akaratának önkéntes és határozott kinyilvánítása, amely megfelelő tájékoztatáson alapul, és amellyel félreérthetetlen beleegyezését adja a rá vonatkozó személyes adat- teljes körű vagy egyes műveletekre kiterjedő – kezeléséhez. <h4>1.5. Adatfeldolgozás:</h4> az adatkezelési műveletekhez kapcsolódó technikai feladatok elvégzése, függetlenül a műveletek végrehajtásához alkalmazott módszertől és eszköztől, valamint az alkalmazás helyétől, feltéve hogy a technikai feladatot az adaton végzik. <h4>1.6. Adatfeldolgozó:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, aki vagy amely szerződés alapján - beleértve a jogszabály rendelkezése alapján kötött szerződést is - adatok feldolgozását végzi. <h4>1.7. Érintett:</h4> bármely meghatározott, személyes adat alapján azonosított vagy - közvetlenül vagy közvetve - azonosítható természetes személy.<h3> 2. Az adatkezelő megnevezése : </h3>Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95. Email: <span id="emailcim">milena&copy;egyuttmozgas.probaljaki.hu</span> évi CXII. törvény 65. § (3) a) pontja értelmében nem vezet adatvédelmi nyilvántartást a Hatóság arról az adatkezelésről, amely az adatkezelővel munkaviszonyban, tagsági viszonyban, - a pénzügyi szervezetek, közüzemi szolgáltatók, elektronikus hírközlési szolgáltatók ügyfelei kivételével - ügyfélkapcsolatban álló személyek adataira vonatkozik.<h3> 3. Az adatok megismerésére jogosult természetes és jogi személyek, az adatfeldolgozó:</h3> Az adatokat az Adatkezelő Alapszabályában és SZMSZ-ében meghatározott vezetősége, illetve a vezetőség által külön ferre felhatalmazott Adatvédelmi és Adatkezelési Szabályzat 2018 3 személyek jogosultak megismerni Adatkezelő az adatokat nem teszik közzé, harmadik személyek számára nem adják ki.<h3> 4. A kezelt személyes adatok köre:</h3> A jelen szabályzat kizárólag a természetes személyek adatainak a kezelésére terjed ki, tekintettel a szabályzat arra, hogy személyes adatok kizárólag természetes személyek vonatkozásában értelmezhetők. A Weboldal bármely internethasználó által regisztráció nélkül hozzáférhető tartalmakat is biztosít. Bizonyos tartalmi szolgáltatásai és hírlevél funkciója azonban csak regisztrált felhasználók számára hozzáférhető. Regisztrált felhasználó az lehet, akit a az Adatkezelő a saját belső szabályzatának megfelelően erre feljogosít. A regisztráció folyamata ingyenes. <h4>4.1. A regisztráció során az Ügyfélnek kötelezően meg kell adnia a következő személyes adatokat:</h4> <li> Ügyfél neve,</li> <li>E-mail címe</li> <h4> 4.2.</h4> A www.egyuttmozgas.probaljaki.hu (továbbiakban: Weboldal) adatbázisa az Ügyfél adatait a regisztrációval nyújtott ingyenes szolgáltatások teljesítése érdekében tárolja, azokat az adatkezelő továbbadni sem reklámfelhasználás, sem egyéb célra - az Ügyfél kifejezett hozzájárulása hiányában - nem jogosult. <h4>4.3.</h4> A Weboldalon tett látogatások során egy vagy több cookie-t - apró információcsomagot, amelyet a szerver küld a böngészőnek, majd a böngésző visszaküld a szervernek minden, a szerver felé irányított kérés alkalmával - küldünk az Ügyfél számítógépére, amely(ek) révén annak böngészője egyedileg azonosítható lesz. Ezen cookie-k kizárólag a felhasználói élmény javítása, a belépési folyamat automatizálása, valamint reklámtevékenységünk hatékonyságának mérése érdekében működnek. <h4>4.4.</h4> Az Ügyfél személyes adatainak kezelése során a Szolgáltató betartja az információs önrendelkezési jogról szóló 2011. évi CXII. törvény előírásait. <h4>4.5.</h4> Az Ügyfél mindenkor jogosult az adatkezelést letiltani. <h3>5. Az adatkezelés jogalapja, módja és célja Adatvédelmi és Adatkezelési Szabályzat 2018 </h3> <h4>5.1.</h4> Az adatkezelés jogalapja az Ügyfél önkéntes hozzájárulása. A hozzájárulást az Ügyfél a fentiekben megjelölt adatok kezelése tekintetében jelen adatvédelmi szabályzat előzetes megismerését követően a regisztrációval, a kérdéses adatok önkéntes megadásával adja meg. A hírlevéllel kapcsolatban az Ügyfél az erre vonatkozó jelölőnégyzet kipipálásával kifejezett és önkéntes hozzájárulását adja ahhoz, hogy Adatkezelő a Weboldallal kapcsolatos híreket, információkat küldjön az Ügyfél által a regisztráció során megadott e-mail címre. <h4>5.2.</h4> Az adatkezelés célja a tartalomszolgáltatás és az ezzel, valamint az Adatkezelő egyesület működésével összefüggő egyéb információk megadása. A Szolgáltató az Ügyfél által rendelkezésre bocsátott adatokat célhoz kötötten tárolja. Ügyfél a weboldalon történő regisztrációval hozzájárul ahhoz, hogy személyes adatait az alábbi célokra felhasználhassuk:  hírlevél szolgáltatás tartalomszolgáltatás <h4>5.3.</h4> A regisztráció során megadott elektronikus levélcímek (e-mail címek) adatkezelő általi felhasználásának módja a következő: az e-mail címek kezelése az ügyfél azonosítását, a szolgáltatások igénybevétele során a kapcsolattartási célokat, illetőleg az ügyfél részére hírlevél megküldésére szolgál. Adatkezelő az általa nyújtott szolgáltatásokra vonatkozó tájékoztatást elektronikus formában, e-mailben juttatja el ügyfél részére. Adatkezelő az ügyfél kifejezett hozzájárulásával küld a regisztráció során megadott e-mail címre a Weboldal tartalmaival és a gyakorlások szervezésével kapcsolatos információkat tartalmazó hírleveleket. Adatkezelő kizárólag azon ügyfelei számára küld hírleveleket, akik az erre szolgáló menüpontban ehhez kifejezett hozzájárulásukat adták.<h4> 5.4.</h4> Az Ügyfél a hírlevél szolgáltatásról bármikor, ingyenesen és indoklás nélkül leiratkozhat. A leiratkozás történhet egyetlen lépésben, a hírlevélben található linkre kattintással, illetve leiratkozhat az Adatkezelőnek küldött e-mail formájában is. Ebben az esetben Adatkezelő haladéktalanul törli a nyilvántartásából az Ügyfél adatait. <h4>5.5.</h4> Az Ügyfél által megadott telefonszám adatkezelő általi felhasználási célja a következő: az folyamat során kapcsolattartási célokat szolgál. <h4>5.6.</h4> Az Ügyfél adatait kizárólag számítástechnikai eszközzel végrehajtott adatfeldolgozással kezeljük. Az automatikusan rögzítésre kerülő adatok célja statisztika-készítés, az informatikai rendszer technikai fejlesztése, a felhasználók jogainak védelme. Az automatikusan rögzítésre kerülő adatok az alábbiak: az ügyfél számítógépének dinamikus IP címe, az ügyfél számítógépének beállításaitól függően az ügyfél által használt számítógép operációs rendszerének és böngészőjének típusa, az ügyfélnek a Weboldallal kapcsolatos aktivitása. Ezen adatok felhasználása egyrészről technikai célokat szolgál - pl. a szerverek biztonságos üzemeltetése, utólagos ellenőrzése, másrészt az Adatkezelő ezen Adatvédelmi és Adatkezelési Szabályzat 2018 5 adatokat oldalhasználati statisztikák készítéséhez, a felhasználói igények elemzéséhez használja fel a szolgáltatások színvonalának emelése érdekében. A fenti adatok az ügyfél azonosítására nem alkalmasak, és ezeket a Szolgáltató egyéb személyes adatokkal nem kapcsolja össze. <h4>5.7.</h4> Az adatkezelő a megadott személyes adatokat az e pontokban írt céloktól eltérő célokra nem használhatja fel. Személyes adatok harmadik személynek vagy hatóságok számára történő kiadása - hacsak törvény ettől eltérően nem rendelkezik kötelező erővel - a felhasználó előzetes, kifejezett hozzájárulása esetén lehetséges kizárólag.<h4> 5.8.</h4> Adatkezelő a neki megadott személyes adatokat nem ellenőrzi. A megadott adatok megfelelőségéért kizárólag az azt megadó személy felel..' +
                //     "Bármely Ügyfél e-mail címénekmegadásakor egyben felelősséget vállal azért, hogy a megadott e-mail címről kizárólag ő vesz igénybe szolgáltatást. E felelősségvállalásra" +
                //     "tekintettel egy megadott e-mail címen történt belépésekkel összefüggő mindennemű felelősség kizárólag azt a felhasználót terheli, aki az e-mail címet regisztrálta.<h3> 6. Az adatkezelés időtartama</h3> <h4>6.1.</h4> A regisztráció során kötelezően megadott adatok kezelése a regisztrációval kezdődik és annak törléséig tart. Nem kötelező adatok esetén az adatkezelés az adat megadásának időpontjától a kérdéses adat törléséig tart. A regisztráció során rögzített adatok megváltoztatását, vagy törlését a regisztrált Ügyfél a bejelentkezést követően a „Saját fiókban” kezdeményezheti. <h4>6.2.<h4> Fenti rendelkezések nem érintik a jogszabályban (pl. számviteli jogszabályokban) meghatározott megőrzési kötelezettségek teljesítését. <h3>7. Az adatokat megismerni jogosult személyek köre</h3> <h4>7.1.</h4> Az adatokat elsődlegesen Adatkezelő, illetve Adatkezelő belső munkatársai jogosultak megismerni, azonban azokat nem teszik közzé, harmadik személyek részére nem adják át.<h4> 7.2.</h4> Az alapul fekvő informatikai rendszer üzemeltetése, a megrendelések teljesítése, az elszámolás rendezése körében Adatkezelő adatfeldolgozót (pl. rendszerüzemeltető, könyvelő) vehet igénybe. Adatkezelő az ilyen külső szereplők adatkezelési gyakorlatáért nem felelős.<h4> 7.3. </h4>A fentieken túl az Ügyfélre vonatkozó személyes adatok továbbítására kizárólag törvényben kötelezően meghatározott esetben, illetve az Ügyfél hozzájárulása alapján kerülhet sor. <h3>8. Az ügyfél jogai Adatvédelmi és Adatkezelési Szabályzat 2018 6</h3> <h4>8.1.</h4> Az Ügyfél bármikor jogosult tájékoztatást kérni a Adatkezelő által kezelt, rá vonatkozó személyes adatokról, továbbá bármikor módosíthatja azokat. Ügyfél jogosult továbbá adatai törlésének kérésére az e pontban megadott elérhetőségek útján. <h4>8.2.</h4> Szolgáltató az Ügyfél kérésére tájékoztatást ad a rá vonatkozó, általa kezelt adatokról, az adatkezelés céljáról, jogalapjáról, időtartamáról, továbbá arról, hogy kik és milyen célból kapják vagy kapták meg adatait. Szolgáltató a kérelem benyújtásától számított 30 napon belül írásban adja meg a kért tájékoztatást.<h4> 8.3.</h4> Az Ügyfél bármely, az adatkezeléssel kapcsolatos kérdéssel, illetve észrevétellel az Adatkezelő munkatársához fordulhat a fenti elérhetőségeken keresztül. Levelezési cím: 6070 Izsák Matyó 95<h4> 8.4.</h4> Az Ügyfél bármikor jogosult a helytelenül rögzített adatainak helyesbítését, vagy azok törlését kérni. Egyes adatait az Ügyfél a Honlapon maga helyesbítheti; egyéb esetekben Szolgáltató a kérelem beérkezésétől számított 3 munkanapon belül törli az adatokat, ez esetben azok nem lesznek újra helyreállíthatók. A törlés nem vonatkozik a jogszabály (pl. számviteli szabályozás) alapján szükséges adatkezelésekre, azokat Szolgáltató a szükséges időtartamig megőrzi.<h4> 8.5.</h4> Az ügyfél bíróság előtt érvényesítheti jogait, kérheti továbbá az adatvédelmi biztos segítségét is. Ügyfél, jogsértés esetén jogorvoslatért fordulhat: az Adatvédelmi Biztos Hivatalához (1051 Budapest, Nádor u. 22.) A Nemzeti Adatvédelmi és Információszabadság Hatósághoz<h4> 8.6.</h4> Amennyiben az Ügyfél szolgáltatás igénybevételéhez a regisztráció során harmadik fél adatait adta meg, vagy a Weboldal használata során bármilyen módon kárt okozott, a Szolgáltató jogosult az Ügyféllel szembeni kártérítés érvényesítésére. A Szolgáltató ilyen esetben minden tőle telhető segítséget megad az eljáró hatóságoknak a jogsértő személy személyazonosságának megállapítása céljából. <h3>9. Egyéb rendelkezések </h3><h4>9.1.</h4> Szolgáltató rendszere a felhasználók aktivitásáról adatokat gyűjthet, melyek nem kapcsolhatóak össze a felhasználók által a regisztrációkor megadott egyéb adatokkal, sem más honlapok vagy szolgáltatások igénybevételekor keletkező adatokkal. <h4>9.2.</h4> Minden olyan esetben, ha a szolgáltatott adatokat a Szolgáltató az eredeti adatfelvétel céljától eltérő célra kívánja felhasználni, erről a felhasználót tájékoztatja, és ehhez előzetes, kifejezett hozzájárulását megszerzi, illetőleg lehetőséget biztosít számára, hogy a felhasználást megtiltsa. <h4>9.3.</h4> Szolgáltató kötelezi magát, hogy gondoskodik az adatok biztonságáról, megteszi továbbá azokat a technikai intézkedéseket, amelyek biztosítják, hogy a felvett, tárolt, illetve kezelt adatok védettek legyenek, illetőleg mindent megtesz annak érdekében, hogy megakadályozza azok megsemmisülését, jogosulatlan felhasználását és jogosulatlan megváltoztatását. Kötelezi magát arra is, hogy Adatvédelmi és Adatkezelési Szabályzat 2018 7 minden olyan harmadik felet, akiknek az adatokat esetlegesen továbbítja vagy átadja, ugyancsak felhívja ez irányú kötelezettségeinek teljesítésére. <h4>9.4.</h4> Szolgáltató fenntartja a jogot, hogy jelen Szabályzatot az Ügyfelek előzetes értesítése mellett egyoldalúan módosítsa. A módosítás hatályba lépését követően az Ügyfél a szolgáltatás használatával ráutaló magatartással elfogadja a módosított Szabályzatban foglaltakat. Az Adatkezelő magára nézve kötelezőnek ismeri el jelen szabályzat tartalmát, és kötelezettséget vállal arra, hogy szolgáltatásával kapcsolatos adatkezelése megfelel a jelen szabályzatban megfogalmazott előírásoknak." +
                //     "</div>";
                return;
            case 8:
                return '<div id="page-wrapper"><h3>Kövesd a leírtakat. A WebApp alapértelmezésben DMSK-240B titkosítást használ az adatok küldéséhez és fogadásához. (Regisztráció után választható opciók : DMSK-240B-FULL , O.T.P , valamint jelszavas  titkosítások, szöveg és fájlátvitelhez.)</h3><br /><h1>Regisztráció</h1><div class="field"><label for="name">Add meg a felhasznlói neved:</label><input type="text" id="name" ><div id="regisztral" class="field"><label >Add meg az email címed:</label><input type="email" id="email"></div></div>'; //----
            case 9:
                return '<div id="page-wrapper"><h1 id="tajekoztato">Regisztrációs adatok törlése</h1><br /><h3>Biztos vagy benne? Ha igen, kattints a Végrehajtás feliratu gombon. Ha mégsem válassz más menüpontot. A regisztrációs adataid törlésével nem tudsz újra bejelentkezni csak ha ismét regisztrálod magad.</h3></div>';
            case 10:
                return szovegetide(1, 62) + '<br />A régi jelszavad nem lehetett kevesebb mint 10 karakter. Kérem ellenőrizd a beírt jelszót.';
            case 11:
                return szovegetide(1, 62) + '<br />A régi jelszó nem az érvényes jelszavad.';
            case 12:
                return szovegetide(1, 62) + '<br />Az új jelszó hossza, minimum 10 karakter kell, hogy legyen.';
            case 13:
                return szovegetide(1, 62) + '<br />A jelszó meg nem engedett, karaktert tartalmaz.';
            case 14:
                return szovegetide(1, 62) + '<br />A két új jelszó mező értéke nem egyforma .';
            case 15:
                return szovegetide(1, 62) + '<br />A felhasználói neved minimum 4 karakter legyen.';
            case 16:
                return szovegetide(1, 62) + '<br />A felhasználói neved nem megengedett, karaktert tartalmaz.';
            case 17:
                return szovegetide(1, 62) + '<br />A megadott felhasználói név már foglalt.';
            case 18:
                return szovegetide(1, 62) + '<br />A jelszó módosítása nem sikerült.';
            case 19:
                return szovegetide(1, 62) + '<br />Az adatok módosítása megtörtént.';
            case 20:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy a csoportból mindenkinek, vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig vagy az általad megadott maximális ideig érhatőek el. Utánna a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.<button class="gombok" id="413">413 statusz</button></h3><br><div>' + '<center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all" >Üzenet küldése, mindenkinek<br><input type="radio" name="kuldes" value="select" checked="checked">Üzenet küldése a kiválasztott tagoknak<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div>' + '<br>' + filefelt + '<br>'+hangfelt+'<img id="uzenetkuldesinfo2" src="ico/info.png"><label>Üzenet szövege</label><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft"></textarea>' + '<br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"><br></div>';
            case 21:
                return szovegetide(1, 62) + '<br />Hiba a taglista letöltésekor. Próbáld újra.';
            case 22:
                return szovegetide(1, 62) + '<br />Hiba a kapcsolatban vagy a kapcsolat offline.';
            case 23:
                return szovegetide(1, 62) + '<br />Nem választottál címzettet.';
            case 24:
                return szovegetide(1, 62) + '<br />Nem írtál be üzenetet. Az üres üzenet, nem lett elküldve.';
            case 25:
                return szovegetide(1, 62) + '<br />Üzenet mentve, online allapotban elküldésre kerül. Ha előtte kilépsz az alkalmazásból vagy bezárod a weboldalt az üzenet nem kerül elküldésre.';
            case 26:
                return 'Elküldve: ';
            case 27:
                return 'Hiba! Az üzenet elküldése valószínüleg nem sikerült.';
            case 28:
                return szovegetide(1, 62) + '<br />Üzenet elküldve.';
            case 29:
                return '<div id="page-wrapper"><h2>Üzenetek megjelenítéséhez kattintson az üzenetek menügombon (mobil esszközön 2-szer nyomja meg)</h2><h3></h3><br><script>uzenetekbetoltese();</script></div>';
            case 30:
                return 'Az alkalmazás offline';
            case 31:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 1';
            case 32:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 2';
            case 33:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 3';
            case 34:
                return szovegetide(1, 62) + '<br />Nincsen üzeneted';
            case 35:
                return '<h2>Dekódolási hiba, kérem próbáld újra az üzenetek letöltését</h2>';
            case 36:
                return 'Az üzenet kulcsfájlal dekódolható';
            case 37:
                return 'Az üzenetet az alkalmazás dekódolta';
            case 38:
                return 'A fájl jelszóval dekódolható';
            case 39:
                return 'A fájl kulcsfájlal dekódolható';
            case 40:
                return '<div id="page-wrapper"><h1>DMSK Beállítások</h1><center><div id="dmsk_radio"><input  type="radio" name="valasztas" value="off">  DMSK 240B-F mód kikapcsolása<br><input id="dmsk_modosit" type="radio" name="valasztas" value="mode">  DMSK 240B-F kód módosítása<br><input  type="radio" name="valasztas" value="on" checked="checked">  DMSK 240B-F mód bekapcsolása<br></div></center><br><input id="ujdmsk" type="text"/><img id="dmskinfo" src="ico/info.png"><h3 id="dmskinfotext">A DMSK 240B-F algoritmus egy, csak az adatbázis-szerver és egy csak általad ismert kódsorozattal (szöveg, szám, mondat) egy plusz paramétert, sót ad hozzá az üzenetek kódolásához. Ha elfelejted a kódot a DMSK plussz funkcióját nem fogod tudni használni. Ha ez történne töröld a regisztrációd és regisztrálj újra. Akkor a rendszer egy új kódot fog küldeni e-mailban. Amit bejelentkezés után lehetőleg módosíts minél hamarabb. A kódra a jelszóra is érvényes szabályok érvényesek.(minimum 10 karakter nagy és kisbetü és szám.) </h3><br><label>Kulcsszinkron időközök secundum</label><input id="kulcsszinkronsetup" type="number" style="color:yellow;background:black" min="15" max="160" value="29" step="5"><br><label>Üzenetellenörzési időközök secundum</label><input id="uzenetellenorzessetup" type="number" style="color:yellow;background:black" min="10" max="1800" value="15" step="5"><br><label>Időzár beállítás perc</label><input id="idozarsetup" type="number" style="color:yellow;background:black" min="1" max="60" value="5" step="1"></div>';
            case 41:
                return '<br/><button id="help" class="gombok tooltip">Online help</button><br/><button id="jkk" class="gombok tooltip">Kliens kód</button><h3>A jelszó és felhasználóinév módosításhoz kattints az ikonra</h3><br><img id="belepoinfo" src="ico/gear.png" alt="Információk"/><br><div id = "beinfo"><div><h3>Asztali gépet használóknak:<br><br>CTRL+Q hozza elő ezeket az információkat. Utánna ENTER az üzenetlistát<br>CTRL+X kilépés<br>CTRL+Y azonnali kulcsszinkron<br>CTRL+0 (nulla) menümagnes ki-be<br>CTRL+F1 Online help<br>CTRL+F2 üzenetküldés menü<br>ESC Rendszerüzenet bezárása</h3><br>' + "<h3> Kérem ne frissítsd az oldalt mert a generált azonosítód csak egyszeri belépésre jogosít.Használd a webalkalmazás gombjait.Ha elnavigálsz az oldalról ismét be kell majd jelentkezned. Böngészéshez nyiss új fület a böngészőben és ezt hagyd nyitva amíg bejelentkezve kívánsz maradni.Tehát az oldal bezárásával is megtörténik a kijelentkezésed. <br/>" + "Amíg az oldal meg van nyitva az új üzeneteidről a beállított időintervallumonként értesítést fogsz kapni. <br/></h3><div><label" + ' for = "message"> Régi jelszó: </label><input type="password" id="regijelszo"/></div><div><label for = "message"> Új jelszó: </label><input type="password" id="passa"/></div><div><label for = "message"> Új jelszó megismétlése: </label><input type="password" id="passb"/><div><label for = "message"> Felhasználói név váltás(opcionális, de a jelszóváltáshoz kötött): </label><input type="text" id="ujnicname"/></div>' + "</div><h3><br/>Ha új felhasználó vagy, érdemes a jelszavad módosítania. A hossza minimum 10 karakter ékezetek nélküli, kis és nagybetük, számok.</h3></div>";
            case 42:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mód kikapcsolva</h1></div>';
            case 43:
                return szovegetide(1, 62) + '<br />A DMSK-240B-F kódra a minimális elvárások a jelszóéval egyeznek meg.';
            case 44:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mód bekapcsolva</h1><h3>Amennyiben rossz kódot adtál meg az alkalmazás nem fog működni. A kód módosítását csak helyes kód megadása után tudod elvégezni.</h3></div>';
            case 45:
                return szovegetide(1, 62) + '<br />A DMSK-240B-F kód módosításához be kell kapcsolni, azt a jelenlegi érvényes kóddal.';
            case 46:
                return szovegetide(1, 62) + '<br />Írj be egy megfelelően bonyolult, de jól megjegyezhető kódot.';
            case 47:
                return szovegetide(1, 62) + '<br />A kód maximális hossza 199 karakter, minimális hossza 10 karakter.';
            case 48:
                return szovegetide(1, 62) + '<br />A kód nem megengedett karaktert tartalmaz.';
            case 49:
                return szovegetide(1, 62) + '<br />A kód módosítása során hiba történt';
            case 50:
                return szovegetide(1, 62) + '<br />A kód módosítása sikeresen megtörtént.';
            case 51:
                return szovegetide(1, 62) + '<br />A művelet elvégzése során hiba lépett fel';
            case 52:
                return ' \n\n---- Erre válasz: ';
            case 53:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy mindenkinek vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig, törlésükig vagy az általad megadott maximális ideig érhetőek el. Majd a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.</h3><br><div><div id="uzenetkuldes_radio"><input type="radio" name="kuldes" value="select" checked="checked">Válasz üzenet küldése<br><div id="tagidlist"><br><select name="tagoklista" id="taglista"><option value="';
            case 54:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy mindenkinek vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig, törlésükig vagy az általad megadott maximális ideig érhatőek el. Majd a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.</h3><br><div><center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all" >Üzenet küldése, minden tagnak<br><input type="radio" name="kuldes" value="select" checked="checked">Üzenet küldése a kiválasztott tagoknak<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div><br>' + filefelt+'<br>' +hangfelt+ '<label>Üzenet szövege</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft">Továbbított üzenet:\n\n' + kapottuzenetszovege + '</textarea>' + '<br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"></div>';
            case 55:
                return '<div id="page-wrapper"><h1>Privát Üzenetküldő Webalkalmazás<br>PMWA<br>DMSK-240B-F<br>One Time Pad<br>Alias Verman Encrypter</h1></div>'; //----
            case 56:
                return '<h2>Offline kapcsolat, nincsen elérhető üzenetlista</h2>';
            case 57:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />Nincsenek olvasatlan üzeneteid<br><br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 58:
                return '<h2>Kulcsszikron hiba. Szinkronizálj manuálisan, vagy várd meg amíg a rendszer újraszinkronizál.</h2><br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 59:
                return '<br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 60:
                return '<h2>Offline állapot: mentett üzenetlista</h2><br>';
            case 61:
                return; //'<br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 62:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span>';
            case 63:
                return 'Fogadott adatok: ';
            case 64:
                return 'Összes(ki és be) adatcsomag száma: ';
            case 65:
                return 'Küldött adatok: ';
            case 66:
                return 'Végrehajtás';
            case 67:
                return 'Küldés';
            case 68:
                return '<div><h3>El nem küldött offline üzeneteid vannak</h3></div><div><h3 style="color:brown">Biztos hogy kilépsz az alkalmazásból?</h3><br>';
            case 69:
                return 'Megerősítés';
            case 70:
                return '<div><h3>Biztos hogy törlöd a regisztrációd?</h3></div><div><h3 style="color:brown">Akkor add meg a jelszavad</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 71:
                return szovegetide(1, 62) + '<br />A DMSK kódolás után az üzenet hossza meghaladja a megengedett méretet. Titkosítsd az üzenetet jelszóval, kulcsfájlal vagy rövidítsd le.';
            case 72:
                return szovegetide(1, 62) + '<br /> Jelszavas vagy kulcsfájlos titkosítás nélkül nem kóldhetsz fájlt.';
            case 73:
                return szovegetide(1, 62) + '<br />A kulcsfájl hossza kisebb a kódolandó adatoknal, ez ellentétben áll a One Time Pad titkosítás alapelvével. Válasszon nagyobb kulcsot.';
            case 74:
                return szovegetide(1, 62) + '<br />A kulcsfájl hossza kisebb a kodolandó fájlnál, ez ellentétben áll a One Time Pad titkosítás alapelvével. Válassz nagyobb kulcsot.';
            case 75:
                return; //'<img src = "images/sportcsarnok.jpg" id = "terkep" alt="A kép betöltése nem sikerült..."><div id="helyszin" class="helyszin">Helyszin: Izsák, Sportcsarnok</div>';
            case 76:
                return 'Regisztráció';
            case 77:
                return 'Belépés';
            case 78:
                return '<div id="page-wrapper"><h3>A regisztrációnál megadott felhasználói neved, és ha még nem módosítottad az ott kapott jelszó. Az webalkalmazás, alapértelmezésben DMSK-240B titkosítást használ az adatok küldéséhez és fogadásához. Ami HTTPS kapcsolat nélkül is, védelmet nyújt a küldött, információk, számára.</h3><br /><h1>Bejelentkezés</h1><div class="field"><label >Felhasználóinév:</label><input type="text" id="loginname"></div><div class="field"><label for="message">Jelszó:</label><input type="password" id="loginpass"></input><br><label>Minden más eszközről léptessen ki</label><input id="kileptetes" type="checkbox" class="kileptetes"></div></div>';
            case 79:
                return szovegetide(1, 62) + '<br />Tartalmazzon legalább egy számot.';
            case 80:
                return szovegetide(1, 62) + '<br />Tartalmazzon kisbetüket is.';
            case 81:
                return szovegetide(1, 62) + '<br />Tartalmazzon nagybetüket is.';
            case 82:
                return szovegetide(1, 62) + '<br />Szerver oldali hiba (500)';
            case 83:
                return szovegetide(1, 62) + '<br />A webserver a kérést átmenetileg elutasította. Próbáld meg ismét. (503)';
            case 84:
                return szovegetide(1, 62) + '<br />Az oldal nem elérhető (404)';
            case 85:
                return szovegetide(1, 62) + '<br />Az üzenet elküldésekor hiba keletkezett (400)';
            case 86:
                return szovegetide(1, 62) + '<br />Az oldal nem elérhető (0)';
            case 87:
                return szovegetide(1, 62) + '<br />Az 1MB-ot meghaladó adatokat darabokban küldjük. Automatikus darabolás végrehajtva. Várd meg amíg minden darab elküldésre kerül.';
            case 88:
                return szovegetide(1, 62) + '<br />A kapcsolat offline, ellenőrizd az internetkapcsolatod.';
            case 89:
                return szovegetide(1, 62) + '<br />A kapcsolat online.';
            case 90:
                return szovegetide(1, 62) + '<br />A loginnév vagy a jelszó hossza nem megfelelő';
            case 91:
                return 'Ellenőrizd a Felhasználói neved, mert valamit biztos elírtál.';
            case 92:
                return "Kapcsolati hiba: Próbáld meg mégegyszer a bejelentekezés elküldését";
            case 93:
                return szovegetide(1, 62) + '<br />Add meg a kódot a küldés gomb megnyomása előtt';
            case 94:
                return '<h1>A megadott regisztrációs kód nem érvényes</h1>';
            case 95:
                return "A biztonság kedvéért a belépés utánni üzenetküldési funkciók eléréséhez, meg kell várnod a csoportadminisztrátori aktiválást.";
            case 96:
                return szovegetide(1, 62) + '<br />Foglalt név';;
            case 97:
                return szovegetide(1, 62) + '<br />A név minimum  4 karakter legyen , az email cím pedig élő, mert oda kapod a megerősítéshez szükséges kódot';
            case 98:
                return szovegetide(1, 62) + '<br />Az email cím formátuma nem megfelelő: pelda@valami.com';
            case 99:
                return szovegetide(1, 62) + '<br />A felhasználói név nem megengedett karaktert tartalmaz.';
            case 100:
                return "<h1>A megadott felhasználói név már foglalt, használj valami megkülönböztető információt.</h1>";
            case 101:
                return '<div id="page-wrapper"><h3>Kövesd a leírtakat és nyomd meg a küldés gombot.</h3><br /><h1>Megerősítés</h1><div id="regisztral" class="field"><label >Add meg az emailben kapott kódot:</label><input type="password" id="regkod"></div></div>';
            case 102:
                return 'Hiba! Az üzenet elküldése  nem sikerült. A szerver nem fogadja a kéréseket.';
            case 103:
                return 'Hiba! A feltöltés  nem sikerült.';
            case 104:
                return; //'<h3 id="udvszoveg"><br>Üdvözöllek az együttmozás csoport privát üzenetküldő webalkalmazása kezdőoldalán.<br></h3>';
            case 105:
                return '<h1 id="honlapra">SEMOTUS</h1>'; //----
            case 106:
                return 'kezdőoldal<span class = "tooltiptext"> Főoldal. </span>';
            case 107:
                return; //'helyszín<span class = "tooltiptext" > A tornaterem helye és címe.</span>';
            case 108:
                return; //'adatvédelem<span class = "tooltiptext" > Adatvédelmi nyilatkozat. </span>';
            case 109:
                return 'belépés<span class="tooltiptext">Regisztráció szükséges.</span>'; //----
            case 110:
                return 'regisztráció<span class = "tooltiptext" > Regisztráció, érdeklődőknek, teszteléshez, kipróbáláshoz.</span>'; //--
            case 111:
                return 'Sikeres bejelentkezés';
            case 112:
                return 'kijelentkezés<span class=\"tooltiptext \">Főoldalra.</span>';
            case 113:
                return 'Teljeskép-be<span class=\"tooltiptext\">Teljes képernyős mód ki és bekapcsolása</span>';
            case 114:
                return 'üzenetek<span class=\"tooltiptext \">Az üzeneteidet itt nézheted meg</span>';
            case 115:
                return 'üzenetküldés<span class=\"tooltiptext\">Innen idíthatsz üzeneteket</span>';
            case 116:
                return 'DMSK beállítás<span class=\"tooltiptext\">Kikapcsolhatod, bekapcsolhatod a DMSK-240B-F módot, vagy módosíthatod a kódot. Erőssen ajánlott a használata.</span>';
            case 117:
                return 'Törlöm magam<span class=\"tooltiptext\">Megerősítés után végleg törölheted a regisztrációs adataidat.</span>';
            case 118:
                return 'Admin<span class=\"tooltiptext\">Adminisztrációs feladatok, felhasználók kezelése.</span>';
            case 119:
                return ' A csoporthoz való tarozásod ellenörzéséig nem tudod igénybe venni a webalkalmazás funkcióit. Kérem a türelmed, amíg megerősítem a státuszod: Admin.';
            case 120:
                return 'Üdvözöllek, az üzenetküldő webalkalmazásban';
            case 121:
                return 'Üdvözöllek, az üzenetküldő webalkalmazásban-ADMIN mód';
            case 122:
                return 'Mégsem';
            case 123:
                return '<span class="tooltiptext "><p class="elrejt">Figyelmeztetés törlése</p></span><br />A jelszavas védelem törlése végrehajtva. Most adhatsz meg másik jelszót, vagy választhatsz másik védelmi funkciót.';
            case 124:
                return '<div><h3>Titkosított üzenet küldése</h3></div><div><h3 style="color:brown">Add meg a jelszót amit a fogadó fél is ismer</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 125:
                return 'Titkosítás';
            case 126:
                return 'A jelszó hossza legalább 10 karakter kell legyen (ajánlott 30 karakter)';
            case 127:
                return '<span class="tooltiptext "><p class="elrejt">Figyelmeztetés törlése</p></span><br />A jelszó megfelelő. Ne feledd, hogy az ismerete nélkül a fogadó fél nem tudja elolvasni az uzeneted.';
            case 128:
                return '<label>OTP titkosítás</label><label id="kflabel">Kulcsfájl használata titkosításhoz<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/></label>';
            case 129:
                return '<button id="filefel" class="gombok tooltip">Fájl küldés</button><label id="fmtlab">A fájl már titkosított</label><input id="cb_titkositott" type="checkbox" class="kileptetes">';
            case 130:
                return 'A kulcsfájl mérete 10kb és 30MB közötti lehet';
            case 131:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A titkosításhoz használt fájl adatai';
            case 132:
                return 'Fájl: ';
            case 133:
                return 'Tipusa: ';
            case 134:
                return 'Mérete: ';
            case 135:
                return ' MB<br>Figyelem a kulcsfájl ismerete nélkül az adatok a fogadó oldalon nem fejthetőek vissza!';
            case 136:
                return 'Kulcsfájl törlése';
            case 137:
                return 'Kulcsfájl használata titkosításhoz<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/>';
            case 138:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A kulcsfájl vissza lett vonva.';
            case 139:
                return 'Fájl küldés';
            case 140:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A küldendő fájl vissza lett vonva.';
            case 141:
                return 'Fájl kiválasztva';
            case 142:
                return 'A fájl mérete 1kb és 10MB közötti lehet';
            case 143:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A küldésre kiválasztott fájl adatai';
            case 144:
                return 'Ezzel az üzenettel egyidőben küldött fájl neve:';
            case 145:
                return '<div><h3>Titkosított üzenet dekódolása</h3></div><div><h3 style="color:brown">Adja meg a jelszót amivel a feladó kódolta az üzenetet</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 146:
                return 'Visszafejtés';
            case 147:
                return 'Ha rossz jelszót írtál be töltsd le újra az üzenetet a dekódoláshoz.';
            case 148:
                return '<div><h3>Titkosított fájl dekódolása</h3></div><div><h3 style="color:brown">Add meg a jelszót amivel a feladó kódolta a fájlt. A dekódolás hosszabb ideig is eltarthat...</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 149:
                return 'Ha rossz jelszót írál be töltsd le újra az fájlt a dekódoláshoz.';
            case 150:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A dekodoláshoz használt fájl adatai';
            case 151:
                return 'Ha rossz kulcsfájlt adotál meg töltsd le újra az üzenetet a dekódoláshoz.';
            case 152:
                return 'Több mint 1 perce kikapcsoltad a kulcsszinkronizálást. Ha így használod az alkalmazást az 2 perc inaktivitás után biztonsági okokból kidob! (Lásd a rendszerspecifikációt).';
            case 153:
                return '" selected>VÁLASZ</option></select></div></div>';
            case 154:
                return '<label>Üzenet szövege</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="20" cols="40">';
            case 155:
                return '</textarea><br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>';
            case 156:
                return '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"></div></div>';
            case 157:
                return 'Webalkalmazás adminisztráció';
            case 158:
                return 'Felhasználók';
            case 159:
                return 'Tisztítás';
            case 160:
                return 'Vissza';
            case 161:
                return 'Felhasználói lista';
            case 162:
                return ' Sor került törlésre az adatbázisból';
            case 163:
                return 'Az adatbazishoz az aktiv kapcsolatok száma: ';
            case 164:
                return ' Minden kommunikáció';
            case 165:
                return '<div><h3>Biztos hogy feloldod a kommunikációs blokkolást?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 166:
                return '<div><h3>Biztos hogy blokkolsz minden kommunikációt?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 167:
                return '<div><h3>Biztos hogy elvégzed az adatbazis tisztitását?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 168:
                return 'Biztos hogy elvégzed az aktiválást? Ismered a felhasználót?';
            case 169:
                return 'Biztos hogy elvégzed a tag felfüggesztést?';
            case 170:
                return 'Biztos hogy elvégzed az egész csoport törlését?';
            case 171:
                return 'Akkor add meg a jelszavad';
            case 172:
                return 'Az adminisztrátor nem törölhető csak a csoporttal együtt';
            case 173:
                return 'Biztos hogy elvégzed a tag regisztrációjának a törlését?';
            case 174:
                return 'Szerver oldali hibakód: ';
            case 175:
                return 'Érkezett üzenetek';
            case 176:
                return 'Feladó: ';
            case 177:
                return 'Üzenet: DMSK védelem';
            case 178:
                return 'Üzenet: Kulcsfájllal védett';
            case 179:
                return '"OneTimePad" védett fájl';
            case 180:
                return 'Jelszóval védett fájl';
            case 181:
                return 'Üzenet: Jelszóval védett';
            case 182:
                return ' Küldés ideje: ';
            case 183:
                return 'Az üzenet mérete: ';
            case 184:
                return 'Az üzenetek összmérete: ';
            case 185:
                return 'Letöltöm';
            case 186:
                return 'Üzenet letöltése olvasásra.';
            case 187:
                return 'Törlöm !!!';
            case 188:
                return 'Ha ide kattintasz az üzenet nem jelenik meg többet.';
            case 189:
                return 'Letöltött üzenet';
            case 200:
                return 'DMSK védelemmel ellátott üzenet';
            case 201:
                return '"OneTimePad" kulcsfájllal kódolt üzenet. A megtekintéshez dekódold';
            case 202:
                return 'Jelszóval védett üzenet. A megtekintéshez dekódold';
            case 203:
                return 'Jelszóval kódolt fájl. A mentéséhez dekódold';
            case 204:
                return '"OneTimePad" kódolt fájl, a mentéshez dekódold.';
            case 205:
                return 'Válasz';
            case 206:
                return 'Válasz írása az üzenetre.';
            case 207:
                return 'Elolvastam';
            case 208:
                return 'Ha ide kattintasz az üzenet nem jelenik meg többet.';
            case 209:
                return 'Jelszó beírása a kódolt üzenet dekódolásához.';
            case 210:
                return 'Továbbítom';
            case 211:
                return 'Az üzenet továbbítása más tagnak.';
            case 212:
                return 'Törlöm';
            case 213:
                return 'Lementem';
            case 214:
                return 'Jelszó beírása a kódolt üzenet dekódolásához.';
            case 215:
                return 'A megadott belépési adatok nem érvényesek. Figyelj a nagy és kisbetükre...';
            case 216:
                return 'A mezők kitöltése nem volt megfelelő... (code:400)';
            case 217:
                return 'A felhasználóinév min 4 a jelszó minimum 10 karakter';
            case 218:
                return 'Elméletileg a szerver által fogadott maximális HTTP adatcsomag mérete: ';
            case 219:
                return 'A válasz elküldésével és az elolvastam gomb megnyomásával az üzenet nem tölthető be újra.<br> A továbbított üzenet újból letölthető az érvényességi idején belül.';
            case 220:
                return 'Visszavan: ';
            case 221:
                return 'Csomagok összefűzése a szerveren';
            case 222:
                return 'Az 1MB -ot meghaladó adatokat darabokban küldjük. Automatikus darabolás végrehajtva. Várd meg amíg minden darab elküldésre kerül.';
            case 223:
                return 'A loginneveddel, sikertelen, belépési próbálkozások száma: ';
            case 224:
                return ' Ha nem te tévesztettél, biztonsági okokból ajánlott a loginnév megváltoztatása';
            case 225:
                return ' Regisztrált: ';
            case 226:
                return 'Megkezdett regisztráció';
            case 227:
                return 'A belépéshez használt eszközök listálya:';
            case 228:
                return 'Törlöm';
            case 229:
                return 'Aktiválom';
            case 230:
                return 'Aktiválásra vár!';
            case 231:
                return 'Felfüggesztem';
            case 232:
                return 'Aktív felhasználó';
            case 233:
                return 'Adminisztrátor';
            case 234:
                return 'Csoport-KILL';
            case 235:
                return 'Szabadhely a kiszolgálón: ';
            case 236:
                return 'Teljeshely a kiszolgálón: ';
            case 237:
                return 'Az eszközről kijelentkezve';
            case 238:
                return 'Az eszközre bejelentkezve: ';
            case 239:
                return 'Belépésszám:';
            case 240:
                return 'A megadott e-mail cím formátumában hiba van.';
            case 241:
                return 'A megadott e-mail címről már történt regisztráció.';
            case 242:
                return 'Ellenőrizd az e-mail fiókod és add meg a kapott ellenörző kódot a regisztráció befejezéséhez.';
            case 243:
                return 'Offline állapotban nem küldhetsz fájlt';
            case 244:
                return 'Megadhatja a kulcsszinkron gyakoriságát 15 és 110 másodperc között.';
            case 245:
                return 'DMSK kulcs, váltás idő beállítás';
            case 246:
                return 'Megadhatja az üzenetellenörzés gyakoriságát 10 másodperc és 30 perc között másodpercben.';
            case 247:
                return 'Új üzenetek ellenörzése';
            case 248:
                return 'Add meg a jelszavad';
            case 249:
                return 'Időzár';
            case 250:
                return '<br><button id="hangfelvetel" class="gombok tooltip">Hangüzenet</button><br>';
            case 251:
                return szovegetide(1, 62) + '<br />A hangüzenet törölve lett ';
            case 252:
                return '<br><h2>A hangüzeneteket nem célszerü lemezre menteni</h2><br>';
            case 253:
                return szovegetide(1, 62) + '<br/>Java üzennetellenörző klienshez a kódja: ' + juszlkk + '<br/>A vágólapról elérhető.';
            case 254:
                return 'A fájl mentés után dekódolandó';
            case 255:
                return 'A fájlt a webalkalmazás csak közvetítette a feladója külső titkosításunak jelölte. Mentse le és utánna dekódolja.';
            case 256:
                return;
            case 257:
                return;
            case 258:
                return;
            case 259:
                return;

        }

    } else if (milyennyelven == 2) {
        switch (hovakered) {
            case 1:
                return 'Fullscreen off<span class=\"tooltiptext\">Turn full screen mode on and off</span>';
            case 2:
                return 'Fullscreen on<span class=\"tooltiptext\">Turn full screen mode on and off</span>';
            case 3:
                return '<audio controls autoplay hidden><source src=\"1.mp3\" type=\"audio/mpeg\"></audio>';
            case 4:
                return 'Message: ';
            case 5:
                return '<img id=\"messimg\" src=\"ico/error.png\"><img id=\"messimg\" src=\"ico/erdsmk.png\">';
            case 6:
                return '<img id=\"messimg\" src=\"ico/error.png\">';
            case 7:
                return '<div id="adatvedelem">' +
                    '<h2></br>ADATVÉDELMI ÉS ADATKEZELÉSI SZABÁLYZAT 2018. </br>Hatályos: 2018. május 25. napjától</h2><h3>Általános rendelkezések</h3> A Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95), mint az Adatkezelő aáltala üzemeltetett http:// egyuttmozgas.probaljaki.hu weboldal és az ott meghatározott egyéb címeken elérhető weboldalak(a továbbiakban: „weboldal”) által nyújtott szolgáltatásaihoz kapcsolódóan a felhasználó természetes személyek („ügyfél“) valamennyi adatkezelése során a jelen Adatvédelmi és Adatkezelési Szabályzat és Tájékoztató alapján jár el. Az Ügyfél a weboldalra történő belépéssel, és a weboldal használatával magára nézve kötelezőnek fogadja el a jelen szabályzat rendelkezéseit. A szabályzat célja, hogy meghatározza az Adatkezelő által kezelt személyes adatok körét, az adatkezelés módját, valamint biztosítsa az adatvédelem és adatkezelés alkotmányos elveinek, az adatbiztonság követelményeinek érvényesülését annak érdekében, hogy a felhasználó természetes személyek magánszférájának a tiszteletben tartása megvalósuljon az érintettek személyes adatainak gépi feldolgozása, illetőleg kezelése során. <h3>1. Értelmező rendelkezések</h3> <h4>1.1. Adatkezelő:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, a ki vagy amely önállóan vagy másokkal együtt az adat kezelésének célját meghatározza, az adatkezelésre (beleértve a felhasznált eszközt) vonatkozó döntéseket meghozza és végrehajtja, vagy az adatfeldolgozóval végrehajtatja.<h4> 1.2. Adatkezelés:</h4> az alkalmazott eljárástól függetlenül az adaton végzett bármely művelet vagy a műveletek összessége, így különösen gyűjtése, felvétele, rögzítése, rendszerezése, tárolása, megváltoztatása, felhasználása, lekérdezése, továbbítása, nyilvánosságra hozatala, összehangolása vagy összekapcsolása, zárolása, törlése és megsemmisítése, valamint az adat további felhasználásának megakadályozása, fénykép-, hang- vagy képfelvétel készítése, valamint a személy azonosítására Adatvédelmi és Adatkezelési Szabályzat 2018 2 alkalmas fizikai jellemzők (pl. ujj- vagy tenyérnyomat, DNS-minta, íriszkép) rögzítése. <h4>1.3. Személyes adat:</h4> az érintettel kapcsolatba hozható adat - különösen az érintett neve, azonosító jele, valamint egy vagy több fizikai, fiziológiai, mentális, gazdasági, kulturális vagy szociális azonosságára jellemző ismeret -, valamint az adatból levonható, az érintettre vonatkozó következtetés.<h4> 1.4. Hozzájárulás:</h4> az érintett akaratának önkéntes és határozott kinyilvánítása, amely megfelelő tájékoztatáson alapul, és amellyel félreérthetetlen beleegyezését adja a rá vonatkozó személyes adat- teljes körű vagy egyes műveletekre kiterjedő – kezeléséhez. <h4>1.5. Adatfeldolgozás:</h4> az adatkezelési műveletekhez kapcsolódó technikai feladatok elvégzése, függetlenül a műveletek végrehajtásához alkalmazott módszertől és eszköztől, valamint az alkalmazás helyétől, feltéve hogy a technikai feladatot az adaton végzik. <h4>1.6. Adatfeldolgozó:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, aki vagy amely szerződés alapján - beleértve a jogszabály rendelkezése alapján kötött szerződést is - adatok feldolgozását végzi. <h4>1.7. Érintett:</h4> bármely meghatározott, személyes adat alapján azonosított vagy - közvetlenül vagy közvetve - azonosítható természetes személy.<h3> 2. Az adatkezelő megnevezése : </h3>Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95. Email: <span id="emailcim">milena&copy;egyuttmozgas.probaljaki.hu</span> évi CXII. törvény 65. § (3) a) pontja értelmében nem vezet adatvédelmi nyilvántartást a Hatóság arról az adatkezelésről, amely az adatkezelővel munkaviszonyban, tagsági viszonyban, - a pénzügyi szervezetek, közüzemi szolgáltatók, elektronikus hírközlési szolgáltatók ügyfelei kivételével - ügyfélkapcsolatban álló személyek adataira vonatkozik.<h3> 3. Az adatok megismerésére jogosult természetes és jogi személyek, az adatfeldolgozó:</h3> Az adatokat az Adatkezelő Alapszabályában és SZMSZ-ében meghatározott vezetősége, illetve a vezetőség által külön ferre felhatalmazott Adatvédelmi és Adatkezelési Szabályzat 2018 3 személyek jogosultak megismerni Adatkezelő az adatokat nem teszik közzé, harmadik személyek számára nem adják ki.<h3> 4. A kezelt személyes adatok köre:</h3> A jelen szabályzat kizárólag a természetes személyek adatainak a kezelésére terjed ki, tekintettel a szabályzat arra, hogy személyes adatok kizárólag természetes személyek vonatkozásában értelmezhetők. A Weboldal bármely internethasználó által regisztráció nélkül hozzáférhető tartalmakat is biztosít. Bizonyos tartalmi szolgáltatásai és hírlevél funkciója azonban csak regisztrált felhasználók számára hozzáférhető. Regisztrált felhasználó az lehet, akit a az Adatkezelő a saját belső szabályzatának megfelelően erre feljogosít. A regisztráció folyamata ingyenes. <h4>4.1. A regisztráció során az Ügyfélnek kötelezően meg kell adnia a következő személyes adatokat:</h4> <li> Ügyfél neve,</li> <li>E-mail címe</li> <h4> 4.2.</h4> A www.egyuttmozgas.probaljaki.hu (továbbiakban: Weboldal) adatbázisa az Ügyfél adatait a regisztrációval nyújtott ingyenes szolgáltatások teljesítése érdekében tárolja, azokat az adatkezelő továbbadni sem reklámfelhasználás, sem egyéb célra - az Ügyfél kifejezett hozzájárulása hiányában - nem jogosult. <h4>4.3.</h4> A Weboldalon tett látogatások során egy vagy több cookie-t - apró információcsomagot, amelyet a szerver küld a böngészőnek, majd a böngésző visszaküld a szervernek minden, a szerver felé irányított kérés alkalmával - küldünk az Ügyfél számítógépére, amely(ek) révén annak böngészője egyedileg azonosítható lesz. Ezen cookie-k kizárólag a felhasználói élmény javítása, a belépési folyamat automatizálása, valamint reklámtevékenységünk hatékonyságának mérése érdekében működnek. <h4>4.4.</h4> Az Ügyfél személyes adatainak kezelése során a Szolgáltató betartja az információs önrendelkezési jogról szóló 2011. évi CXII. törvény előírásait. <h4>4.5.</h4> Az Ügyfél mindenkor jogosult az adatkezelést letiltani. <h3>5. Az adatkezelés jogalapja, módja és célja Adatvédelmi és Adatkezelési Szabályzat 2018 </h3> <h4>5.1.</h4> Az adatkezelés jogalapja az Ügyfél önkéntes hozzájárulása. A hozzájárulást az Ügyfél a fentiekben megjelölt adatok kezelése tekintetében jelen adatvédelmi szabályzat előzetes megismerését követően a regisztrációval, a kérdéses adatok önkéntes megadásával adja meg. A hírlevéllel kapcsolatban az Ügyfél az erre vonatkozó jelölőnégyzet kipipálásával kifejezett és önkéntes hozzájárulását adja ahhoz, hogy Adatkezelő a Weboldallal kapcsolatos híreket, információkat küldjön az Ügyfél által a regisztráció során megadott e-mail címre. <h4>5.2.</h4> Az adatkezelés célja a tartalomszolgáltatás és az ezzel, valamint az Adatkezelő egyesület működésével összefüggő egyéb információk megadása. A Szolgáltató az Ügyfél által rendelkezésre bocsátott adatokat célhoz kötötten tárolja. Ügyfél a weboldalon történő regisztrációval hozzájárul ahhoz, hogy személyes adatait az alábbi célokra felhasználhassuk:  hírlevél szolgáltatás tartalomszolgáltatás <h4>5.3.</h4> A regisztráció során megadott elektronikus levélcímek (e-mail címek) adatkezelő általi felhasználásának módja a következő: az e-mail címek kezelése az ügyfél azonosítását, a szolgáltatások igénybevétele során a kapcsolattartási célokat, illetőleg az ügyfél részére hírlevél megküldésére szolgál. Adatkezelő az általa nyújtott szolgáltatásokra vonatkozó tájékoztatást elektronikus formában, e-mailben juttatja el ügyfél részére. Adatkezelő az ügyfél kifejezett hozzájárulásával küld a regisztráció során megadott e-mail címre a Weboldal tartalmaival és a gyakorlások szervezésével kapcsolatos információkat tartalmazó hírleveleket. Adatkezelő kizárólag azon ügyfelei számára küld hírleveleket, akik az erre szolgáló menüpontban ehhez kifejezett hozzájárulásukat adták.<h4> 5.4.</h4> Az Ügyfél a hírlevél szolgáltatásról bármikor, ingyenesen és indoklás nélkül leiratkozhat. A leiratkozás történhet egyetlen lépésben, a hírlevélben található linkre kattintással, illetve leiratkozhat az Adatkezelőnek küldött e-mail formájában is. Ebben az esetben Adatkezelő haladéktalanul törli a nyilvántartásából az Ügyfél adatait. <h4>5.5.</h4> Az Ügyfél által megadott telefonszám adatkezelő általi felhasználási célja a következő: az folyamat során kapcsolattartási célokat szolgál. <h4>5.6.</h4> Az Ügyfél adatait kizárólag számítástechnikai eszközzel végrehajtott adatfeldolgozással kezeljük. Az automatikusan rögzítésre kerülő adatok célja statisztika-készítés, az informatikai rendszer technikai fejlesztése, a felhasználók jogainak védelme. Az automatikusan rögzítésre kerülő adatok az alábbiak: az ügyfél számítógépének dinamikus IP címe, az ügyfél számítógépének beállításaitól függően az ügyfél által használt számítógép operációs rendszerének és böngészőjének típusa, az ügyfélnek a Weboldallal kapcsolatos aktivitása. Ezen adatok felhasználása egyrészről technikai célokat szolgál - pl. a szerverek biztonságos üzemeltetése, utólagos ellenőrzése, másrészt az Adatkezelő ezen Adatvédelmi és Adatkezelési Szabályzat 2018 5 adatokat oldalhasználati statisztikák készítéséhez, a felhasználói igények elemzéséhez használja fel a szolgáltatások színvonalának emelése érdekében. A fenti adatok az ügyfél azonosítására nem alkalmasak, és ezeket a Szolgáltató egyéb személyes adatokkal nem kapcsolja össze. <h4>5.7.</h4> Az adatkezelő a megadott személyes adatokat az e pontokban írt céloktól eltérő célokra nem használhatja fel. Személyes adatok harmadik személynek vagy hatóságok számára történő kiadása - hacsak törvény ettől eltérően nem rendelkezik kötelező erővel - a felhasználó előzetes, kifejezett hozzájárulása esetén lehetséges kizárólag.<h4> 5.8.</h4> Adatkezelő a neki megadott személyes adatokat nem ellenőrzi. A megadott adatok megfelelőségéért kizárólag az azt megadó személy felel..' +
                    "Bármely Ügyfél e-mail címénekmegadásakor egyben felelősséget vállal azért, hogy a megadott e-mail címről kizárólag ő vesz igénybe szolgáltatást. E felelősségvállalásra" +
                    "tekintettel egy megadott e-mail címen történt belépésekkel összefüggő mindennemű felelősség kizárólag azt a felhasználót terheli, aki az e-mail címet regisztrálta.<h3> 6. Az adatkezelés időtartama</h3> <h4>6.1.</h4> A regisztráció során kötelezően megadott adatok kezelése a regisztrációval kezdődik és annak törléséig tart. Nem kötelező adatok esetén az adatkezelés az adat megadásának időpontjától a kérdéses adat törléséig tart. A regisztráció során rögzített adatok megváltoztatását, vagy törlését a regisztrált Ügyfél a bejelentkezést követően a „Saját fiókban” kezdeményezheti. <h4>6.2.<h4> Fenti rendelkezések nem érintik a jogszabályban (pl. számviteli jogszabályokban) meghatározott megőrzési kötelezettségek teljesítését. <h3>7. Az adatokat megismerni jogosult személyek köre</h3> <h4>7.1.</h4> Az adatokat elsődlegesen Adatkezelő, illetve Adatkezelő belső munkatársai jogosultak megismerni, azonban azokat nem teszik közzé, harmadik személyek részére nem adják át.<h4> 7.2.</h4> Az alapul fekvő informatikai rendszer üzemeltetése, a megrendelések teljesítése, az elszámolás rendezése körében Adatkezelő adatfeldolgozót (pl. rendszerüzemeltető, könyvelő) vehet igénybe. Adatkezelő az ilyen külső szereplők adatkezelési gyakorlatáért nem felelős.<h4> 7.3. </h4>A fentieken túl az Ügyfélre vonatkozó személyes adatok továbbítására kizárólag törvényben kötelezően meghatározott esetben, illetve az Ügyfél hozzájárulása alapján kerülhet sor. <h3>8. Az ügyfél jogai Adatvédelmi és Adatkezelési Szabályzat 2018 6</h3> <h4>8.1.</h4> Az Ügyfél bármikor jogosult tájékoztatást kérni a Adatkezelő által kezelt, rá vonatkozó személyes adatokról, továbbá bármikor módosíthatja azokat. Ügyfél jogosult továbbá adatai törlésének kérésére az e pontban megadott elérhetőségek útján. <h4>8.2.</h4> Szolgáltató az Ügyfél kérésére tájékoztatást ad a rá vonatkozó, általa kezelt adatokról, az adatkezelés céljáról, jogalapjáról, időtartamáról, továbbá arról, hogy kik és milyen célból kapják vagy kapták meg adatait. Szolgáltató a kérelem benyújtásától számított 30 napon belül írásban adja meg a kért tájékoztatást.<h4> 8.3.</h4> Az Ügyfél bármely, az adatkezeléssel kapcsolatos kérdéssel, illetve észrevétellel az Adatkezelő munkatársához fordulhat a fenti elérhetőségeken keresztül. Levelezési cím: 6070 Izsák Matyó 95<h4> 8.4.</h4> Az Ügyfél bármikor jogosult a helytelenül rögzített adatainak helyesbítését, vagy azok törlését kérni. Egyes adatait az Ügyfél a Honlapon maga helyesbítheti; egyéb esetekben Szolgáltató a kérelem beérkezésétől számított 3 munkanapon belül törli az adatokat, ez esetben azok nem lesznek újra helyreállíthatók. A törlés nem vonatkozik a jogszabály (pl. számviteli szabályozás) alapján szükséges adatkezelésekre, azokat Szolgáltató a szükséges időtartamig megőrzi.<h4> 8.5.</h4> Az ügyfél bíróság előtt érvényesítheti jogait, kérheti továbbá az adatvédelmi biztos segítségét is. Ügyfél, jogsértés esetén jogorvoslatért fordulhat: az Adatvédelmi Biztos Hivatalához (1051 Budapest, Nádor u. 22.) A Nemzeti Adatvédelmi és Információszabadság Hatósághoz<h4> 8.6.</h4> Amennyiben az Ügyfél szolgáltatás igénybevételéhez a regisztráció során harmadik fél adatait adta meg, vagy a Weboldal használata során bármilyen módon kárt okozott, a Szolgáltató jogosult az Ügyféllel szembeni kártérítés érvényesítésére. A Szolgáltató ilyen esetben minden tőle telhető segítséget megad az eljáró hatóságoknak a jogsértő személy személyazonosságának megállapítása céljából. <h3>9. Egyéb rendelkezések </h3><h4>9.1.</h4> Szolgáltató rendszere a felhasználók aktivitásáról adatokat gyűjthet, melyek nem kapcsolhatóak össze a felhasználók által a regisztrációkor megadott egyéb adatokkal, sem más honlapok vagy szolgáltatások igénybevételekor keletkező adatokkal. <h4>9.2.</h4> Minden olyan esetben, ha a szolgáltatott adatokat a Szolgáltató az eredeti adatfelvétel céljától eltérő célra kívánja felhasználni, erről a felhasználót tájékoztatja, és ehhez előzetes, kifejezett hozzájárulását megszerzi, illetőleg lehetőséget biztosít számára, hogy a felhasználást megtiltsa. <h4>9.3.</h4> Szolgáltató kötelezi magát, hogy gondoskodik az adatok biztonságáról, megteszi továbbá azokat a technikai intézkedéseket, amelyek biztosítják, hogy a felvett, tárolt, illetve kezelt adatok védettek legyenek, illetőleg mindent megtesz annak érdekében, hogy megakadályozza azok megsemmisülését, jogosulatlan felhasználását és jogosulatlan megváltoztatását. Kötelezi magát arra is, hogy Adatvédelmi és Adatkezelési Szabályzat 2018 7 minden olyan harmadik felet, akiknek az adatokat esetlegesen továbbítja vagy átadja, ugyancsak felhívja ez irányú kötelezettségeinek teljesítésére. <h4>9.4.</h4> Szolgáltató fenntartja a jogot, hogy jelen Szabályzatot az Ügyfelek előzetes értesítése mellett egyoldalúan módosítsa. A módosítás hatályba lépését követően az Ügyfél a szolgáltatás használatával ráutaló magatartással elfogadja a módosított Szabályzatban foglaltakat. Az Adatkezelő magára nézve kötelezőnek ismeri el jelen szabályzat tartalmát, és kötelezettséget vállal arra, hogy szolgáltatásával kapcsolatos adatkezelése megfelel a jelen szabályzatban megfogalmazott előírásoknak." +
                    "</div>";
            case 8:
                return '<div id="page-wrapper"><h3>Please follow the instructions and press the Confirm key.</h3><br /><h1>Sign up</h1><div class="field"><label for="name">Please enter your username:</label><input type="text" id="name" ><div id="regisztral" class="field"><label >Please enter your email address:</label><input type="email" id="email"></div></div>';
            case 9:
                return '<div id="page-wrapper"><h1 id="tajekoztato">Clear registration data</h1><br /><h3>Are you sure? If so, click on the Execute Label button. If you do not choose another menu item. </h3></div>';
            case 10:
                return szovegetide(2, 62) + '<br />Your old password not could have been less than 8 characters. Please check the password you entered.';
            case 11:
                return szovegetide(2, 62) + '<br />The old password is not a valid password.';
            case 12:
                return szovegetide(2, 62) + '<br />The new password must have a minimum of 10 characters.';
            case 13:
                return szovegetide(2, 62) + '<br />The password contains a forbidden character.';
            case 14:
                return szovegetide(2, 62) + '<br />The value of the two password fields is not the same.';
            case 15:
                return szovegetide(2, 62) + '<br />The user name must be at least 4 characters.';
            case 16:
                return szovegetide(2, 62) + '<br />The user name contains a forbidden character.';
            case 17:
                return szovegetide(2, 62) + '<br />The given username is already occupied.';
            case 18:
                return szovegetide(2, 62) + '<br />Failed to change password.';
            case 19:
                return szovegetide(2, 62) + '<br />Data has been modified.';
            case 20:
                return '<div id="page-wrapper"><h1>Send message</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Choose you want to send a message to everyone or just some of the users. Your message is displayed for the maximum length of time. The message automatic delete after the expiration time. There is no way to retrieve it.<button class="gombok" id="413">413 status</button></h3><br><div><center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all" >Send message to everyone<br><input type="radio" name="kuldes" value="select" checked="checked">Send a message to the selected users<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div>' + '<br>' + filefelt + hangfelt+'<br><img id="uzenetkuldesinfo2" src="ico/info.png"><label>Message text</label><br><h3 id="uzenetkuldestext2">Encrypted messages will NOT be saved! Files must be protected by a password or key file.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft"></textarea>' + '<br><button class="gombok" id="kiurit">Clear Text</button><br><label>The message password protected</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Enter the maximum validity time for your message in hours</label><input type="number" id="maxido" value="48" min="1" max="168"><br></div>';
            case 21:
                return szovegetide(2, 62) + '<br />Error loading user list. Please try again.';
            case 22:
                return szovegetide(2, 62) + '<br />Error in connection or offline.';
            case 23:
                return szovegetide(2, 62) + '<br />Not selected recipient.';
            case 24:
                return szovegetide(2, 62) + '<br />You have not posted a message. The blank message was not sent.';
            case 25:
                return szovegetide(2, 62) + '<br />Message saved. Send  by online to status. If you exit the application or close the web page, the message will not be sent.';
            case 26:
                return 'Sent:';
            case 27:
                return 'Warning! The message may not be sent';
            case 28:
                return szovegetide(2, 62) + '<br />Message sent.';
            case 29:
                return '<div id="page-wrapper"><h2>To display messages, click on the messages button </h2><h3></h3><br><script>uzenetekbetoltese();</script></div>';
            case 30:
                return 'The application is offline';
            case 31:
                return szovegetide(2, 62) + '<br />Lekérdezés hibakód: 1';
            case 32:
                return szovegetide(2, 62) + '<br />Lekérdezés hibakód: 2';
            case 33:
                return szovegetide(2, 62) + '<br />Lekérdezés hibakód: 3';
            case 34:
                return szovegetide(2, 62) + '<br />You do not have a message';
            case 35:
                return '<h2>Decoding error, please try downloading the messages again</h2>';
            case 36:
                return 'The message can be decoded with a key file';
            case 37:
                return 'The message was decrypted by the application';
            case 38:
                return 'The file can be decoded by password';
            case 39:
                return 'The file can be decoded with a key file';
            case 40:
                return '<div id="page-wrapper"><h1>DMSK Setup</h1><center><div id="dmsk_radio"><input  type="radio" name="valasztas" value="off">  DMSK 240B-F OFF<br><input id="dmsk_modosit" type="radio" name="valasztas" value="mode">  DMSK 240B-F code change<br><input  type="radio" name="valasztas" value="on" checked="checked">  DMSK 240B-F ON<br></div></center><br><input id="ujdmsk" type="text"/><img id="dmskinfo" src="ico/info.png"><h3 id="dmskinfotext">The DMSK 240B-F system adds an additional parameter to the encoding of messages  to you. Your default code can be found in the registration email. Modify it as soon as possible. The validation rules valid for the password are valid for the code (minimum 10 characters large and small letters and numbers.)</h3></div><br><label>Key synchronous intervals secundum</label><input id="kulcsszinkronsetup" type="number" style="color:yellow;background:black" min="15" max="160" value="29" step="5"><br><label>Message verification intervals secundum</label><input id="uzenetellenorzessetup" type="number" style="color:yellow;background:black" min="10" max="1800" value="15" step="5"><br><label>Time lock on minutes</label><input id="idozarsetup" type="number" style="color:yellow;background:black" min="1" max="60" value="5" step="1"></div>';
            case 41:
                return '<br/><button id="help" class="gombok tooltip">Online help</button><br/><button id="jkk" class="gombok tooltip">Client code</button><h3>To change the password and user name, click the icon</h3><br><img id="belepoinfo" src="ico/gear.png" alt="Információk"/><br><div id = "beinfo"><div><h3>For desktop users:<br><br>CTRL + Q will bring this information visible. After ENTER button the message list<br>CTRL+X logout<br>CTRL+Y instant key sync<br>CTRL+0 (null) menümagnes on-off<br>CTRL+F1 Online help<br>CTRL+F2 messaging menu<br>ESC Close the system message</h3><br>' + "<h3> Please do not refresh the page because your generated ID entitles you to one-time access. Use the web application buttons. If the page is updated, you must be signed in again. To browse, open a new tab in your browser. You will also be signed out by closing the page. <br/>" + "While the page is open, you will be notified of new messages.<br/></h3><div><label" + ' for = "message"> Old password: </label><input type="password" id="regijelszo"/></div><div><label for = "message"> New password: </label><input type="password" id="passa"/></div><div><label for = "message">New password again</label><input type="password" id="passb"/><div><label for = "message">Change User Name </label><input type="text" id="ujnicname"/></div>' + "</div><h3><br/>If you are a new user, change your password. Minimum 10 characters lowercase, upper case, number</h3></div>";
            case 42:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mode off</h1></div>';
            case 43:
                return szovegetide(2, 62) + '<br />For DMSK-240B-F, the minimum requirements are the same as the password.';
            case 44:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mode on</h1><h3>If the wrong code is entered, the application will not work properly. You can only modify the code after entering the correct code.</h3></div>';
            case 45:
                return szovegetide(2, 62) + '<br />To modify the DMSK-240B-F code, you need to turn it on with the current valid code.';
            case 46:
                return szovegetide(2, 62) + '<br />Please enter a properly complex code.';
            case 47:
                return szovegetide(2, 62) + '<br />The maximum length of the code is 199 characters, the minimum length is 8 characters.';
            case 48:
                return szovegetide(2, 62) + '<br />The code contains an illegal character.';
            case 49:
                return szovegetide(2, 62) + '<br />There was an error changing the code';
            case 50:
                return szovegetide(2, 62) + '<br />The code has been modified successfully.';
            case 51:
                return szovegetide(2, 62) + '<br />An error occurred during this operation';
            case 52:
                return ' \n\n---- Answer:';
            case 53:
                return '<div id="page-wrapper"><h1>Send Message</h1><br><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Choose you want to send a message to everyone or just some of the users. Your message is displayed for the maximum length of time. The message automatic delete after the expiration time. There is no way to retrieve it.</h3><br><div><center><div id="uzenetkuldes_radio"><input type="radio" name="kuldes" value="select" checked="checked">Send a reply message<br><div id="tagidlist"><br><select name="tagoklista" id="taglista"><option value="';
            case 54:
                return '<div id="page-wrapper"><h1>Send Message</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Choose you want to send a message to everyone or just some of the users. Your message is displayed for the maximum length of time. The message automatic delete after the expiration time. There is no way to retrieve it.</h3><br><div><center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all">Send message to all users<br><input type="radio" name="kuldes" value="select" checked="checked">Send a message to the selected users<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div><br>' + filefelt + '<br>'+hangfelt+'<label>Message Text</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Encrypted messages will NOT be saved! Files must be protected by a password or key file.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft">Forwarded Message:\n\n' + kapottuzenetszovege + '</textarea>' + '<br><button class="gombok" id="kiurit">Clear Text</button><br><label>The message password protected</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Enter the maximum validity time for your message in hours</label><input type="number" id="maxido" value="48" min="1" max="168"></div>';
            case 55:
                return '<div id="page-wrapper"><h1>Messaging web application<br>PMWA<br>DMSK-240B-F<br>One Time Pad<br>Alias Verman encrypter</h1></div>';
            case 56:
                return '<h2>Offline connection, no message list available</h2>';
            case 57:
                return szovegetide(2, 62) + ' <br/> You have no messages to display <br><br><p class = "adatokmegjelenitesek">Sent Data: ' + (kuldottadat / 1024 / 1024).toFixed(4) + 'MB </p><p class="adatokmegjelenitesef">Received data: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Number of total (out and in) data packets: ' + szerverkapcsolatszam + '</p>';
            case 58:
                return '<h2>Key synchron error. Synchronize manually or wait until the system resynchronizes.</h2><br><p class="adatokmegjelenitesek">Sent Data:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Received data:' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Number of total (out and in) data packets: ' + szerverkapcsolatszam + '</p>';
            case 59:
                return '<br><p class="adatokmegjelenitesek">Sent Data:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Received data: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Number of total (out and in) data packets: ' + szerverkapcsolatszam + '</p>';
            case 60:
                return '<h2>Offline status: saved message list</h2><br>';
            case 61:
                return; //'<br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 62:
                return '<span class="tooltiptext "><p class="elrejt">Hide information</p></span>';
            case 63:
                return 'Received data:';
            case 64:
                return 'Number of total (out and in) data packets:';
            case 65:
                return 'Sent Data:';
            case 66:
                return 'Do it';
            case 67:
                return 'Submit';
            case 68:
                return '<div><h3>There are unsent messages</h3></div><div><h3 style="color:brown">Are you sure you want to quit the application?</h3><br>';
            case 69:
                return 'Confirmation';
            case 70:
                return '<div><h3>Are you sure you want to cancel your registration?</h3></div><div><h3 style="color:brown">Then enter your password</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 71:
                return szovegetide(2, 62) + '<br />After DMSK encoding, the length of the message exceeds the allowed size. Please encrypt the message or shorten it.';
            case 72:
                return szovegetide(2, 62) + '<br /> You can not send a file without password or keyfile encryption.';
            case 73:
                return szovegetide(2, 62) + '<br />The length of the key file is less than the data, in contrast to the OTP cipher encryption. Please choose a larger key file.';
            case 74:
                return szovegetide(2, 62) + '<br />The length of the key file is less than the data, in contrast to the OTP cipher encryption. Please choose a larger key file.';
            case 75:
                return '<img src = "images/sportcsarnok.jpg" id = "terkep" alt="Loading image failed ..."><div id="helyszin" class="helyszin">Helyszin: Izsák, Sportcsarnok</div>';
            case 76:
                return 'Sign up';
            case 77:
                return 'Log in';
            case 78:
                return '<div id="page-wrapper"><h3>The user name you entered when you registered and if you have not yet changed the password you received. The Web application uses DMSK-240B or DMSK-240B-F encrypted to send and receive data. Even if it does not work with a HTTPS connection, it provides the right protection for the information it has sent to you.</h3><br /><h1>Login</h1><div class="field"><label >Username:</label><input type="text" id="loginname"></div><div class="field"><label for="message">Password:</label><input type="password" id="loginpass"></input><br><label>Get out of any other device</label><input id="kileptetes" type="checkbox" class="kileptetes"></div></div>';
            case 79:
                return szovegetide(2, 62) + '<br />Include at least one number.';
            case 80:
                return szovegetide(2, 62) + '<br />Include minimum one lowercase.';
            case 81:
                return szovegetide(2, 62) + '<br />Include minimum one uppercase.';
            case 82:
                return szovegetide(2, 62) + '<br />Server error (500)';
            case 83:
                return szovegetide(2, 62) + '<br />The webserver temporarily rejected the request. Try it again. (503)';
            case 84:
                return szovegetide(2, 62) + '<br />Page not available (404)';
            case 85:
                return szovegetide(2, 62) + '<br />There was an error send the data(400)';
            case 86:
                return szovegetide(2, 62) + '<br />The page is unavailable (0)';
            case 87:
                return szovegetide(2, 62) + '<br />Send data over 1 MB  piece. Auto cut is done. Please wait until every 500kb piece is sent.';
            case 88:
                return szovegetide(2, 62) + '<br />Connection is offline, check your Internet connection.';
            case 89:
                return szovegetide(2, 62) + '<br />The connection is online.';
            case 90:
                return szovegetide(2, 62) + '<br />The length of the login name or password is incorrect';
            case 91:
                return 'Check your User Name.';
            case 92:
                return "Connection error: try submitting your the login again";
            case 93:
                return szovegetide(2, 62) + '<br />Please enter the code before pressing the Send button';
            case 94:
                return '<h1>The registration code you entered is not valid</h1>';
            case 95:
                return "To access functions after you login, you have to wait for Administrator check.";
            case 96:
                return szovegetide(2, 62) + '<br />Reserved name';
            case 97:
                return szovegetide(2, 62) + '<br />The name must be at least 4 characters, and the email address is live because it receives the code for confirmation';;
            case 98:
                return szovegetide(2, 62) + '<br />The email address format is incorrect: pelda@valami.com';
            case 99:
                return szovegetide(2, 62) + '<br />The user name contains an unsuitable character.';
            case 100:
                return "<h1>The given username is already occupied, please use some distinctive information.</h1>";
            case 101:
                return '<div id="page-wrapper"><h3>Please follow the instructions and press the send button.</h3><br /><h1>Confirmation</h1><div id="regisztral" class="field"><label>Please enter the code you received in your email:</label><input type="password" id="regkod"></div></div>';
            case 102:
                return 'Fault! Sending message failed. The server will not accept the requests.';
            case 103:
                return 'Fault! Upload failed.';
            case 104:
                return '<h3 id="udvszoveg"><br>Welcome to the one group\'s private messaging webpage homepage.<br></h3>';
            case 105:
                return '<h1 id="honlapra">SEMOTUS</h1>'; //
            case 106:
                return 'home<span class = "tooltiptext"> Home. </span>';
            case 107:
                return 'locations<span class = "tooltiptext" > Correct address</span>';
            case 108:
                return 'data protection<span class = "tooltiptext"> Privacy Statement. </span>';
            case 109:
                return 'login<span class="tooltiptext">Information, messages. Login required.</span>';
            case 110:
                return 'registration<span class = "tooltiptext" > Accessing internal information </span>';
            case 111:
                return 'Successful login';
            case 112:
                return 'log-out<span class=\"tooltiptext \">Home.</span>';
            case 113:
                return 'Fullscreen-on<span class=\"tooltiptext\">Turn full screen mode on and off</span>';
            case 114:
                return 'messages<span class=\"tooltiptext \">See your messages here</span>';
            case 115:
                return 'Send a message<span class=\"tooltiptext\">You can post messages here</span>';
            case 116:
                return 'DMSK setup<span class=\"tooltiptext\">You can turn it off, turn on DMSK-240B-F or change the code</span>';
            case 117:
                return 'delete all<span class=\"tooltiptext\">After confirmation, you can permanently delete your registration information.</span>';
            case 118:
                return 'Admin<span class=\"tooltiptext\">Manage administrative tasks and users.</span>';
            case 119:
                return ' You will not be able to access the features of the web application before checking user rights. Your patience please: Admin';
            case 120:
                return 'Welcome to the messaging web application';
            case 121:
                return 'Welcome to the messaging web application-ADMIN status';
            case 122:
                return 'Cancel';
            case 123:
                return szovegetide(2, 62) + '<br />A jelszavas védelem törlése végrehajtva. Most még adhat meg másik jelszót.';
            case 124:
                return '<div><h3>Send encrypted message</h3></div><div><h3 style="color:brown">Enter the password that the recipient also knows</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 125:
                return 'Encryption';
            case 126:
                return 'The length of the password must be at least 10 characters (30 characters recommended)';
            case 127:
                return szovegetide(2, 62) + '<br />The password is correct. Keep in mind that the recipient can not read the message without the password.';
            case 128:
                return '<label>OTP  Encryption</label><label id="kflabel">Use a key file for encryption<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/></label>';
            case 129:
                return '<button id="filefel" class="gombok tooltip">Send file</button><label id="fmtlab">The file is already encrypted</label><input id="cb_titkositott" type="checkbox" class="kileptetes">';
            case 130:
                return 'Keyfile size cant range from 10kb to 30MB';
            case 131:
                return szovegetide(2, 62) + '<br />The encryption file property';
            case 132:
                return 'File: ';
            case 133:
                return 'Property: ';
            case 134:
                return 'Size: ';
            case 135:
                return ' MB<br>Please note that without the knowledge of the key file the data can not be retrieved on the receiving side!';
            case 136:
                return 'Delete Key File';
            case 137:
                return 'Use a key file for encryption<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/>';
            case 138:
                return szovegetide(2, 62) + '<br />The key file has been deleted.';
            case 139:
                return 'Send file';
            case 140:
                return szovegetide(2, 62) + '<br />The file to be sent was deleted.';
            case 141:
                return 'File Selected';
            case 142:
                return 'The file size can be between 1kb and 10MB';
            case 143:
                return szovegetide(2, 62) + '<br />Details of the file selected for sending';
            case 144:
                return 'The name of this file sent at the same time:';
            case 145:
                return '<div><h3>Decrypt encrypted message</h3></div><div><h3 style="color:brown">Enter the password that the sender encrypted the message</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 146:
                return 'Decrypt';
            case 147:
                return 'If you have written a bad password, download the message again for decoding.';
            case 148:
                return '<div><h3>Decrypt encrypted file</h3></div><div><h3 style="color:brown">Enter the password.</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 149:
                return 'If you have written a bad password, download the file again for decoding.';
            case 150:
                return szovegetide(2, 62) + '<br />Data for file used for decoding';
            case 151:
                return 'If you entered the wrong key file, download the message again for decoding.';
            case 152:
                return 'Over 1 minute turned off key sync.  It causes a system error after 2 minutes of inactivity.';
            case 153:
                return '" selected>REPLY</option></select></div></div>';
            case 154:
                return '<label>Message text</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Encrypted messages will NOT be saved! Files can only be sent by password or key file encode.</h3><textarea id="ujuzenet" rows="20" cols="40">';
            case 155:
                return '</textarea><br><button class="gombok" id="kiurit">Clear Text</button><br><label>The message password protected</label><button class="gombok" id="pinvedett">Password</button><br>';
            case 156:
                return '<label>Enter the maximum validity time for your message in hours</label><input type="number" id="maxido" value="48" min="1" max="168"></div></div>';
            case 157:
                return 'Web Application Administration';
            case 158:
                return 'Users';
            case 159:
                return 'Cleaner';
            case 160:
                return 'Back';
            case 161:
                return 'User List';
            case 162:
                return ' row deleted from the database';
            case 163:
                return 'Number of active connections to the database: ';
            case 164:
                return ' All communications';
            case 165:
                return '<div><h3>Are you sure to unlock the communication block?</h3></div><div><h3 style="color:brown">Then enter your password</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 166:
                return '<div><h3>Are you sure you block all communications?</h3></div><div><h3 style="color:brown">Then enter your password</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 167:
                return '<div><h3>Are you sure you want to cleanse the database?</h3></div><div><h3 style="color:brown">Then enter your password</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 168:
                return 'Are you sure you want to activate it? Do you know the user?';
            case 169:
                return 'Are you sure that the user will be suspended?';
            case 170:
                return 'Are you sure you want to delete the entire group?';
            case 171:
                return 'Then enter your password';
            case 172:
                return 'The administrator can not be deleted only with the group';
            case 173:
                return 'Are you sure you want to delete the user\'s registration ?';
            case 174:
                return 'Server Status: ';
            case 175:
                return 'Received messages';
            case 176:
                return 'Sender: ';
            case 177:
                return 'Message: DMSK protection';
            case 178:
                return 'Message: Key file protected';
            case 179:
                return '"OneTimePad" protected file';
            case 180:
                return 'Password-protected file';
            case 181:
                return 'Message: Password protected';
            case 182:
                return ' Sending time: ';
            case 183:
                return 'Message Size: ';
            case 184:
                return 'Total message size: ';
            case 185:
                return 'I download';
            case 186:
                return 'Download message for reading.';
            case 187:
                return 'Delete it !!!';
            case 188:
                return 'If you click here, the message will no longer be displayed.';
            case 189:
                return 'Downloaded message';
            case 200:
                return 'DMSK protected message';
            case 201:
                return '"OneTimePad" protected message. It decodes it for viewing';
            case 202:
                return 'Password-protected message. It decodes it for viewing';
            case 203:
                return 'Password encrypted file. To save it, you have to decode it';
            case 204:
                return '"OneTimePad" protected file. To save it, you have to decode it.';
            case 205:
                return 'Reply';
            case 206:
                return 'Write a reply to the message.';
            case 207:
                return 'I have read';
            case 208:
                return 'If you click here, the message will no longer be displayed.';
            case 209:
                return 'Enter a password for decoding the encrypted message.';
            case 210:
                return 'Transfers';
            case 211:
                return 'To forward the message to another user.';
            case 212:
                return 'Delete';
            case 213:
                return 'Save';
            case 214:
                return 'Enter a password for decoding the encrypted message.';
            case 215:
                return 'The login does not apply.';
            case 216:
                return 'Filling out fields was incorrect ... (code:400)';
            case 217:
                return 'The user name min 4 is the password minimum 10 characters';
            case 218:
                return 'Theoretically, the maximum HTTP data packet received by the server is: ';
            case 219:
                return 'By sending the reply and pressing the read key, the message will be deleted.<br> The transmitted message can be retrieved within its validity period.';
            case 220:
                return 'Resume: ';
            case 221:
                return 'Rebuilding the data packet on the server';
            case 222:
                return 'Send data over 1 MB  piece. Auto cut is done. Please wait until every 500kb piece is sent.';
            case 223:
                return 'The number of login attempts failed with your user named: ';
            case 224:
                return ' It is recommended that you change your logon for security reasons';
            case 225:
                return 'Registered:';
            case 226:
                return 'Registration started';
            case 227:
                return 'List of devices used to access:';
            case 228:
                return 'Delete';
            case 229:
                return 'Aktiválom';
            case 230:
                return 'Activate';
            case 231:
                return 'Suspend';
            case 232:
                return 'Active user';
            case 233:
                return 'Administrator';
            case 234:
                return 'Group-KILL';
            case 235:
                return 'Freedom on the server: ';
            case 236:
                return 'Total location on server: ';
            case 237:
                return 'Logged out of the device';
            case 238:
                return 'Signed in to your device: ';
            case 239:
                return 'Number of log-in: ';
            case 240:
                return 'There is an error in the format of the specified email address.';
            case 241:
                return 'You have already registered with the given email address.';
            case 242:
                return 'Please check your email account and enter the verification code you received to complete your registration.';
            case 243:
                return 'You can not send a file in Offline mode.';
                case 244:
                    return 'Megadhatja a kulcsszinkron gyakoriságát 15 és 110 másodperc között.';
                case 245:
                    return 'DMSK kulcs, váltás idő beállítás';
                case 246:
                    return 'Megadhatja az üzenetellenörzés gyakoriságát 10 másodperc és 30 perc között másodpercben.';
                case 247:
                    return 'Új üzenetek ellenörzése';
                case 248:
                    return 'Add meg a jelszavad';
                case 249:
                    return 'Időzár';
                case 250:
                    return '<br><button id="hangfelvetel" class="gombok tooltip">Voice message</button><br>';
                case 251:
                    return szovegetide(2, 62) + '<br />The voice message has been deleted';
                case 252:
                    return '<br><h2>Saving audio messages is not safe.</h2><br>';
                case 253:
                    return szovegetide(2, 62) + '<br/>Java message verification client has its code:' + juszlkk + '<br/>Available from the clipboard.';
                case 254:
                    return 'The file is encrypted';
                case 255:
                    return 'The file was transmitted   with the webapplication  you sender has labeled it  external encryption. Save and decode it.';
                case 256:
                    return;
                case 257:
                    return;
                case 258:
                    return;
                case 259:
                    return;
        }

    } else if (milyennyelven == 3) {
        switch (hovakered) {
            case 1:
                return 'Полное изображение-офф<span class=\"tooltiptext\">Включение и выключение полноэкранного режима</span>';
            case 2:
                return 'Teljeskép-be<span class=\"tooltiptext\">Teljes képernyős mód ki és bekapcsolása</span>';
            case 3:
                return '<audio controls autoplay hidden><source src=\"1.mp3\" type=\"audio/mpeg\"></audio>';
            case 4:
                return 'Üzenet: ';
            case 5:
                return '<img id=\"messimg\" src=\"ico/error.png\"><img id=\"messimg\" src=\"ico/erdsmk.png\">';
            case 6:
                return '<img id=\"messimg\" src=\"ico/error.png\">';
            case 7:
                // return '<div id="adatvedelem">' +
                //     '<h2></br>ADATVÉDELMI ÉS ADATKEZELÉSI SZABÁLYZAT 2018. </br>Hatályos: 2018. május 25. napjától</h2><h3>Általános rendelkezések</h3> A Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95), mint az Adatkezelő aáltala üzemeltetett http:// egyuttmozgas.probaljaki.hu weboldal és az ott meghatározott egyéb címeken elérhető weboldalak(a továbbiakban: „weboldal”) által nyújtott szolgáltatásaihoz kapcsolódóan a felhasználó természetes személyek („ügyfél“) valamennyi adatkezelése során a jelen Adatvédelmi és Adatkezelési Szabályzat és Tájékoztató alapján jár el. Az Ügyfél a weboldalra történő belépéssel, és a weboldal használatával magára nézve kötelezőnek fogadja el a jelen szabályzat rendelkezéseit. A szabályzat célja, hogy meghatározza az Adatkezelő által kezelt személyes adatok körét, az adatkezelés módját, valamint biztosítsa az adatvédelem és adatkezelés alkotmányos elveinek, az adatbiztonság követelményeinek érvényesülését annak érdekében, hogy a felhasználó természetes személyek magánszférájának a tiszteletben tartása megvalósuljon az érintettek személyes adatainak gépi feldolgozása, illetőleg kezelése során. <h3>1. Értelmező rendelkezések</h3> <h4>1.1. Adatkezelő:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, a ki vagy amely önállóan vagy másokkal együtt az adat kezelésének célját meghatározza, az adatkezelésre (beleértve a felhasznált eszközt) vonatkozó döntéseket meghozza és végrehajtja, vagy az adatfeldolgozóval végrehajtatja.<h4> 1.2. Adatkezelés:</h4> az alkalmazott eljárástól függetlenül az adaton végzett bármely művelet vagy a műveletek összessége, így különösen gyűjtése, felvétele, rögzítése, rendszerezése, tárolása, megváltoztatása, felhasználása, lekérdezése, továbbítása, nyilvánosságra hozatala, összehangolása vagy összekapcsolása, zárolása, törlése és megsemmisítése, valamint az adat további felhasználásának megakadályozása, fénykép-, hang- vagy képfelvétel készítése, valamint a személy azonosítására Adatvédelmi és Adatkezelési Szabályzat 2018 2 alkalmas fizikai jellemzők (pl. ujj- vagy tenyérnyomat, DNS-minta, íriszkép) rögzítése. <h4>1.3. Személyes adat:</h4> az érintettel kapcsolatba hozható adat - különösen az érintett neve, azonosító jele, valamint egy vagy több fizikai, fiziológiai, mentális, gazdasági, kulturális vagy szociális azonosságára jellemző ismeret -, valamint az adatból levonható, az érintettre vonatkozó következtetés.<h4> 1.4. Hozzájárulás:</h4> az érintett akaratának önkéntes és határozott kinyilvánítása, amely megfelelő tájékoztatáson alapul, és amellyel félreérthetetlen beleegyezését adja a rá vonatkozó személyes adat- teljes körű vagy egyes műveletekre kiterjedő – kezeléséhez. <h4>1.5. Adatfeldolgozás:</h4> az adatkezelési műveletekhez kapcsolódó technikai feladatok elvégzése, függetlenül a műveletek végrehajtásához alkalmazott módszertől és eszköztől, valamint az alkalmazás helyétől, feltéve hogy a technikai feladatot az adaton végzik. <h4>1.6. Adatfeldolgozó:</h4> az a természetes vagy jogi személy, illetve jogi személyiséggel nem rendelkező szervezet, aki vagy amely szerződés alapján - beleértve a jogszabály rendelkezése alapján kötött szerződést is - adatok feldolgozását végzi. <h4>1.7. Érintett:</h4> bármely meghatározott, személyes adat alapján azonosított vagy - közvetlenül vagy közvetve - azonosítható természetes személy.<h3> 2. Az adatkezelő megnevezése : </h3>Dobosné Reisinger Miléna magánszemély. (székhelye: 6040 Izsák Matyo 95. Email: <span id="emailcim">milena&copy;egyuttmozgas.probaljaki.hu</span> évi CXII. törvény 65. § (3) a) pontja értelmében nem vezet adatvédelmi nyilvántartást a Hatóság arról az adatkezelésről, amely az adatkezelővel munkaviszonyban, tagsági viszonyban, - a pénzügyi szervezetek, közüzemi szolgáltatók, elektronikus hírközlési szolgáltatók ügyfelei kivételével - ügyfélkapcsolatban álló személyek adataira vonatkozik.<h3> 3. Az adatok megismerésére jogosult természetes és jogi személyek, az adatfeldolgozó:</h3> Az adatokat az Adatkezelő Alapszabályában és SZMSZ-ében meghatározott vezetősége, illetve a vezetőség által külön ferre felhatalmazott Adatvédelmi és Adatkezelési Szabályzat 2018 3 személyek jogosultak megismerni Adatkezelő az adatokat nem teszik közzé, harmadik személyek számára nem adják ki.<h3> 4. A kezelt személyes adatok köre:</h3> A jelen szabályzat kizárólag a természetes személyek adatainak a kezelésére terjed ki, tekintettel a szabályzat arra, hogy személyes adatok kizárólag természetes személyek vonatkozásában értelmezhetők. A Weboldal bármely internethasználó által regisztráció nélkül hozzáférhető tartalmakat is biztosít. Bizonyos tartalmi szolgáltatásai és hírlevél funkciója azonban csak regisztrált felhasználók számára hozzáférhető. Regisztrált felhasználó az lehet, akit a az Adatkezelő a saját belső szabályzatának megfelelően erre feljogosít. A regisztráció folyamata ingyenes. <h4>4.1. A regisztráció során az Ügyfélnek kötelezően meg kell adnia a következő személyes adatokat:</h4> <li> Ügyfél neve,</li> <li>E-mail címe</li> <h4> 4.2.</h4> A www.egyuttmozgas.probaljaki.hu (továbbiakban: Weboldal) adatbázisa az Ügyfél adatait a regisztrációval nyújtott ingyenes szolgáltatások teljesítése érdekében tárolja, azokat az adatkezelő továbbadni sem reklámfelhasználás, sem egyéb célra - az Ügyfél kifejezett hozzájárulása hiányában - nem jogosult. <h4>4.3.</h4> A Weboldalon tett látogatások során egy vagy több cookie-t - apró információcsomagot, amelyet a szerver küld a böngészőnek, majd a böngésző visszaküld a szervernek minden, a szerver felé irányított kérés alkalmával - küldünk az Ügyfél számítógépére, amely(ek) révén annak böngészője egyedileg azonosítható lesz. Ezen cookie-k kizárólag a felhasználói élmény javítása, a belépési folyamat automatizálása, valamint reklámtevékenységünk hatékonyságának mérése érdekében működnek. <h4>4.4.</h4> Az Ügyfél személyes adatainak kezelése során a Szolgáltató betartja az információs önrendelkezési jogról szóló 2011. évi CXII. törvény előírásait. <h4>4.5.</h4> Az Ügyfél mindenkor jogosult az adatkezelést letiltani. <h3>5. Az adatkezelés jogalapja, módja és célja Adatvédelmi és Adatkezelési Szabályzat 2018 </h3> <h4>5.1.</h4> Az adatkezelés jogalapja az Ügyfél önkéntes hozzájárulása. A hozzájárulást az Ügyfél a fentiekben megjelölt adatok kezelése tekintetében jelen adatvédelmi szabályzat előzetes megismerését követően a regisztrációval, a kérdéses adatok önkéntes megadásával adja meg. A hírlevéllel kapcsolatban az Ügyfél az erre vonatkozó jelölőnégyzet kipipálásával kifejezett és önkéntes hozzájárulását adja ahhoz, hogy Adatkezelő a Weboldallal kapcsolatos híreket, információkat küldjön az Ügyfél által a regisztráció során megadott e-mail címre. <h4>5.2.</h4> Az adatkezelés célja a tartalomszolgáltatás és az ezzel, valamint az Adatkezelő egyesület működésével összefüggő egyéb információk megadása. A Szolgáltató az Ügyfél által rendelkezésre bocsátott adatokat célhoz kötötten tárolja. Ügyfél a weboldalon történő regisztrációval hozzájárul ahhoz, hogy személyes adatait az alábbi célokra felhasználhassuk:  hírlevél szolgáltatás tartalomszolgáltatás <h4>5.3.</h4> A regisztráció során megadott elektronikus levélcímek (e-mail címek) adatkezelő általi felhasználásának módja a következő: az e-mail címek kezelése az ügyfél azonosítását, a szolgáltatások igénybevétele során a kapcsolattartási célokat, illetőleg az ügyfél részére hírlevél megküldésére szolgál. Adatkezelő az általa nyújtott szolgáltatásokra vonatkozó tájékoztatást elektronikus formában, e-mailben juttatja el ügyfél részére. Adatkezelő az ügyfél kifejezett hozzájárulásával küld a regisztráció során megadott e-mail címre a Weboldal tartalmaival és a gyakorlások szervezésével kapcsolatos információkat tartalmazó hírleveleket. Adatkezelő kizárólag azon ügyfelei számára küld hírleveleket, akik az erre szolgáló menüpontban ehhez kifejezett hozzájárulásukat adták.<h4> 5.4.</h4> Az Ügyfél a hírlevél szolgáltatásról bármikor, ingyenesen és indoklás nélkül leiratkozhat. A leiratkozás történhet egyetlen lépésben, a hírlevélben található linkre kattintással, illetve leiratkozhat az Adatkezelőnek küldött e-mail formájában is. Ebben az esetben Adatkezelő haladéktalanul törli a nyilvántartásából az Ügyfél adatait. <h4>5.5.</h4> Az Ügyfél által megadott telefonszám adatkezelő általi felhasználási célja a következő: az folyamat során kapcsolattartási célokat szolgál. <h4>5.6.</h4> Az Ügyfél adatait kizárólag számítástechnikai eszközzel végrehajtott adatfeldolgozással kezeljük. Az automatikusan rögzítésre kerülő adatok célja statisztika-készítés, az informatikai rendszer technikai fejlesztése, a felhasználók jogainak védelme. Az automatikusan rögzítésre kerülő adatok az alábbiak: az ügyfél számítógépének dinamikus IP címe, az ügyfél számítógépének beállításaitól függően az ügyfél által használt számítógép operációs rendszerének és böngészőjének típusa, az ügyfélnek a Weboldallal kapcsolatos aktivitása. Ezen adatok felhasználása egyrészről technikai célokat szolgál - pl. a szerverek biztonságos üzemeltetése, utólagos ellenőrzése, másrészt az Adatkezelő ezen Adatvédelmi és Adatkezelési Szabályzat 2018 5 adatokat oldalhasználati statisztikák készítéséhez, a felhasználói igények elemzéséhez használja fel a szolgáltatások színvonalának emelése érdekében. A fenti adatok az ügyfél azonosítására nem alkalmasak, és ezeket a Szolgáltató egyéb személyes adatokkal nem kapcsolja össze. <h4>5.7.</h4> Az adatkezelő a megadott személyes adatokat az e pontokban írt céloktól eltérő célokra nem használhatja fel. Személyes adatok harmadik személynek vagy hatóságok számára történő kiadása - hacsak törvény ettől eltérően nem rendelkezik kötelező erővel - a felhasználó előzetes, kifejezett hozzájárulása esetén lehetséges kizárólag.<h4> 5.8.</h4> Adatkezelő a neki megadott személyes adatokat nem ellenőrzi. A megadott adatok megfelelőségéért kizárólag az azt megadó személy felel..' +
                //     "Bármely Ügyfél e-mail címénekmegadásakor egyben felelősséget vállal azért, hogy a megadott e-mail címről kizárólag ő vesz igénybe szolgáltatást. E felelősségvállalásra" +
                //     "tekintettel egy megadott e-mail címen történt belépésekkel összefüggő mindennemű felelősség kizárólag azt a felhasználót terheli, aki az e-mail címet regisztrálta.<h3> 6. Az adatkezelés időtartama</h3> <h4>6.1.</h4> A regisztráció során kötelezően megadott adatok kezelése a regisztrációval kezdődik és annak törléséig tart. Nem kötelező adatok esetén az adatkezelés az adat megadásának időpontjától a kérdéses adat törléséig tart. A regisztráció során rögzített adatok megváltoztatását, vagy törlését a regisztrált Ügyfél a bejelentkezést követően a „Saját fiókban” kezdeményezheti. <h4>6.2.<h4> Fenti rendelkezések nem érintik a jogszabályban (pl. számviteli jogszabályokban) meghatározott megőrzési kötelezettségek teljesítését. <h3>7. Az adatokat megismerni jogosult személyek köre</h3> <h4>7.1.</h4> Az adatokat elsődlegesen Adatkezelő, illetve Adatkezelő belső munkatársai jogosultak megismerni, azonban azokat nem teszik közzé, harmadik személyek részére nem adják át.<h4> 7.2.</h4> Az alapul fekvő informatikai rendszer üzemeltetése, a megrendelések teljesítése, az elszámolás rendezése körében Adatkezelő adatfeldolgozót (pl. rendszerüzemeltető, könyvelő) vehet igénybe. Adatkezelő az ilyen külső szereplők adatkezelési gyakorlatáért nem felelős.<h4> 7.3. </h4>A fentieken túl az Ügyfélre vonatkozó személyes adatok továbbítására kizárólag törvényben kötelezően meghatározott esetben, illetve az Ügyfél hozzájárulása alapján kerülhet sor. <h3>8. Az ügyfél jogai Adatvédelmi és Adatkezelési Szabályzat 2018 6</h3> <h4>8.1.</h4> Az Ügyfél bármikor jogosult tájékoztatást kérni a Adatkezelő által kezelt, rá vonatkozó személyes adatokról, továbbá bármikor módosíthatja azokat. Ügyfél jogosult továbbá adatai törlésének kérésére az e pontban megadott elérhetőségek útján. <h4>8.2.</h4> Szolgáltató az Ügyfél kérésére tájékoztatást ad a rá vonatkozó, általa kezelt adatokról, az adatkezelés céljáról, jogalapjáról, időtartamáról, továbbá arról, hogy kik és milyen célból kapják vagy kapták meg adatait. Szolgáltató a kérelem benyújtásától számított 30 napon belül írásban adja meg a kért tájékoztatást.<h4> 8.3.</h4> Az Ügyfél bármely, az adatkezeléssel kapcsolatos kérdéssel, illetve észrevétellel az Adatkezelő munkatársához fordulhat a fenti elérhetőségeken keresztül. Levelezési cím: 6070 Izsák Matyó 95<h4> 8.4.</h4> Az Ügyfél bármikor jogosult a helytelenül rögzített adatainak helyesbítését, vagy azok törlését kérni. Egyes adatait az Ügyfél a Honlapon maga helyesbítheti; egyéb esetekben Szolgáltató a kérelem beérkezésétől számított 3 munkanapon belül törli az adatokat, ez esetben azok nem lesznek újra helyreállíthatók. A törlés nem vonatkozik a jogszabály (pl. számviteli szabályozás) alapján szükséges adatkezelésekre, azokat Szolgáltató a szükséges időtartamig megőrzi.<h4> 8.5.</h4> Az ügyfél bíróság előtt érvényesítheti jogait, kérheti továbbá az adatvédelmi biztos segítségét is. Ügyfél, jogsértés esetén jogorvoslatért fordulhat: az Adatvédelmi Biztos Hivatalához (1051 Budapest, Nádor u. 22.) A Nemzeti Adatvédelmi és Információszabadság Hatósághoz<h4> 8.6.</h4> Amennyiben az Ügyfél szolgáltatás igénybevételéhez a regisztráció során harmadik fél adatait adta meg, vagy a Weboldal használata során bármilyen módon kárt okozott, a Szolgáltató jogosult az Ügyféllel szembeni kártérítés érvényesítésére. A Szolgáltató ilyen esetben minden tőle telhető segítséget megad az eljáró hatóságoknak a jogsértő személy személyazonosságának megállapítása céljából. <h3>9. Egyéb rendelkezések </h3><h4>9.1.</h4> Szolgáltató rendszere a felhasználók aktivitásáról adatokat gyűjthet, melyek nem kapcsolhatóak össze a felhasználók által a regisztrációkor megadott egyéb adatokkal, sem más honlapok vagy szolgáltatások igénybevételekor keletkező adatokkal. <h4>9.2.</h4> Minden olyan esetben, ha a szolgáltatott adatokat a Szolgáltató az eredeti adatfelvétel céljától eltérő célra kívánja felhasználni, erről a felhasználót tájékoztatja, és ehhez előzetes, kifejezett hozzájárulását megszerzi, illetőleg lehetőséget biztosít számára, hogy a felhasználást megtiltsa. <h4>9.3.</h4> Szolgáltató kötelezi magát, hogy gondoskodik az adatok biztonságáról, megteszi továbbá azokat a technikai intézkedéseket, amelyek biztosítják, hogy a felvett, tárolt, illetve kezelt adatok védettek legyenek, illetőleg mindent megtesz annak érdekében, hogy megakadályozza azok megsemmisülését, jogosulatlan felhasználását és jogosulatlan megváltoztatását. Kötelezi magát arra is, hogy Adatvédelmi és Adatkezelési Szabályzat 2018 7 minden olyan harmadik felet, akiknek az adatokat esetlegesen továbbítja vagy átadja, ugyancsak felhívja ez irányú kötelezettségeinek teljesítésére. <h4>9.4.</h4> Szolgáltató fenntartja a jogot, hogy jelen Szabályzatot az Ügyfelek előzetes értesítése mellett egyoldalúan módosítsa. A módosítás hatályba lépését követően az Ügyfél a szolgáltatás használatával ráutaló magatartással elfogadja a módosított Szabályzatban foglaltakat. Az Adatkezelő magára nézve kötelezőnek ismeri el jelen szabályzat tartalmát, és kötelezettséget vállal arra, hogy szolgáltatásával kapcsolatos adatkezelése megfelel a jelen szabályzatban megfogalmazott előírásoknak." +
                //     "</div>";
                return;
            case 8:
                return '<div id="page-wrapper"><h3>Kövesd a leírtakat. A WebApp alapértelmezésben DMSK-240B titkosítást használ az adatok küldéséhez és fogadásához. (Regisztráció után választható opciók : DMSK-240B-FULL , O.T.P , valamint jelszavas  titkosítások, szöveg és fájlátvitelhez.)</h3><br /><h1>Regisztráció</h1><div class="field"><label for="name">Add meg a felhasznlói neved:</label><input type="text" id="name" ><div id="regisztral" class="field"><label >Add meg az email címed:</label><input type="email" id="email"></div></div>'; //----
            case 9:
                return '<div id="page-wrapper"><h1 id="tajekoztato">Regisztrációs adatok törlése</h1><br /><h3>Biztos vagy benne? Ha igen, kattints a Végrehajtás feliratu gombon. Ha mégsem válassz más menüpontot. A regisztrációs adataid törlésével nem tudsz újra bejelentkezni csak ha ismét regisztrálod magad.</h3></div>';
            case 10:
                return szovegetide(1, 62) + '<br />A régi jelszavad nem lehetett kevesebb mint 10 karakter. Kérem ellenőrizd a beírt jelszót.';
            case 11:
                return szovegetide(1, 62) + '<br />A régi jelszó nem az érvényes jelszavad.';
            case 12:
                return szovegetide(1, 62) + '<br />Az új jelszó hossza, minimum 10 karakter kell, hogy legyen.';
            case 13:
                return szovegetide(1, 62) + '<br />A jelszó meg nem engedett, karaktert tartalmaz.';
            case 14:
                return szovegetide(1, 62) + '<br />A két új jelszó mező értéke nem egyforma .';
            case 15:
                return szovegetide(1, 62) + '<br />A felhasználói neved minimum 4 karakter legyen.';
            case 16:
                return szovegetide(1, 62) + '<br />A felhasználói neved nem megengedett, karaktert tartalmaz.';
            case 17:
                return szovegetide(1, 62) + '<br />A megadott felhasználói név már foglalt.';
            case 18:
                return szovegetide(1, 62) + '<br />A jelszó módosítása nem sikerült.';
            case 19:
                return szovegetide(1, 62) + '<br />Az adatok módosítása megtörtént.';
            case 20:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy a csoportból mindenkinek, vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig vagy az általad megadott maximális ideig érhatőek el. Utánna a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.<button class="gombok" id="413">413 statusz</button></h3><br><div>' + '<center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all" >Üzenet küldése, mindenkinek<br><input type="radio" name="kuldes" value="select" checked="checked">Üzenet küldése a kiválasztott tagoknak<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div>' + '<br>' + filefelt + '<br>' + hangfelt + '<img id="uzenetkuldesinfo2" src="ico/info.png"><label>Üzenet szövege</label><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft"></textarea>' + '<br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"><br></div>';
            case 21:
                return szovegetide(1, 62) + '<br />Hiba a taglista letöltésekor. Próbáld újra.';
            case 22:
                return szovegetide(1, 62) + '<br />Hiba a kapcsolatban vagy a kapcsolat offline.';
            case 23:
                return szovegetide(1, 62) + '<br />Nem választottál címzettet.';
            case 24:
                return szovegetide(1, 62) + '<br />Nem írtál be üzenetet. Az üres üzenet, nem lett elküldve.';
            case 25:
                return szovegetide(1, 62) + '<br />Üzenet mentve, online allapotban elküldésre kerül. Ha előtte kilépsz az alkalmazásból vagy bezárod a weboldalt az üzenet nem kerül elküldésre.';
            case 26:
                return 'Elküldve: ';
            case 27:
                return 'Hiba! Az üzenet elküldése valószínüleg nem sikerült.';
            case 28:
                return szovegetide(1, 62) + '<br />Üzenet elküldve.';
            case 29:
                return '<div id="page-wrapper"><h2>Üzenetek megjelenítéséhez kattintson az üzenetek menügombon (mobil esszközön 2-szer nyomja meg)</h2><h3></h3><br><script>uzenetekbetoltese();</script></div>';
            case 30:
                return 'Az alkalmazás offline';
            case 31:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 1';
            case 32:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 2';
            case 33:
                return szovegetide(1, 62) + '<br />Lekérdezés hibakód: 3';
            case 34:
                return szovegetide(1, 62) + '<br />Nincsen üzeneted';
            case 35:
                return '<h2>Dekódolási hiba, kérem próbáld újra az üzenetek letöltését</h2>';
            case 36:
                return 'Az üzenet kulcsfájlal dekódolható';
            case 37:
                return 'Az üzenetet az alkalmazás dekódolta';
            case 38:
                return 'A fájl jelszóval dekódolható';
            case 39:
                return 'A fájl kulcsfájlal dekódolható';
            case 40:
                return '<div id="page-wrapper"><h1>DMSK Beállítások</h1><center><div id="dmsk_radio"><input  type="radio" name="valasztas" value="off">  DMSK 240B-F mód kikapcsolása<br><input id="dmsk_modosit" type="radio" name="valasztas" value="mode">  DMSK 240B-F kód módosítása<br><input  type="radio" name="valasztas" value="on" checked="checked">  DMSK 240B-F mód bekapcsolása<br></div></center><br><input id="ujdmsk" type="text"/><img id="dmskinfo" src="ico/info.png"><h3 id="dmskinfotext">A DMSK 240B-F algoritmus egy, csak az adatbázis-szerver és egy csak általad ismert kódsorozattal (szöveg, szám, mondat) egy plusz paramétert, sót ad hozzá az üzenetek kódolásához. Ha elfelejted a kódot a DMSK plussz funkcióját nem fogod tudni használni. Ha ez történne töröld a regisztrációd és regisztrálj újra. Akkor a rendszer egy új kódot fog küldeni e-mailban. Amit bejelentkezés után lehetőleg módosíts minél hamarabb. A kódra a jelszóra is érvényes szabályok érvényesek.(minimum 10 karakter nagy és kisbetü és szám.) </h3><br><label>Kulcsszinkron időközök secundum</label><input id="kulcsszinkronsetup" type="number" style="color:yellow;background:black" min="15" max="160" value="29" step="5"><br><label>Üzenetellenörzési időközök secundum</label><input id="uzenetellenorzessetup" type="number" style="color:yellow;background:black" min="10" max="1800" value="15" step="5"><br><label>Időzár beállítás perc</label><input id="idozarsetup" type="number" style="color:yellow;background:black" min="1" max="60" value="5" step="1"></div>';
            case 41:
                return '<br/><button id="help" class="gombok tooltip">Online help</button><br/><button id="jkk" class="gombok tooltip">Kliens kód</button><h3>A jelszó és felhasználóinév módosításhoz kattints az ikonra</h3><br><img id="belepoinfo" src="ico/gear.png" alt="Információk"/><br><div id = "beinfo"><div><h3>Asztali gépet használóknak:<br><br>CTRL+Q hozza elő ezeket az információkat. Utánna ENTER az üzenetlistát<br>CTRL+X kilépés<br>CTRL+Y azonnali kulcsszinkron<br>CTRL+0 (nulla) menümagnes ki-be<br>CTRL+F1 Online help<br>CTRL+F2 üzenetküldés menü<br>ESC Rendszerüzenet bezárása</h3><br>' + "<h3> Kérem ne frissítsd az oldalt mert a generált azonosítód csak egyszeri belépésre jogosít.Használd a webalkalmazás gombjait.Ha elnavigálsz az oldalról ismét be kell majd jelentkezned. Böngészéshez nyiss új fület a böngészőben és ezt hagyd nyitva amíg bejelentkezve kívánsz maradni.Tehát az oldal bezárásával is megtörténik a kijelentkezésed. <br/>" + "Amíg az oldal meg van nyitva az új üzeneteidről a beállított időintervallumonként értesítést fogsz kapni. <br/></h3><div><label" + ' for = "message"> Régi jelszó: </label><input type="password" id="regijelszo"/></div><div><label for = "message"> Új jelszó: </label><input type="password" id="passa"/></div><div><label for = "message"> Új jelszó megismétlése: </label><input type="password" id="passb"/><div><label for = "message"> Felhasználói név váltás(opcionális, de a jelszóváltáshoz kötött): </label><input type="text" id="ujnicname"/></div>' + "</div><h3><br/>Ha új felhasználó vagy, érdemes a jelszavad módosítania. A hossza minimum 10 karakter ékezetek nélküli, kis és nagybetük, számok.</h3></div>";
            case 42:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mód kikapcsolva</h1></div>';
            case 43:
                return szovegetide(1, 62) + '<br />A DMSK-240B-F kódra a minimális elvárások a jelszóéval egyeznek meg.';
            case 44:
                return '<div id="page-wrapper"><h1>DMSK 240B-F mód bekapcsolva</h1><h3>Amennyiben rossz kódot adtál meg az alkalmazás nem fog működni. A kód módosítását csak helyes kód megadása után tudod elvégezni.</h3></div>';
            case 45:
                return szovegetide(1, 62) + '<br />A DMSK-240B-F kód módosításához be kell kapcsolni, azt a jelenlegi érvényes kóddal.';
            case 46:
                return szovegetide(1, 62) + '<br />Írj be egy megfelelően bonyolult, de jól megjegyezhető kódot.';
            case 47:
                return szovegetide(1, 62) + '<br />A kód maximális hossza 199 karakter, minimális hossza 10 karakter.';
            case 48:
                return szovegetide(1, 62) + '<br />A kód nem megengedett karaktert tartalmaz.';
            case 49:
                return szovegetide(1, 62) + '<br />A kód módosítása során hiba történt';
            case 50:
                return szovegetide(1, 62) + '<br />A kód módosítása sikeresen megtörtént.';
            case 51:
                return szovegetide(1, 62) + '<br />A művelet elvégzése során hiba lépett fel';
            case 52:
                return ' \n\n---- Erre válasz: ';
            case 53:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy mindenkinek vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig, törlésükig vagy az általad megadott maximális ideig érhetőek el. Majd a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.</h3><br><div><div id="uzenetkuldes_radio"><input type="radio" name="kuldes" value="select" checked="checked">Válasz üzenet küldése<br><div id="tagidlist"><br><select name="tagoklista" id="taglista"><option value="';
            case 54:
                return '<div id="page-wrapper"><h1>Üzenet küldése</h1><br><img id="uzenetkuldesinfo1" src="ico/info.png"><h3 id="uzenetkuldestext1">Válaszd ki, hogy mindenkinek vagy csak bizonyos szmélyeknek akarsz üzenetet küldeni. Az üzeneted elolvasásukig, törlésükig vagy az általad megadott maximális ideig érhatőek el. Majd a rendszer automatikusan törli azokat. Visszakeresésükre nincsen mód.</h3><br><div><center><div id="uzenetkuldes_radio"><input  type="radio" name="kuldes" value="all" >Üzenet küldése, minden tagnak<br><input type="radio" name="kuldes" value="select" checked="checked">Üzenet küldése a kiválasztott tagoknak<br></div></center><div id="tagidlist"><script>tagidlistabetoltese();</script></div></div><br>' + filefelt + '<br>' + hangfelt + '<label>Üzenet szövege</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="10" cols="20" wrap="soft">Továbbított üzenet:\n\n' + kapottuzenetszovege + '</textarea>' + '<br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>' + kulcsft + '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"></div>';
            case 55:
                return '<div id="page-wrapper"><h1>Privát Üzenetküldő Webalkalmazás<br>PMWA<br>DMSK-240B-F<br>One Time Pad<br>Alias Verman Encrypter</h1></div>'; //----
            case 56:
                return '<h2>Offline kapcsolat, nincsen elérhető üzenetlista</h2>';
            case 57:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />Nincsenek olvasatlan üzeneteid<br><br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 58:
                return '<h2>Kulcsszikron hiba. Szinkronizálj manuálisan, vagy várd meg amíg a rendszer újraszinkronizál.</h2><br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 59:
                return '<br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 60:
                return '<h2>Offline állapot: mentett üzenetlista</h2><br>';
            case 61:
                return; //'<br><p class="adatokmegjelenitesek">Küldött adatok:' + (kuldottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjelenitesef">Fogadott adatok: ' + (fogadottadat / 1024 / 1024).toFixed(4) + ' MB</p><p class="adatokmegjeleniteseo">Összes (ki és be) adatcsomag száma: ' + szerverkapcsolatszam + '</p>';
            case 62:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span>';
            case 63:
                return 'Fogadott adatok: ';
            case 64:
                return 'Összes(ki és be) adatcsomag száma: ';
            case 65:
                return 'Küldött adatok: ';
            case 66:
                return 'Végrehajtás';
            case 67:
                return 'Küldés';
            case 68:
                return '<div><h3>El nem küldött offline üzeneteid vannak</h3></div><div><h3 style="color:brown">Biztos hogy kilépsz az alkalmazásból?</h3><br>';
            case 69:
                return 'Megerősítés';
            case 70:
                return '<div><h3>Biztos hogy törlöd a regisztrációd?</h3></div><div><h3 style="color:brown">Akkor add meg a jelszavad</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 71:
                return szovegetide(1, 62) + '<br />A DMSK kódolás után az üzenet hossza meghaladja a megengedett méretet. Titkosítsd az üzenetet jelszóval, kulcsfájlal vagy rövidítsd le.';
            case 72:
                return szovegetide(1, 62) + '<br /> Jelszavas vagy kulcsfájlos titkosítás nélkül nem kóldhetsz fájlt.';
            case 73:
                return szovegetide(1, 62) + '<br />A kulcsfájl hossza kisebb a kódolandó adatoknal, ez ellentétben áll a One Time Pad titkosítás alapelvével. Válasszon nagyobb kulcsot.';
            case 74:
                return szovegetide(1, 62) + '<br />A kulcsfájl hossza kisebb a kodolandó fájlnál, ez ellentétben áll a One Time Pad titkosítás alapelvével. Válassz nagyobb kulcsot.';
            case 75:
                return; //'<img src = "images/sportcsarnok.jpg" id = "terkep" alt="A kép betöltése nem sikerült..."><div id="helyszin" class="helyszin">Helyszin: Izsák, Sportcsarnok</div>';
            case 76:
                return 'Regisztráció';
            case 77:
                return 'Belépés';
            case 78:
                return '<div id="page-wrapper"><h3>A regisztrációnál megadott felhasználói neved, és ha még nem módosítottad az ott kapott jelszó. Az webalkalmazás, alapértelmezésben DMSK-240B titkosítást használ az adatok küldéséhez és fogadásához. Ami HTTPS kapcsolat nélkül is, védelmet nyújt a küldött, információk, számára.</h3><br /><h1>Bejelentkezés</h1><div class="field"><label >Felhasználóinév:</label><input type="text" id="loginname"></div><div class="field"><label for="message">Jelszó:</label><input type="password" id="loginpass"></input><br><label>Minden más eszközről léptessen ki</label><input id="kileptetes" type="checkbox" class="kileptetes"></div></div>';
            case 79:
                return szovegetide(1, 62) + '<br />Tartalmazzon legalább egy számot.';
            case 80:
                return szovegetide(1, 62) + '<br />Tartalmazzon kisbetüket is.';
            case 81:
                return szovegetide(1, 62) + '<br />Tartalmazzon nagybetüket is.';
            case 82:
                return szovegetide(1, 62) + '<br />Szerver oldali hiba (500)';
            case 83:
                return szovegetide(1, 62) + '<br />A webserver a kérést átmenetileg elutasította. Próbáld meg ismét. (503)';
            case 84:
                return szovegetide(1, 62) + '<br />Az oldal nem elérhető (404)';
            case 85:
                return szovegetide(1, 62) + '<br />Az üzenet elküldésekor hiba keletkezett (400)';
            case 86:
                return szovegetide(1, 62) + '<br />Az oldal nem elérhető (0)';
            case 87:
                return szovegetide(1, 62) + '<br />Az 1MB-ot meghaladó adatokat darabokban küldjük. Automatikus darabolás végrehajtva. Várd meg amíg minden darab elküldésre kerül.';
            case 88:
                return szovegetide(1, 62) + '<br />A kapcsolat offline, ellenőrizd az internetkapcsolatod.';
            case 89:
                return szovegetide(1, 62) + '<br />A kapcsolat online.';
            case 90:
                return szovegetide(1, 62) + '<br />A loginnév vagy a jelszó hossza nem megfelelő';
            case 91:
                return 'Ellenőrizd a Felhasználói neved, mert valamit biztos elírtál.';
            case 92:
                return "Kapcsolati hiba: Próbáld meg mégegyszer a bejelentekezés elküldését";
            case 93:
                return szovegetide(1, 62) + '<br />Add meg a kódot a küldés gomb megnyomása előtt';
            case 94:
                return '<h1>A megadott regisztrációs kód nem érvényes</h1>';
            case 95:
                return "A biztonság kedvéért a belépés utánni üzenetküldési funkciók eléréséhez, meg kell várnod a csoportadminisztrátori aktiválást.";
            case 96:
                return szovegetide(1, 62) + '<br />Foglalt név';;
            case 97:
                return szovegetide(1, 62) + '<br />A név minimum  4 karakter legyen , az email cím pedig élő, mert oda kapod a megerősítéshez szükséges kódot';
            case 98:
                return szovegetide(1, 62) + '<br />Az email cím formátuma nem megfelelő: pelda@valami.com';
            case 99:
                return szovegetide(1, 62) + '<br />A felhasználói név nem megengedett karaktert tartalmaz.';
            case 100:
                return "<h1>A megadott felhasználói név már foglalt, használj valami megkülönböztető információt.</h1>";
            case 101:
                return '<div id="page-wrapper"><h3>Kövesd a leírtakat és nyomd meg a küldés gombot.</h3><br /><h1>Megerősítés</h1><div id="regisztral" class="field"><label >Add meg az emailben kapott kódot:</label><input type="password" id="regkod"></div></div>';
            case 102:
                return 'Hiba! Az üzenet elküldése  nem sikerült. A szerver nem fogadja a kéréseket.';
            case 103:
                return 'Hiba! A feltöltés  nem sikerült.';
            case 104:
                return; //'<h3 id="udvszoveg"><br>Üdvözöllek az együttmozás csoport privát üzenetküldő webalkalmazása kezdőoldalán.<br></h3>';
            case 105:
                return '<h1 id="honlapra">SEMOTUS</h1>'; //----
            case 106:
                return 'kezdőoldal<span class = "tooltiptext"> Főoldal. </span>';
            case 107:
                return; //'helyszín<span class = "tooltiptext" > A tornaterem helye és címe.</span>';
            case 108:
                return; //'adatvédelem<span class = "tooltiptext" > Adatvédelmi nyilatkozat. </span>';
            case 109:
                return 'belépés<span class="tooltiptext">Regisztráció szükséges.</span>'; //----
            case 110:
                return 'regisztráció<span class = "tooltiptext" > Regisztráció, érdeklődőknek, teszteléshez, kipróbáláshoz.</span>'; //--
            case 111:
                return 'Sikeres bejelentkezés';
            case 112:
                return 'kijelentkezés<span class=\"tooltiptext \">Főoldalra.</span>';
            case 113:
                return 'Teljeskép-be<span class=\"tooltiptext\">Teljes képernyős mód ki és bekapcsolása</span>';
            case 114:
                return 'üzenetek<span class=\"tooltiptext \">Az üzeneteidet itt nézheted meg</span>';
            case 115:
                return 'üzenetküldés<span class=\"tooltiptext\">Innen idíthatsz üzeneteket</span>';
            case 116:
                return 'DMSK beállítás<span class=\"tooltiptext\">Kikapcsolhatod, bekapcsolhatod a DMSK-240B-F módot, vagy módosíthatod a kódot. Erőssen ajánlott a használata.</span>';
            case 117:
                return 'Törlöm magam<span class=\"tooltiptext\">Megerősítés után végleg törölheted a regisztrációs adataidat.</span>';
            case 118:
                return 'Admin<span class=\"tooltiptext\">Adminisztrációs feladatok, felhasználók kezelése.</span>';
            case 119:
                return ' A csoporthoz való tarozásod ellenörzéséig nem tudod igénybe venni a webalkalmazás funkcióit. Kérem a türelmed, amíg megerősítem a státuszod: Admin.';
            case 120:
                return 'Üdvözöllek, az üzenetküldő webalkalmazásban';
            case 121:
                return 'Üdvözöllek, az üzenetküldő webalkalmazásban-ADMIN mód';
            case 122:
                return 'Mégsem';
            case 123:
                return '<span class="tooltiptext "><p class="elrejt">Figyelmeztetés törlése</p></span><br />A jelszavas védelem törlése végrehajtva. Most adhatsz meg másik jelszót, vagy választhatsz másik védelmi funkciót.';
            case 124:
                return '<div><h3>Titkosított üzenet küldése</h3></div><div><h3 style="color:brown">Add meg a jelszót amit a fogadó fél is ismer</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 125:
                return 'Titkosítás';
            case 126:
                return 'A jelszó hossza legalább 10 karakter kell legyen (ajánlott 30 karakter)';
            case 127:
                return '<span class="tooltiptext "><p class="elrejt">Figyelmeztetés törlése</p></span><br />A jelszó megfelelő. Ne feledd, hogy az ismerete nélkül a fogadó fél nem tudja elolvasni az uzeneted.';
            case 128:
                return '<label>OTP titkosítás</label><label id="kflabel">Kulcsfájl használata titkosításhoz<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/></label>';
            case 129:
                return '<button id="filefel" class="gombok tooltip">Fájl küldés</button><label id="fmtlab">A fájl már titkosított</label><input id="cb_titkositott" type="checkbox" class="kileptetes">';
            case 130:
                return 'A kulcsfájl mérete 10kb és 30MB közötti lehet';
            case 131:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A titkosításhoz használt fájl adatai';
            case 132:
                return 'Fájl: ';
            case 133:
                return 'Tipusa: ';
            case 134:
                return 'Mérete: ';
            case 135:
                return ' MB<br>Figyelem a kulcsfájl ismerete nélkül az adatok a fogadó oldalon nem fejthetőek vissza!';
            case 136:
                return 'Kulcsfájl törlése';
            case 137:
                return 'Kulcsfájl használata titkosításhoz<input type ="file" name ="kfile" id ="verman" class ="inputfilek"/>';
            case 138:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A kulcsfájl vissza lett vonva.';
            case 139:
                return 'Fájl küldés';
            case 140:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A küldendő fájl vissza lett vonva.';
            case 141:
                return 'Fájl kiválasztva';
            case 142:
                return 'A fájl mérete 1kb és 10MB közötti lehet';
            case 143:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A küldésre kiválasztott fájl adatai';
            case 144:
                return 'Ezzel az üzenettel egyidőben küldött fájl neve:';
            case 145:
                return '<div><h3>Titkosított üzenet dekódolása</h3></div><div><h3 style="color:brown">Adja meg a jelszót amivel a feladó kódolta az üzenetet</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 146:
                return 'Visszafejtés';
            case 147:
                return 'Ha rossz jelszót írtál be töltsd le újra az üzenetet a dekódoláshoz.';
            case 148:
                return '<div><h3>Titkosított fájl dekódolása</h3></div><div><h3 style="color:brown">Add meg a jelszót amivel a feladó kódolta a fájlt. A dekódolás hosszabb ideig is eltarthat...</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 149:
                return 'Ha rossz jelszót írál be töltsd le újra az fájlt a dekódoláshoz.';
            case 150:
                return '<span class="tooltiptext "><p class="elrejt">Információ elrejtése</p></span><br />A dekodoláshoz használt fájl adatai';
            case 151:
                return 'Ha rossz kulcsfájlt adotál meg töltsd le újra az üzenetet a dekódoláshoz.';
            case 152:
                return 'Több mint 1 perce kikapcsoltad a kulcsszinkronizálást. Ha így használod az alkalmazást az 2 perc inaktivitás után biztonsági okokból kidob! (Lásd a rendszerspecifikációt).';
            case 153:
                return '" selected>VÁLASZ</option></select></div></div>';
            case 154:
                return '<label>Üzenet szövege</label><br><img id="uzenetkuldesinfo2" src="ico/info.png"><br><h3 id="uzenetkuldestext2">Küldés után az UTOLJÁRA elküldött üzeneted az ÜZENETKÜLDÉS menügombra kattintva újra betöltődik, ha másnak is el akarod küldeni. A jelszóval titkosított üzenetek NEM lesznek mentve! A fájlok csak jelszóval vagy kulcsfájlal védve küldhetőek.</h3><textarea id="ujuzenet" rows="20" cols="40">';
            case 155:
                return '</textarea><br><button class="gombok" id="kiurit">Szövegtörlése</button><br><label>Az üzenet legyen jelszóval védett</label><button class="gombok" id="pinvedett">Password</button><br>';
            case 156:
                return '<label>Írd be órában az üzeneted maximális érvényességi idejét</label><input type="number" id="maxido" value="48" min="1" max="168"></div></div>';
            case 157:
                return 'Webalkalmazás adminisztráció';
            case 158:
                return 'Felhasználók';
            case 159:
                return 'Tisztítás';
            case 160:
                return 'Vissza';
            case 161:
                return 'Felhasználói lista';
            case 162:
                return ' Sor került törlésre az adatbázisból';
            case 163:
                return 'Az adatbazishoz az aktiv kapcsolatok száma: ';
            case 164:
                return ' Minden kommunikáció';
            case 165:
                return '<div><h3>Biztos hogy feloldod a kommunikációs blokkolást?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 166:
                return '<div><h3>Biztos hogy blokkolsz minden kommunikációt?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 167:
                return '<div><h3>Biztos hogy elvégzed az adatbazis tisztitását?</h3></div><div><h3 style="color:brown">Akkor adja meg a jelszavát</h3><br></div><input type="password" style="z-index:10000;border: 1px solid red;background-color:lightgreen" name="name"><br>';
            case 168:
                return 'Biztos hogy elvégzed az aktiválást? Ismered a felhasználót?';
            case 169:
                return 'Biztos hogy elvégzed a tag felfüggesztést?';
            case 170:
                return 'Biztos hogy elvégzed az egész csoport törlését?';
            case 171:
                return 'Akkor add meg a jelszavad';
            case 172:
                return 'Az adminisztrátor nem törölhető csak a csoporttal együtt';
            case 173:
                return 'Biztos hogy elvégzed a tag regisztrációjának a törlését?';
            case 174:
                return 'Szerver oldali hibakód: ';
            case 175:
                return 'Érkezett üzenetek';
            case 176:
                return 'Feladó: ';
            case 177:
                return 'Üzenet: DMSK védelem';
            case 178:
                return 'Üzenet: Kulcsfájllal védett';
            case 179:
                return '"OneTimePad" védett fájl';
            case 180:
                return 'Jelszóval védett fájl';
            case 181:
                return 'Üzenet: Jelszóval védett';
            case 182:
                return ' Küldés ideje: ';
            case 183:
                return 'Az üzenet mérete: ';
            case 184:
                return 'Az üzenetek összmérete: ';
            case 185:
                return 'Letöltöm';
            case 186:
                return 'Üzenet letöltése olvasásra.';
            case 187:
                return 'Törlöm !!!';
            case 188:
                return 'Ha ide kattintasz az üzenet nem jelenik meg többet.';
            case 189:
                return 'Letöltött üzenet';
            case 200:
                return 'DMSK védelemmel ellátott üzenet';
            case 201:
                return '"OneTimePad" kulcsfájllal kódolt üzenet. A megtekintéshez dekódold';
            case 202:
                return 'Jelszóval védett üzenet. A megtekintéshez dekódold';
            case 203:
                return 'Jelszóval kódolt fájl. A mentéséhez dekódold';
            case 204:
                return '"OneTimePad" kódolt fájl, a mentéshez dekódold.';
            case 205:
                return 'Válasz';
            case 206:
                return 'Válasz írása az üzenetre.';
            case 207:
                return 'Elolvastam';
            case 208:
                return 'Ha ide kattintasz az üzenet nem jelenik meg többet.';
            case 209:
                return 'Jelszó beírása a kódolt üzenet dekódolásához.';
            case 210:
                return 'Továbbítom';
            case 211:
                return 'Az üzenet továbbítása más tagnak.';
            case 212:
                return 'Törlöm';
            case 213:
                return 'Lementem';
            case 214:
                return 'Jelszó beírása a kódolt üzenet dekódolásához.';
            case 215:
                return 'A megadott belépési adatok nem érvényesek. Figyelj a nagy és kisbetükre...';
            case 216:
                return 'A mezők kitöltése nem volt megfelelő... (code:400)';
            case 217:
                return 'A felhasználóinév min 4 a jelszó minimum 10 karakter';
            case 218:
                return 'Elméletileg a szerver által fogadott maximális HTTP adatcsomag mérete: ';
            case 219:
                return 'A válasz elküldésével és az elolvastam gomb megnyomásával az üzenet nem tölthető be újra.<br> A továbbított üzenet újból letölthető az érvényességi idején belül.';
            case 220:
                return 'Visszavan: ';
            case 221:
                return 'Csomagok összefűzése a szerveren';
            case 222:
                return 'Az 1MB -ot meghaladó adatokat darabokban küldjük. Automatikus darabolás végrehajtva. Várd meg amíg minden darab elküldésre kerül.';
            case 223:
                return 'A loginneveddel, sikertelen, belépési próbálkozások száma: ';
            case 224:
                return ' Ha nem te tévesztettél, biztonsági okokból ajánlott a loginnév megváltoztatása';
            case 225:
                return ' Regisztrált: ';
            case 226:
                return 'Megkezdett regisztráció';
            case 227:
                return 'A belépéshez használt eszközök listálya:';
            case 228:
                return 'Törlöm';
            case 229:
                return 'Aktiválom';
            case 230:
                return 'Aktiválásra vár!';
            case 231:
                return 'Felfüggesztem';
            case 232:
                return 'Aktív felhasználó';
            case 233:
                return 'Adminisztrátor';
            case 234:
                return 'Csoport-KILL';
            case 235:
                return 'Szabadhely a kiszolgálón: ';
            case 236:
                return 'Teljeshely a kiszolgálón: ';
            case 237:
                return 'Az eszközről kijelentkezve';
            case 238:
                return 'Az eszközre bejelentkezve: ';
            case 239:
                return 'Belépésszám:';
            case 240:
                return 'A megadott e-mail cím formátumában hiba van.';
            case 241:
                return 'A megadott e-mail címről már történt regisztráció.';
            case 242:
                return 'Ellenőrizd az e-mail fiókod és add meg a kapott ellenörző kódot a regisztráció befejezéséhez.';
            case 243:
                return 'Offline állapotban nem küldhetsz fájlt';
            case 244:
                return 'Megadhatja a kulcsszinkron gyakoriságát 15 és 110 másodperc között.';
            case 245:
                return 'DMSK kulcs, váltás idő beállítás';
            case 246:
                return 'Megadhatja az üzenetellenörzés gyakoriságát 10 másodperc és 30 perc között másodpercben.';
            case 247:
                return 'Új üzenetek ellenörzése';
            case 248:
                return 'Add meg a jelszavad';
            case 249:
                return 'Időzár';
            case 250:
                return '<br><button id="hangfelvetel" class="gombok tooltip">Hangüzenet</button><br>';
            case 251:
                return szovegetide(1, 62) + '<br />A hangüzenet törölve lett ';
            case 252:
                return '<br><h2>A hangüzeneteket nem célszerü lemezre menteni</h2><br>';
            case 253:
                return szovegetide(1, 62) + '<br/>Java üzennetellenörző klienshez a kódja: ' + juszlkk + '<br/>A vágólapról elérhető.';
            case 254:
                return 'A fájl mentés után dekódolandó';
            case 255:
                return 'A fájlt a webalkalmazás csak közvetítette a feladója külső titkosításunak jelölte. Mentse le és utánna dekódolja.';
            case 256:
                return;
            case 257:
                return;
            case 258:
                return;
            case 259:
                return;

        }

    }
}