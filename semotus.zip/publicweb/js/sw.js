importScripts('serviceworker-cache-polyfill.js');

// example usage:
self.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open('semotus-cache').then(function (cache) {
            return cache.addAll([
                        '/',
                        '/index.php',
                        '/index.php?homescreen=1',
                        '/?homescreen=1',
                        '/js/TweenMax.min.js',
                        '/js/jquery.min.js',
                        '/js/jquery-ui.min.js',
                        '/js/nyelvek.js',
                        '/js/app.js',
                        '/js/OggVorbisEncoder.min.js.mem',
                        '/js/Mp3LameEncoder.min.js.mem',
                        '/js/WebAudioRecorderWav.min.js',
                        '/js/WebAudioRecorderOgg.min.js',
                        '/js/WebAudioRecorderMp3.min.js',
                        '/js/WebAudioRecorder.min.js',
                        '/js/index.html',
                        '/ico/eng.png',
                        '/ico/hun.png',
                        '/ico/fel.png',
                        '/ico/le.png',
                        '/ico/ulock.png',
                        '/ico/lock.png',
                        '/ico/error.png',
                        '/ico/enter.png',
                        '/ico/erdsmk.png',
                        '/ico/eszkozok.png',
                        '/ico/ki.png',
                        '/ico/burn.png',
                        '/images/icons-512.png',
                        '/images/icons-192.png',
                        '/css/pie.css',
                        '/css/fonts.css',
                        '/css/images/ui-icons_ffffff_256x240.png',
                        '/css/images/ui-icons_454545_256x240.png',
                        '/css/images/ui-icons_555555_256x240.png',
                        '/css/images/ui-icons_777620_256x240.png',
                        '/css/images/ui-icons_777777_256x240.png',
                        '/css/images/ui-icons_888888_256x240.png',
                        '/css/images/ui-icons_cc0000_256x240.png',
                        '/css/images/ui-bg_flat_75_ffffff_40x100.png',
                        '/css/images/ui-bg_glass_65_ffffff_1x400.png',
                        '/css/images/ui-bg_glass_75_dadada_1x400.png',
                        '/css/images/ui-bg_glass_75_e6e6e6_1x400.png',
                        '/css/images/ui-bg_highlight-soft_75_cccccc_1x100.png',
                        '/css/images/ui-icons_222222_256x240.png',
                        '/css/images/ui-icons_444444_256x240.png',
                        '/css/images/ui-bg_flat_0_aaaaaa_40x100.png',
                        '/images/elutasit.gif',
                        '/43.gif',
                        '/favicon.ico',
                        '/1.mp3',
                        '/manifest.json'
            ]);
        })
    );
});

self.addEventListener('fetch', function (event) {
    event.respondWith(
        caches.match(event.request).then(function (response) {
            return response || new Response("Nothing in the cache for this request");
        })
    );
});

// let deferredPrompt;



// self.addEventListener('beforeinstallprompt', (e) => {
//     // Prevent Chrome 67 and earlier from automatically showing the prompt
//     e.preventDefault();
//     // Stash the event so it can be triggered later.
//     deferredPrompt = e;
//     // Update UI notify the user they can add to home screen
//     btnAdd.style.display = 'block';
// });

// self.addEventListener('click', (e) => {
//     // hide our user interface that shows our A2HS button
//     btnAdd.style.display = 'none';
//     // Show the prompt
//     deferredPrompt.prompt();
//     // Wait for the user to respond to the prompt
//     deferredPrompt.userChoice
//         .then((choiceResult) => {
//             if (choiceResult.outcome === 'accepted') {
//                 console.log('User accepted the A2HS prompt');
//             } else {
//                 console.log('User dismissed the A2HS prompt');
//             }
//             deferredPrompt = null;
//         });
// });

// self.addEventListener('appinstalled', (evt) => {
//     app.logEvent('a2hs', 'installed');
// });