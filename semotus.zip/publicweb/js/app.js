//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; //stream from getUserMedia()
var recorder; //WebAudioRecorder object
var input; //MediaStreamAudioSourceNode  we'll be recording
var encodingType; //holds selected encoding for resulting audio (file)
var encodeAfterRecord = true; // when to encode

// shim for AudioContext when it's not avb. 
var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext; //new audio context to help us record

var encodingTypeSelect = document.getElementById("encodingTypeSelect");
var recordButton = document.getElementById("recordButton");
var stopButton = document.getElementById("stopButton");

//add events to those 2 buttons
recordButton.addEventListener("click", startRecording);
stopButton.addEventListener("click", stopRecording);

function startRecording() {
    console.log("startRecording() called");

    /*
    	Simple constraints object, for more advanced features see
    	https://addpipe.com/blog/audio-constraints-getusermedia/
    */

    var constraints = {
        audio: true,
        video: false
    };

    
    navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
        $('#log').html("Recording Start...");
        audioContext = new AudioContext();
        document.getElementById("formats").innerHTML = "<br>";//"Format: 2 channel " + encodingTypeSelect.options[encodingTypeSelect.selectedIndex].value + " @ " + audioContext.sampleRate / 1000 + "kHz"
        gumStream = stream;
        input = audioContext.createMediaStreamSource(stream);
        encodingType = encodingTypeSelect.options[encodingTypeSelect.selectedIndex].value;
        encodingTypeSelect.disabled = true;

        recorder = new WebAudioRecorder(input, {
            workerDir: "js/",
            encoding: encodingType,
            numChannels: 2, 
            onEncoderLoading: function (recorder, encoding) {
                // show "loading encoder..." display
               
            },
            onEncoderLoaded: function (recorder, encoding) {
                // hide "loading encoder..." display
               
            }
        });

        recorder.onComplete = function (recorder, blob) {
           
            createDownloadLink(blob, recorder.encoding);
            encodingTypeSelect.disabled = false;
        }

        recorder.setOptions({
            timeLimit: 120,
            encodeAfterRecord: encodeAfterRecord,
            ogg: {
                quality: 0.2
            },
            mp3: {
                bitRate: 96
            }
        });

        //start the recording process
        recorder.startRecording();

        

    }).catch(function (err) {
        //enable the record button if getUSerMedia() fails
        recordButton.disabled = false;
        stopButton.disabled = true;

    });

    //disable the record button
    recordButton.disabled = true;
    stopButton.disabled = false;
}

function stopRecording() {
    console.log("stopRecording() called");

    //stop microphone access
    gumStream.getAudioTracks()[0].stop();

    //disable the stop button
    stopButton.disabled = true;
    recordButton.disabled = false;

    //tell the recorder to finish the recording (stop recording + encode the recorded audio)
    recorder.finishRecording();

    __log('Recording stopped');
}
var fadekapocs=0;
function createDownloadLink(blob, encoding) {

  
    var start = 0;
    var stop = blob.size - 1;
    fadekapocs = 1;
    var reader = new FileReader();
    tmp = blob.slice(start, stop + 1);
    reader.readAsBinaryString(tmp);
    reader.onloadend = function (evt) {
        
        if (evt.target.readyState == FileReader.DONE) {
            binary = evt.target.result; 
           
        }
    };
    
    if (fadekapocs==1) {
       
        titkositott = 0;
        $('#cb_titkositott').prop('checked', false);
         $('#pinvedett').fadeIn();
         $('#kflabel').fadeIn();
        $('#cb_titkositott').fadeOut(500);
        $("#filefel").fadeOut(500);
        $("#fmtlab").fadeOut(500);
         
      

    }
    else{
        $("#filefel").fadeIn(500);
        $('#cb_titkositott').fadeIn(500);
        $('#fmtlab').fadeIn(500);
       
       
    }
    $('#hanguzenet').css('display', 'none');
    $('#log').html("");
    
}



//helper function
function __log(e, data) {
    log.innerHTML += "\n" + e + " " + (data || '');
}


$('#megsemhang').click(function(){
   $('#hanguzenet').css('display', 'none');
    fadekapocs=1;
       $("#filefel").fadeIn(500);
       $('#cb_titkositott').fadeIn(500);
       $('#fmtlab').fadeIn(500);
       binary="";
        titkositott=0;
        $('#pinvedett').fadeIn();
        $('#kflabel').fadeIn();
        $('#cb_titkositott').prop('checked', false);
       $("#feed_back").html(
           szovegetide(nyelv, 251)
       );
       uzenet();
    //    $('#ujuzenet').val('');
 
   $('#log').html("");
  
});