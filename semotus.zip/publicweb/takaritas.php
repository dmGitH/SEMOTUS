<?php

require_once '../secus.php';

tokenkiller();
lejaruzenettorlese();
inaktivregisztraciotorlese();
sqlproceskill();

