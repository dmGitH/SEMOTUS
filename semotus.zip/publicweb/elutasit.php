<!DOCTYPE HTML>
<html id="fooldal" lang="hu">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="Description" content="private communication web application, author: matyo95">
    <meta name="theme-color" content="#d2691e"/>
    <title>Főoldal</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    body{
    background-image: url('images/elutasit.gif');
    background-size: cover;
    display: flex;
    background-repeat: repeat-y;
    /* background-attachment: fixed; */
    text-align: center;
    flex-direction: column;
    max-width: 100%;
    max-height: 100%;
    min-width: 10%;
    min-height: 10%;
    }
</style>
</head>
<body>
    <?php
        echo '<h2 style="color:white">ip: '.$_SERVER['REMOTE_ADDR'].' </h2><br>';
        echo '<h2 style="color:white">'. $_SERVER['HTTP_USER_AGENT'] .' </h2><br>';
        echo '<h2 style="color:white">Belépési próbálkozások 3 percre letiltva </h2><br>';
    ?>
</body>
</html>