<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//HU" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="hu">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Pssszt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    
</head>
<body>
<?php

echo '<h1 style="color:black">Egy kis időre csendet kérünk...we ask for a small silence</h1>
<br><img src="images/pszt.jpg">';
?>
</body>
</html>