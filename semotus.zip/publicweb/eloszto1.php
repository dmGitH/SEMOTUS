<?php
require_once '../login.php';
require_once '../reggerek.php';
require_once '../dmskuppdate.php';
require_once '../erzgrg684rzgfsfefisfhf.php';
require_once '../kuldott.php';
require_once '../lista.php';
require_once '../passmodifi.php';
require_once '../passchek.php';
require_once '../logout.php';
require_once '../phpinfo.php';
require_once '../reg.php';
require_once '../regdelet.php';
require_once '../searcmessage.php';
require_once '../silent.php';
require_once '../sucess.php';
require_once '../tagid.php';
require_once '../tavozik.php';
require_once '../threadinfo.php';
require_once '../tisztit.php';
require_once '../upload.php';
require_once '../upp413.php';
require_once '../usera.php';
require_once '../uzenetletoltes.php';
require_once '../visible.php';
require_once '../javakerdezile.php';
require_once '../bereg.php';



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $go = $_POST['go'];
    switch($go){
        case 1:
            belepes();
        break;
        case 2:
            reggerek();
        break;
        case 3:
            dmskuppdate();
        break;
        case 4:
            rzgrg();
        break;
        case 5:
            kuldott();
        break;
        case 6:
            lista();
        break;
        case 7:
            logout();
        break;
        case 8:
            $valasz = (int)(str_replace('M', '', ini_get('post_max_size')) * 1024);
            echo '' . $valasz . ' kb';
        break;
        case 9:
            passcsek();
        break;
        case 10:
            passmodifi();
        break;
        case 11:
            info();
        break;
        case 12:
            reg();
        break;
        case 13:
            regdelet();
        break;
        case 14:
            ujuzenet();
        break;
        case 15:
            kussvan();
        break;
        case 16:
            sucess();
        break;
        case 17:
            tagok();
        break;
        case 18:
            tavozik();
        break;
        case 19:
            threadinfo();
        break;
        case 20:
            tisztit();
        break;
        case 21:
            uppload();
        break;
        case 22:
            kerulout();
        break;
        case 23:
            usera();
        break;
        case 24:
            uzenetletoltes();
        break;
        case 25:
            lattam();
        break;
        case 26:
            javakerdimennyiuzenetevan();
        break;
        case 27:
            bereg();
        break;
    }

} else {
    
    echo 1;
    // echo hash('sha256', $_SERVER['HTTP_REFERER']);
}
