<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};
class Regisztracio
{

    public $id;
    public $hash;
    public $aktiv;
    public $regisztralt;
    public $ip;
    public $nickname;
    public $passhash;
    public $dmsk;
	
    public function __construct()
    {
        
    }


}
