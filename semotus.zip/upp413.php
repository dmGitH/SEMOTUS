<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function kerulout()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'csek.php';
    require_once 'athelyez.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $klt = $_POST["klt"];
        // $tk = $_POST["tk"];
        $cssz = $_POST["cssz"];
        $csa = $_POST["csa"];
        // $kulcs = hashellenor($tk);

        $lejar = $_POST["lejarat"];
        $darab = $_POST["darab"];
        $kinek = $_POST["kinek"];
        $ki = $_POST["ki"];
        // $ujkulcs = ujkucs($kulcs, sha1($tk));
        $reg_id=kikerdezi($ki);

        

        $query = $db->prepare("insert into temp413 (`kinek`,`ki`,`darab`,`sorban`,`klt`,`azonosito`,`lejar`,`time`) VALUES(?,?,?,?,?,?,?,?);");
        if ($query->execute(array($kinek, $reg_id, gzcompress($darab), $cssz, $klt, $csa, $lejar,time())));
        else{
            echo -4;
            $db = null;
            exit;
        }

        $arr = $query->errorInfo();
        if ($arr != null) {

            // echo responsxor($arr[0] . '--SQL hibakod' . $arr[1] . '--illesztoprogram hibakod' . $arr[2] . '--illesztoprogram hibauzenet', $ujkulcs);
            // echo 0;
        }
        $db = null;
        if ($cssz == 1) {
            if (athelyezes($csa) == 1) {
                echo 2;
                $db = null;
                exit;
            } else {
                $db = null;
                echo 0;
                exit;
            }
        }
        echo 1;
        exit;
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
