<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function info()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);
        if ($kulcs == null) {
            echo 0;
            exit;
        }
        ujkucs($kulcs, $tk);
        echo phpinfo();
    } else {
        echo hibauzenetek(403);
    }
}
