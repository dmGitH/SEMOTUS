<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    http_response_code(404);
    exit();
};

class Athelyez
{

    public $id;
    public $kinek;
    public $ki;
    public $darab;
    public $sorban;
    public $klt;
    public $azonosito;
    public $lejar;
    public $time;

    public function __construct()
    {

    }


}