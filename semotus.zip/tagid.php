<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function tagok()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST["tk"];
        $kulcs = hashellenor($tk);
        $sinc = $_POST["sinc"];

        $logincod_tagid_sha1 = $_POST["logincode"];
        $ujkulcs = ujkucs($kulcs, $sinc);

        $reg_id = kikerdezi($logincod_tagid_sha1);
        $taglist = '<br><select multiple name="tagoklista" id="taglista">';
        if ($result = $db->query("select * from reg where id!='$reg_id' and nickname<>'system' and aktiv>'1';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $taglist .= '<option value="' . $row->id . '">' . $row->nickname . '</option>';
                }
                $taglist .= '</select>';

            } else {
                $db = null;
                echo hibauzenetek(403);
                exit;
            }
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }

        $db = null;
        echo responsxor($taglist, $ujkulcs);

    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
