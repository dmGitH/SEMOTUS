<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}

function ujuzenet()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'secus.php';
    require_once 'csek.php';
    require_once 'uzenetek_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        //lejaruzenettorlese();

        $logincode_sha1 = $_POST["tk"];
        $st = $_POST["st"];
        $hanincsujuzenet=$_POST["hvuu"];
        $admin = 0;
        $reg_id=kikerdezi($logincode_sha1);
        $i = 0;
        // if ($admin) {
        //     if ($result = $db->query("SELECT reg.nickname AS neve,  uzenetek.kuldte AS mikor, uzenetek.id AS uzenetazonositoja, reg.id AS kuldoazonositoja FROM `uzenetek` INNER JOIN reg on reg.id=uzenetek.reg_id order by uzenetek.kuldte DESC;")) {
        //         $result->setFetchMode(PDO::FETCH_CLASS, 'Uzenetek_m');

        //         if ($result->rowCount()) {
        //             while ($row = $result->fetch()) {
        //                 $ideje = $row->mikor;
        //                 $i++;
        //             }
        //         }
        //     }
        // }
        if ($result = $db->query("select id from kiknek where kinek='$reg_id' and statusz=0;")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Uzenetek');
            $vissza;
            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $id = $row->id;
                    $i++;

                }

                if ($st == 0) {
                    if ($i > 0) {
                        $vissza= base64_encode("ok" . "<span id=\"pirosp\">" . $i . "<script>setTimeout(messpillog, 3000);</script></span>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">&nbsp;<img id=\"dmskimg\" src=\"ico/ulock.png\"/>" . "<audio controls autoplay hidden><source src=\"1.mp3\" type=\"audio/mpeg\"></audio>");
                        if($hanincsujuzenet==sha1($vissza)) echo 'n';
                        else echo $vissza;
                    } else {
                        $vissza = base64_encode("ok" . $i . "<script>$('#uzenetszam').css('color','lightgreen');</script>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">&nbsp;<img id=\"dmskimg\" src=\"ico/ulock.png\>");
                        if ($hanincsujuzenet== sha1($vissza)) echo 'n';
                        else echo $vissza;
                    }

                } else {
                    if ($i > 0) {
                        $vissza= base64_encode("ok" . "<span id=\"pirosp\">" . $i . "<script>setTimeout(messpillog, 3000);$('#uzenetszam').css('color','lightgreen');</script></span>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">&nbsp;" . "<img id=\"dmskimg\" src=\"ico/lock.png\"><audio controls autoplay hidden><source src=\"1.mp3\" type=\"audio/mpeg\"></audio>");
                        if ($hanincsujuzenet == sha1($vissza)) echo 'n';
                        else echo $vissza;
                        
                    } else {
                        $vissza=base64_encode("ok" . $i . "<script>$('#uzenetszam').css('color','lightgreen');</script>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">" . "&nbsp;<img id=\"dmskimg\" src=\"ico/lock.png\">");

                        if ($hanincsujuzenet == sha1($vissza)) echo 'n';
                        else echo $vissza;
                       
                    }
                }
            } else {
                if ($st == 1) {
                    $vissza= base64_encode("ok" . $i . "<script>$('#uzenetszam').css('color','lightgreen');</script>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">" . "&nbsp;<img id=\"dmskimg\" src=\"ico/lock.png\">");
                    if ($hanincsujuzenet == sha1($vissza)) echo 'n';
                    else echo $vissza;
                   
                } else {
                    $vissza= base64_encode("ok" . $i . "<script>$('#uzenetszam').css('color','lightgreen');</script>&nbsp;<img id=\"messimg\" src=\"ico/env.png\">&nbsp;<img id=\"dmskimg\" src=\"ico/ulock.png\">");
                    if ($hanincsujuzenet == sha1($vissza)) echo 'n';
                    else echo $vissza;
                    
                }

            }
        } else {
            $db = null;
            echo 0;
            exit;
        }
        $db = null;
        exit;
    } else {
        $db = null;
        echo hibauzenetek(403);
        exit;
    }
}
