<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}


function reggerek()
{

    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);

        if ($kulcs == null) {
            echo 'Kulcsszinkron hiba. Próbálja meg újra a műveletet<br>';
            exit;
        }
        $loginkod_sha1 = $_POST['lc'];

        $ujkulcs = ujkucs($kulcs, $tk);
        $reg_id = kikerdezi($loginkod_sha1);
        
        $jogod = 0;
        if ($result = $db->query("select * from reg where id='$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
            if ($result->rowCount()) {
                while ($row = $result->fetch()) {
                    $jogod = $row->aktiv;
                    if ($jogod < 3) {
                        echo hibauzenetek(403);
                        exit;
                    } else {
                        $valasz = "";
                        if ($result = $db->query("select * from reg;")) {
                            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');
                            if ($result->rowCount()) {
                                while ($row = $result->fetch()) {
                                    $id = $row->id;
                                    $belepve_ = 'SELECT login from where';

                                    $valasz .= '<div class="reggerek" id="reg' . $id . '">';

                                    $eszkozok = hasznalteszkozok($id);

                                    $valasz .= '<h2>' . $row->nickname . '</h2><p class="a60">' . date("Y-m-d", $row->regisztralt) . '</p>';
                                    $st = $row->aktiv;

                                    if ($st == 0) {
                                        $valasz .= '<p class="akkodja a61" style="color:red"></p>';

                                        $valasz .= '<p class="a62"></p>';
                                        $valasz .= '<img id= "uzenetkuldesinfo1" src="ico/eszkozok.png" alt="' . $id . '"><br>';
                                        $valasz .= $eszkozok;
                                        $valasz .= '<button class="gombok a63" id="tagtorlese" value="' . $id . '_' . $st . '"></button></div></br>';
                                    } else if ($st == 1) {
                                        $valasz .= '<p class="akkodja a65" style="color:red;background-color:lightblue"></p>';

                                        $valasz .= '<p class="a62"></p>';
                                        $valasz .= '<img id= "uzenetkuldesinfo1" src="ico/eszkozok.png" alt="' . $id . '"><br>';
                                        $valasz .= $eszkozok;
                                        $valasz .= '<button class="gombok a64" id="stmodosito" value="' . $id . '_' . $st . '"></button></br>';
                                        $valasz .= '<button class="gombok a63" id="tagtorlese" value="' . $id . '_' . $st . '"></button></div></br>';
                                    } else if ($st == 2) {
                                        $valasz .= '<p class= "akkodja a67"></p>';

                                        $valasz .= '<p class="a62"></p>';
                                        $valasz .= '<img id= "uzenetkuldesinfo1" src="ico/eszkozok.png" alt="' . $id . '"><br>';
                                        $valasz .= $eszkozok;
                                        $valasz .= '<button class="gombok a66" id="stmodosito" value="' . $id . '_' . $st . '"></button></br>';
                                        $valasz .= '<button class="gombok a63" id="tagtorlese" value="' . $id . '_' . $st . '"></button></div></br>';
                                    } else if ($st == 3) {
                                        $valasz .= '<p class="akkodja a68" style="color:lightblue;font-weight:300;background-color:red"></p>';

                                        $valasz .= '<p class="a62"></p>';
                                        $valasz .= '<img id= "uzenetkuldesinfo1" src="ico/eszkozok.png" alt="' . $id . '"><br>';
                                        $valasz .= $eszkozok;
                                        $valasz .= '<button class="gombok a69" id="stmodosito" value="' . $id . '_' . $st . '"></button></br>';
                                        $valasz .= '<button class="gombok a63" id="tagtorlese" value="' . $id . '_' . $st . '"></button></div></br>';
                                    }

                                }
                                $df = (integer) ((disk_free_space(".")) / 1024 / 1024);
                                $ds = (integer) ((disk_total_space(".")) / 1024 / 1024 / 1024);
                                $valasz .= '<label class="a70">' . $df . ' MB</label>';
                                $valasz .= '<label class="a71">' . $ds . ' GB</label>';
                                echo responsxor($valasz, $ujkulcs);

                            } else {
                                $db = null;
                                echo 3;
                                exit;
                            }
                        }
                    }
                }
            } else {
                $db = null;
                echo hibauzenetek(403);
                exit;
            }
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }

    } else {
        echo hibauzenetek(403);
    }

}
