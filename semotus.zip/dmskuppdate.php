<?php
if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) {
    echo hibauzenetek(404);
    exit();
}


function dmskuppdate()
{
    require_once 'd234_kopl_456_db.php';
    require_once 'secus.php';
    require_once 'reg_class.php';
    require_once 'login_class.php';
    require_once 'csek.php';

// csak  POST .
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $tk = $_POST['tk'];
        $kulcs = hashellenor($tk);
        if ($kulcs == null) {
            echo 'kulcsszinkron hiba';
            exit;
        }

        $loginkode_dmsk_sha1 = $_POST['logincode'];
        $ujkod = strip_tags(trim(secxor($_POST['sinc'], $kulcs)));

        $ujkulcs = ujkucs($kulcs, $ujkod);
        //meg kell keresni a felhasználói nevet
        $reg_id = kikerdezi($loginkode_dmsk_sha1);
        $nickname = "";
        if ($result = $db->query("select * from reg where id='$reg_id';")) {
            $result->setFetchMode(PDO::FETCH_CLASS, 'Regisztracio');

            if ($result->rowCount()) {

                while ($row = $result->fetch()) {
                    $dmsk = $row->dmsk;

                }

            } else {
                $db = null;
                echo hibauzenetek(403);
                exit;
            }
        } else {
            $db = null;
            echo hibauzenetek(403);
            exit;
        }
        //letárolni az uj dmsk-t titkositva
        $ujkod = responsxor($ujkod, dmsksec());

        $update = "update reg set `dmsk`='" . $ujkod . "' where id=" . $reg_id . ";";
        $db->exec($update);
        $db = null;

        echo 1;

    } else {
        echo hibauzenetek(403);
    }
}
